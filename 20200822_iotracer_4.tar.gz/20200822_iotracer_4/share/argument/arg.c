#include <stdio.h>
#include <stdlib.h> // atexit
#include <string.h> // strlen

#include "arg.h"
#include "list/list.h"

/* 허용 옵션 방식
 *  --option value
 *  -o value
// *  -abcd // 이같은 경우 각 a, b, c, d가 옵션이며 마지막 d 옵션만 value 허용
// *  -abcdo value // 이처럼 마지막 o만 value 허용
 */

static int is_option_end(struct arg_option *op)
{
	return op->flag == 0 && op->help == 0 && op->long_option == 0 && op->option == 0;
}

#define FIX(fix) do { \
	if (cnt < (fix)) { \
		memset(&buf[cnt], ' ', fix-cnt); \
		cnt = fix; \
	} \
} while (0)


#define BUF_SIZE 81
void arg_usage(struct arg_option *__op)
{
	printf("Usage: [OPTION...] ");
	char buf[BUF_SIZE];
	int cnt = 0;
	struct arg_option *op = __op;
	int middle = 0;
	int max_middle = 38;
	while (!is_option_end(op)) {
		if (op->flag == ARG_OPTION_MANDATORY) {
			printf("<%s> ", op->long_option);
		}

		switch (op->flag) {
		case ARG_OPTION_MANDATORY:
			middle = 8 + strlen(op->long_option) + 2 + 8;
			//       \t<long_option>
			if (max_middle < middle) {
				max_middle = middle;
			}
			break;
		case ARG_OPTION_NO_VALUE:
			middle = 8 + 2 + ((op->long_option)?4+strlen(op->long_option):0) + 8;
			//       \t-option, --option
			if (max_middle < middle) {
				max_middle = middle;
			}
			break;
		case ARG_OPTION_VALUE:
			middle = 8 + 2 + ((op->long_option)?4+strlen(op->long_option):0) + 6 + 8;
			//       \t-option, --option                                      value
			if (max_middle < middle) {
				max_middle = middle;
			}
			break;
		default:
			break;
		}
		++op;
	}

	printf("\n\n");

	op = __op;
	while (!is_option_end(op)) {
		cnt = 0;
		switch (op->flag) {
		case ARG_OPTION_MANDATORY:
			FIX(8);
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, "<%s>", op->long_option);
			FIX(max_middle);
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, "%s", op->help);
			break;
		case ARG_OPTION_NO_VALUE:
			FIX(8);
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, "-%c", op->option);
			if (op->long_option) {
				cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, ", --%s", op->long_option);
			}
			FIX(max_middle);
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, "%s", op->help);
			break;
		case ARG_OPTION_VALUE:
			FIX(8);
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, "-%c", op->option);
			if (op->long_option) {
				cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, ", --%s", op->long_option);
			}
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, " value");
			FIX(max_middle);
			cnt += snprintf(&buf[cnt], BUF_SIZE-cnt, "%s", op->help);
			break;
		default:
			break;
		}
		printf("%s\n", buf);
		++op;
	}
}

struct charkv {
	char *key;
	char *value;
};

static int arg2kv(struct list *list, int argc, char *argv[])
{
	int i = 0;
	struct charkv *kv = NULL;

	if (argc == 0) {
		return 0;
	}
	for (i = 0; i < argc-1; ++i) {
		kv = malloc(sizeof(struct charkv));
		if (kv == NULL) {
			return -1;
		}
		memset(kv, 0, sizeof(struct charkv));

		kv->key = argv[i];
		kv->value = argv[i+1];

		list_add_tail(list, kv);
	}

	kv = malloc(sizeof(struct charkv));
	if (kv == NULL) {
		return -1;
	}
	memset(kv, 0, sizeof(struct charkv));

	kv->key = argv[i];
	kv->value = NULL;
	list_add_tail(list, kv);

	return 0;
}

struct kv {
	char key;
	char *value;
};

struct arg_option *__search_short_option(struct arg_option *op, char ch)
{
	while (!is_option_end(op)) {
		if (op->option == ch) {
			return op;
		}

		++op;
	}

	return NULL;
}

struct arg_option *__search_long_option(struct arg_option *op, char *str)
{
	while (!is_option_end(op)) {
		if (!strcmp(str, op->long_option)) {
			return op;
		}

		++op;
	}

	return NULL;
}

static int parsing(struct list *list, struct arg_option *op, void (*parser)(char key, char *value, void *private), void *private)
{
	struct list *pos = NULL;
	struct charkv *ckv = NULL;
	struct arg_option *search = NULL;
	int len = 0;
	int skip = 0;
	char mandatory_cnt = 0;

	list_for_del(list, pos, ckv) {
		if (skip) {
			skip = 0;
			free(ckv);
			continue;
		}

		len = strlen(ckv->key);
		if (ckv->key[0] == '-') {
			if (ckv->key[1] == '-') {
				if (len > 3) {
					search = __search_long_option(op, &ckv->key[2]);
				} else {
					search = NULL;
				}
			} else {
				if (len == 2) {
					search = __search_short_option(op, ckv->key[1]);
				} else {
					search = NULL;
				}
			}
		} else { // mandatory
			search = __search_short_option(op, mandatory_cnt);
			++mandatory_cnt;
		}

		if (search == NULL) {
			fprintf(stderr, "Unrecognized option %s\n", ckv->key);
			exit(-1);
		}

		switch (search->flag) {
		case ARG_OPTION_VALUE:
			if (ckv->value == NULL) {
				fprintf(stderr, "Unrecognized option %s's value\n", ckv->key);
				exit(-1);
			}
			skip = 1;
			parser(search->option, ckv->value, private);
			break;
		case ARG_OPTION_MANDATORY:
			parser(search->option, ckv->key, private);
			break;
		case ARG_OPTION_NO_VALUE:
			parser(search->option, NULL, private);
			break;
		default:
			break;
		}
		free(ckv);
	}

	return mandatory_cnt;
}

static int __option_check(struct arg_option *op)
{
	struct arg_option *duop = NULL;
	while (!is_option_end(op)) {
		// 1. flag가 이상하다
		switch (op->flag) {
		case ARG_OPTION_VALUE:
			break;
		case ARG_OPTION_MANDATORY:
			break;
		case ARG_OPTION_NO_VALUE:
			break;
		default:
			return -1;
		}

		// 2. option이 겹친다
		duop = &op[1];
		while (!is_option_end(duop)) {
			if (op->option == duop->option) {
				fprintf(stderr, "conflict short option %d\n", op->option);
				return -1;
			}

			if (op->long_option == duop->long_option) {
				if (op->long_option != NULL) {
					fprintf(stderr, "conflict long option\n");
					return -1;
				}
			}

			++duop;
		}

		++op;
	}

	return 0;
}

int arg_parse(int argc, char *argv[], 
	      struct arg_option *op, 
	      arg_parser parser,
	      void *private)
{
	struct list list;
	int r = 0;
	list_init(&list);

	if (__option_check(op)) {
		fprintf(stderr, "check arg_option\n");
		exit(-1);
	}

	r = arg2kv(&list, argc-1, &argv[1]);
	if (r < 0) {
		fprintf(stderr, "arg memory failed\n");
		exit(-1);
	}

	return parsing(&list, op, parser, private);
}
