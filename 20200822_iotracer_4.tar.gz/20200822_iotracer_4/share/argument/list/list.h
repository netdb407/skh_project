#ifndef LIST_H_T2YUXK8T
#define LIST_H_T2YUXK8T

struct list {
	void *data;
	struct list *next, *prev;
};

int list_add(struct list *list, void *data);
void list_del(struct list *list);

#define list_merge(a, b) do { \
	(b)->prev->next = (a); \
	(b)->next->prev = (a)->prev; \
	(a)->prev->next = (b)->next; \
	(a)->prev = (b)->prev; \
	list_init(b); \
} while (0)

#define list_init(list) do { \
	(list)->next = (list); \
	(list)->prev = (list); \
	(list)->data = NULL; \
} while (0)

#define list_add_tail(list, data) list_add((list)->prev, (data))
#define list_empty(list) ((list)->next == (list))
#define list_for(list, pos, entry) for ((pos) = (list)->next, (entry) = (pos)->data; (pos) != (list); (pos) = (pos)->next, (entry) = (pos)->data)
#define __list_for(list, pos, entry) for ((entry) = (pos)->data; (pos) != (list); (pos) = (pos)->next, (entry) = (pos)->data)
#define list_for_del(list, pos, entry) for ((pos) = (list)->next, (entry) = (pos)->data; (pos) != (list); list_del(pos), (pos) = (list)->next, (entry) = (pos)->data)
#define list_reserve_for(list, pos, entry) for ((pos) = (list)->prev, (entry) = (pos)->data; (pos) != (list); (pos) = (pos)->prev, (entry) = (pos)->data)
#define list_reserve_for_del(list, pos, entry) for ((pos) = (list)->prev, (entry) = (pos)->data; (pos) != (list); list_del(pos), (pos) = (list)->prev, (entry) = (pos)->data)

#endif /* end of include guard: LIST_H_T2YUXK8T */
