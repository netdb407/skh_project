#include <stdio.h>
#include "list.h"

int main(void)
{
	struct list head1;
	struct list head2;
	struct list *pos;
	list_init(&head1);
	list_init(&head2);
	int a = 1;
	int b = 2;
	int c = 3;
	int *data;
	int d = 4;
	int e = 5;
	int f = 6;

	list_add_tail(&head1, &a);
	list_add_tail(&head1, &b);
	list_add_tail(&head1, &c);

	list_add_tail(&head2, &d);
	list_add_tail(&head2, &e);
	list_add_tail(&head2, &f);

	list_merge(&head1, &head2);

	list_for(&head1, pos, data) {
		printf("%d\n", *data);
	}

	printf("----------\n");
	list_reserve_for(&head1, pos, data) {
		printf("%d\n", *data);
	}
	
	printf("----------\n");
	list_for_del(&head1, pos, data) {
		printf("%d\n", *data);
	}

	return 0;
}
