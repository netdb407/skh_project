#include <stdio.h>
#include <stdlib.h> // atexit
#include <string.h> // strlen
#include <assert.h>

#include "arg.h"

struct arg_option op[] = {
	{'a', "add", ARG_OPTION_NO_VALUE, "add value"},
	{'d', NULL, ARG_OPTION_VALUE, "set death"},
	{'b', NULL, ARG_OPTION_NO_VALUE, "source directory"},
	{'c', NULL, ARG_OPTION_NO_VALUE, "target directory"},
	{'t', "callme", ARG_OPTION_VALUE, "target directory"},
	{'k', "kiting", ARG_OPTION_NO_VALUE, "target directory"},
	{0, "source", ARG_OPTION_MANDATORY, "source directory"},
	{0, 0, 0, 0},
};

void myparser(char key, char *value, void __attribute__((unused)) *private)
{
	printf("parser %d %s\n", key, value);
}

int main(int argc, char *argv[])
{
	arg_parse(argc, argv, op, myparser, NULL);
	arg_err(op, -1);
	
	return 0;
}
