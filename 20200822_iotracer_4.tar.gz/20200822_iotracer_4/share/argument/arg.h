#ifndef ARGUMENT_H_VQKY0YHW
#define ARGUMENT_H_VQKY0YHW

struct arg_option {
	char option;
	const char *long_option;
	int flag;
	char *help;
};

typedef void (arg_parser)(char key, char *value, void *private);

enum {ARG_OPTION_NO_VALUE = 1, ARG_OPTION_VALUE, ARG_OPTION_MANDATORY};

int arg_parse(int argc, char *argv[], 
	      struct arg_option *op, 
	      arg_parser parser,
	      void *private);
void arg_usage(struct arg_option *op);

#define arg_err(op, num) do {\
	arg_usage((op)); \
	exit(num); \
} while (0)

#define arg_err_msg(op, num, msg, ...) do {\
	fprintf(stderr, ""msg"\n", __VA_ARGS__); \
	arg_usage((op)); \
	exit(num); \
} while (0)

#endif /* end of include guard: ARGUMENT_H_VQKY0YHW */
