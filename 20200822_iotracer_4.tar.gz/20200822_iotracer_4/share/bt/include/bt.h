#ifndef BT_H_KR2AGS3U
#define BT_H_KR2AGS3U

#define BT_M 5

typedef int (*bt_cmp_fn)(void *a, void *b);
typedef void (*bt_visit_fn)(void *data, void *private);

struct bt_node {
	void *data[BT_M];
	struct bt_node *children[BT_M+1];
	int usage;
	struct bt_node *parent;
	int cache_idx;
};

struct bt {
	struct bt_node *node;
	bt_cmp_fn cmp;
};

void bt_init(struct bt *tree, bt_cmp_fn cmp);
struct bt *bt_alloc(bt_cmp_fn cmp);
void bt_free(struct bt *tree, bt_visit_fn fr, void *private);
void bt_free_default(struct bt *tree);

int bt_put(struct bt *tree, void *data);
void *bt_get(struct bt *tree, void *data);
void *bt_del(struct bt *tree, void *data);

void bt_traverse(struct bt *root, bt_visit_fn visit, void *private);

#endif /* end of include guard: BT_H_KR2AGS3U */
