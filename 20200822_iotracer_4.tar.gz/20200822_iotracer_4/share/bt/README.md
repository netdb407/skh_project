# release
1. criterion 통과
	- ./build/test/test
2. valgrind 통과
	- ./valgrind 
3. fsanitize 통과
