#!/bin/bash
set -euo pipefail

while read line
do
	if [[ "$line" == *": "*" test"* ]]; then
		g=$(cut -d: -f1 <<<$line)
	else
		t=$(cut -d' ' -f 2 <<<$line)
		valgrind --leak-check=full --show-leak-kinds=all --track-fds=yes --track-origins=yes --trace-children=yes ./build/test/test --filter=$g/$t > ${g}_$t.log 2>&1
	fi
done <<< $(./build/test/test -l)
