#include <stdio.h>
#include "queue.h"

int main(int argc, char *argv[])
{
	struct queue_head *head = queue_alloc();
	enqueue(head, (void *)1);
	enqueue(head, (void *)2);
	enqueue(head, (void *)3);

	printf("%p\n", dequeue(head));
	printf("%p\n", dequeue(head));
	printf("%p\n", dequeue(head));
	printf("%p\n", dequeue(head));
	printf("%p\n", dequeue(head));
	enqueue(head, (void *)1);
	printf("%p\n", dequeue(head));
	enqueue(head, (void *)2);
	printf("%p\n", dequeue(head));
	enqueue(head, (void *)3);
	printf("%p\n", dequeue(head));
	printf("%p\n", dequeue(head));

	queue_free(head);
	return 0;
}
