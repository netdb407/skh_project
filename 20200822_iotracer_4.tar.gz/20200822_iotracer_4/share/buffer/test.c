#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include "buffer.h"

ssize_t whandler(void *private, void *buf, size_t nbyte)
{
	return write(*(int *)private, buf, nbyte);
}

ssize_t rhandler(void *private, void *buf, size_t nbyte)
{
	return read(*(int *)private, buf, nbyte);
}

int main(void)
{
	struct buffer buf;
	int output = 0;
	int i = 0;
	int r = 0;
	int fd = 0;

	fd = open("TEST", O_RDWR|O_CREAT, 0644);
	if (fd < 0) {
		return -1;
	}

	buffer_init(&buf, 1022, whandler, &fd);
	buffer_print(&buf);

	for (i = 0; i < 258; ++i) {
		r = buffer_push(&buf, &i, sizeof(int));
		if (r < 0) {
			printf("err\n");
		}
		//buffer_print(&buf);
	}

	buffer_send(&buf);
	buffer_deinit(&buf);

	close(fd);

	fd = open("TEST", O_RDWR|O_CREAT, 0644);
	buffer_init(&buf, 1022, rhandler, &fd);
//
	for (i = 0; i < 258; ++i) {
		buffer_pop(&buf, &output, sizeof(int));
		printf("%d : %d\n", i, output);
		assert(output == i);
		buffer_print(&buf);
	}
//
//	//printf("%d\n", output);

	buffer_deinit(&buf);

	close(fd);
	return 0;
}
