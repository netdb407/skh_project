#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "vertex.h"

void *one(void *data, void __attribute__((unused))*private)
{
	int *a = data;

	return a;
}

void *two(void *data, void __attribute__((unused))*private)
{
	int *a = data;
	//pthread_t tid = pthread_self();
//	printf("\ttwo %d\n", *a);
	free(a);

	return NULL;
}

void *produce(void __attribute__((unused))*data, void *private)
{
	int *i = private;
	int *tmp = NULL;
	//sleep(1);

//	if (data == VERTEX_QUIT) {
//		return VERTEX_QUIT;
//	}
	if (*i > 10000000) {
	//if (*i > 100000) {
		return VERTEX_QUIT;
	}

	tmp = malloc(sizeof(int));
	*tmp = *i;

	*i = *i+1;

	return tmp;
}

int main(void)
{
	int i = 0;
	int j = 0;

	struct vertex *producer1 = vertices(0, produce, &i);
	struct vertex *producer2 = vertices(0, produce, &j);
	struct vertex *merge = vertices(20, two, NULL);

	edge(producer1, merge);
	edge(producer2, merge);

	vertex_start(producer1);
	vertex_start(producer2);

	vertex_stop(producer1);
	vertex_stop(producer2);

	printf("%d %d\n", i, j);

	return 0;
}
