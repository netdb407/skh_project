#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>
#include <sys/stat.h>

#include "debug.h"
#include "file.h"

#define LOC "output/game"

int main(void)
{
	struct file *f = NULL;
#if 0
	char buf[3] = "";
	int try = 0;
	f = file_open(LOC, FILE_READ, 11);
	while (file_read(f, buf, 2) > 0) {
		CHECK(!memcmp(buf, "12", 2));
		++try;
	}

	CHECK(try == 1024);
#else
	int i = 0;
	int try = 1024;
	f = file_open(LOC, FILE_WRITE, 11);

	for (i = 0; i < try; ++i) {
		file_write(f, "12", 2);
	}
#endif

	file_close(f);

	return 0;
}
