#ifndef FILE_NAME_H_1WCFRD2I
#define FILE_NAME_H_1WCFRD2I

#define TRACE_FILE "trace.bin"
#define DMDU_FILE "dmdu.bin"
#define LOG_FILE "iotrace.log"
#define ERR_FILE "iotrace.err"
#define THR_FILE "threshold.bin"
#define PROCESS_FILE "process.raw"

#endif /* end of include guard: FILE_NAME_H_1WCFRD2I */
