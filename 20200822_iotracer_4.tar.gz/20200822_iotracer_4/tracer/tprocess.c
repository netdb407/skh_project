#include <stdio.h>
#include <signal.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/connector.h>
#include <linux/cn_proc.h>
#include <signal.h>
#include <errno.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <fcntl.h>
#include <proc/alloc.h>
#include <proc/readproc.h>
#include <proc/sysinfo.h>
#include <proc/version.h>
#include <proc/wchan.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <locale.h>
#include <stdlib.h>
#include <stdio.h>

#include "vertex/vertex.h"
#include "buffer/buffer.h"
#include "store.h"

struct m {
	struct cn_msg cn_msg;
	enum proc_cn_mcast_op cn_mcast;
}__attribute__ ((__packed__));

struct m_message {
	struct nlmsghdr nl_hdr;
	struct m m;
}__attribute__ ((aligned(NLMSG_ALIGNTO)));

struct h {
	struct cn_msg cn_msg;
	struct proc_event proc_ev;
}__attribute__ ((__packed__));

struct h_message {
	struct nlmsghdr nl_hdr;
	struct h h;
}__attribute__ ((aligned(NLMSG_ALIGNTO)));

static int read_unvectored(char *restrict const dst, unsigned sz, const char* whom, const char *what, char sep) 
{
	char path[PROCPATHLEN];
	int fd, len;
	unsigned n = 0;

	if(sz <= 0) return 0;
	if(sz >= INT_MAX) sz = INT_MAX-1;
	dst[0] = '\0';

	len = snprintf(path, sizeof(path), "%s/%s", whom, what);
	if(len <= 0 || (size_t)len >= sizeof(path)) return 0;
	fd = open(path, O_RDONLY);
	if(fd==-1) return 0;

	for(;;){
		ssize_t r = read(fd,dst+n,sz-n);
		if(r==-1){
			if(errno==EINTR) continue;
			break;
		}
		if(r<=0) break;  // EOF
		n += r;
		if(n==sz) {      // filled the buffer
			--n;         // make room for '\0'
			break;
		}
	}
	close(fd);
	if(n){
		unsigned i = n;
		while(i && dst[i-1]=='\0') --i; // skip trailing zeroes
		while(i--)
			if(dst[i]=='\n' || dst[i]=='\0') dst[i]=sep;
		if(dst[n-1]==' ') dst[n-1]='\0';
	}
	dst[n] = '\0';
	return n;
}

static int __read_cmdline(char *restrict const dst, unsigned sz, unsigned pid) 
{
	char path[PROCPATHLEN];
	snprintf(path, sizeof(path), "/proc/%u", pid);
	return read_unvectored(dst, sz, path, "cmdline", ' ');
}

static int read_comm(char *restrict const dst, unsigned sz, unsigned pid) {
	char path[PROCPATHLEN];
	snprintf(path, sizeof(path), "/proc/%u", pid);
	return read_unvectored(dst, sz, path, "comm", ' ');
}

struct pid { // same with parser/process_vtx.c
	uint64_t time;
	int tgid; // PID
	int pid; // TID
};

/*
 * connect to netlink
 * returns netlink socket, or -1 on error
 */
static int nl_connect()
{
	int rc;
	int nl_sock;
	struct sockaddr_nl sa_nl;

	nl_sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_CONNECTOR);
	if (nl_sock == -1) {
		perror("socket");
		return -1;
	}

	sa_nl.nl_family = AF_NETLINK;
	sa_nl.nl_groups = CN_IDX_PROC;
	sa_nl.nl_pid = getpid();

	rc = bind(nl_sock, (struct sockaddr *)&sa_nl, sizeof(sa_nl));
	if (rc == -1) {
		perror("bind");
		close(nl_sock);
		return -1;
	}

	return nl_sock;
}

/*
 * subscribe on proc events (process notifications)
 */
static int set_proc_ev_listen(int nl_sock, bool enable)
{
	int rc;
	struct m_message nlcn_msg = {0};

	memset(&nlcn_msg, 0, sizeof(nlcn_msg));
	nlcn_msg.nl_hdr.nlmsg_len = sizeof(nlcn_msg);
	nlcn_msg.nl_hdr.nlmsg_pid = getpid();
	nlcn_msg.nl_hdr.nlmsg_type = NLMSG_DONE;

	nlcn_msg.m.cn_msg.id.idx = CN_IDX_PROC;
	nlcn_msg.m.cn_msg.id.val = CN_VAL_PROC;
	nlcn_msg.m.cn_msg.len = sizeof(enum proc_cn_mcast_op);

	nlcn_msg.m.cn_mcast = enable ? PROC_CN_MCAST_LISTEN : PROC_CN_MCAST_IGNORE;

	rc = send(nl_sock, &nlcn_msg, sizeof(nlcn_msg), 0);
	if (rc == -1) {
		perror("netlink send");
		return -1;
	}

	return 0;
}

int ps_connect(void)
{
	int nl_sock = 0;
	int rc = 0;

	printf("mypid : %d\n", getpid());

	nl_sock = nl_connect();
	if (nl_sock == -1) {
		return -1;
	}

	rc = set_proc_ev_listen(nl_sock, true);
	if (rc == -1) {
		close(nl_sock);
		return -1;
	}

	return nl_sock;
}

void ps_disconnect(int sock)
{
	set_proc_ev_listen(sock, false);
	close(sock);
}

#define SET_IF_DESIRED(x,y) do{  if(x) *(x) = (y); }while(0)

struct ps_conf {
	int sock;
	struct vertex *wvtx;
	pid_t mypid;
//	struct buffer buffer;
//	int fd;
//	time_t startup;
};

static void *ps_handle(void *data, void *private)
{
	struct ps_conf *conf = private;
	char buffer[1024];
	int rc;
	struct h_message nlcn_msg = {0};
	struct pid *pid = NULL;
	int len = 0;
	int *plen = NULL;
	char *pchar = NULL;

	if (data == VERTEX_QUIT) {
		return VERTEX_QUIT;
	}

	rc = recv(conf->sock, &nlcn_msg, sizeof(nlcn_msg), 0);
	if (rc == 0) {
		return NULL;
	} else if (rc == -1) {
		if (errno == EINTR) {
			return NULL;
		}
		perror("netlink recv");
		return VERTEX_QUIT;
	}

	switch (nlcn_msg.h.proc_ev.what) {
	case PROC_EVENT_NONE:
		printf("set mcast listen ok\n");
		break;
	case PROC_EVENT_FORK:
		if (nlcn_msg.h.proc_ev.event_data.fork.child_tgid == conf->mypid) {
			break;
		}
		rc = __read_cmdline(buffer, 1024, nlcn_msg.h.proc_ev.event_data.fork.child_tgid);
		if (rc < 1) {
			buffer[0] = '[';
			buffer[1] = '<';
			buffer[2] = '<';
			read_comm(&buffer[3], 1021, nlcn_msg.h.proc_ev.event_data.fork.child_tgid);
		}

		len = strlen(buffer);
		pid = store_alloc(STORE_PROCESS, 
				  sizeof(struct pid) + sizeof(int) + len);
		pid->pid = nlcn_msg.h.proc_ev.event_data.fork.child_pid;
		pid->tgid = nlcn_msg.h.proc_ev.event_data.fork.child_tgid;
		pid->time = nlcn_msg.h.proc_ev.timestamp_ns;

		plen = (int *)&pid[1];
		*plen = len;
		pchar = (char *)&plen[1];
		memcpy(pchar, buffer, len);

		vertex_put(conf->wvtx, pid);
		break;
	case PROC_EVENT_EXEC:
		if (nlcn_msg.h.proc_ev.event_data.exec.process_pid == conf->mypid) {
			break;
		}
		rc = __read_cmdline(buffer, 1024, nlcn_msg.h.proc_ev.event_data.exec.process_tgid);
		if (rc < 1) {
			buffer[0] = '[';
			buffer[1] = '<';
			buffer[2] = '<';
			read_comm(&buffer[3], 1021, nlcn_msg.h.proc_ev.event_data.exec.process_tgid);
		}

		len = strlen(buffer);
		pid = store_alloc(STORE_PROCESS, 
				  sizeof(struct pid) + sizeof(int) + len);
		pid->pid = nlcn_msg.h.proc_ev.event_data.fork.child_pid;
		pid->tgid = nlcn_msg.h.proc_ev.event_data.fork.child_tgid;
		pid->time = nlcn_msg.h.proc_ev.timestamp_ns;

		plen = (int *)&pid[1];
		*plen = len;
		pchar = (char *)&plen[1];
		memcpy(pchar, buffer, len);

		vertex_put(conf->wvtx, pid);
		break;
	default:
		break;
	}

	return NULL;
}

struct vertex *processor = NULL;
struct ps_conf ps_conf = {0};

int tprocess_start(struct vertex *wvtx)
{
	ps_conf.wvtx = wvtx;
	ps_conf.mypid = getpid();
	//buffer_init(&ps_conf.buffer, 4096, whandler, &ps_conf.fd);

	ps_conf.sock = ps_connect();
	if (ps_conf.sock < 0) {
		return -1;
	}

	processor = vertices(0, ps_handle, &ps_conf);
	if (processor == NULL) {
		ps_disconnect(ps_conf.sock);
		return -1;
	}

	vertex_start(processor);

	return 0;
}

void tprocess_stop()
{
	vertex_stop(processor);
	ps_disconnect(ps_conf.sock);
//	buffer_send(&ps_conf.buffer);
//	buffer_deinit(&ps_conf.buffer);
//	close(ps_conf.fd);
}
