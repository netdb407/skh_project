#ifndef __COMMON_DEBUG__
#define __COMMON_DEBUG__

#define BRK()  fprintf(stderr, "%s(%d)\n", __func__ , __LINE__)
#if 1
#define DEBUG(msg, ...)  fprintf(stderr, "%s(%d) : "msg"\n", __func__ , __LINE__, __VA_ARGS__)
#else
#define DEBUG(msg, ...)
#endif

#include <stdlib.h> // exit
#define CHECK(cond) do { \
	if (!(cond)) { \
		fprintf(stderr, "[%s:%d] %s condition %s failed\n", __FILE__, __LINE__, __func__, #cond); \
		exit(-1); \
	} \
} while(0)

#include <errno.h> // errno
#include <string.h> // strerror
#define CHECK_ERR(cond) do { \
	if (!(cond)) { \
		fprintf(stderr, "[%s:%d] %s condition %s failed : %s\n", __FILE__, __LINE__, __func__, #cond, strerror(errno)); \
		exit(-1); \
	} \
} while(0)

#endif
