#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <inttypes.h>

#include "debug.h"
#include "../share/event.h"

char *types[] = {
	"BLOCK_BIO_BACKMERGE",
	"BLOCK_BIO_COMPLETE",
	"BLOCK_BIO_QUEUE",
	"BLOCK_DIRTY_BUFFER",
	"BLOCK_PLUG",
	"BLOCK_RQ_INSERT",
	"BLOCK_RQ_REMAP",
	"BLOCK_SLEEPRQ",
	"BLOCK_TOUCH_BUFFER",
	"BLOCK_BIO_BOUNCE",
	"BLOCK_BIO_FRONTMERGE",
	"BLOCK_BIO_REMAP",
	"BLOCK_GETRQ",
	"BLOCK_RQ_COMPLETE",
	"BLOCK_RQ_ISSUE",
	"BLOCK_RQ_REQUEUE",
	"BLOCK_SPLIT",
	"BLOCK_UNPLUG",
	"VFS_WRITE_START",
	"VFS_WRITE_END"
};

int main(void)
{
	int fd = open("log.log",  O_RDONLY);
	CHECK_ERR(fd > 0);

	struct event ev;


	while (read(fd, &ev, sizeof(struct event)) == sizeof(struct event)) {
		printf("|%18.9f|%-20s|%"PRIu64"|%"PRIu64"|%10"PRIu64"|%11u\n",
		       ev.time/1000000000.0, types[ev.type-1], /*event.cpu, */ev.ptid>>32, ev.ptid&0xFFFFFFFF, ev.off, ev.len);
	}

	
	return 0;
}
