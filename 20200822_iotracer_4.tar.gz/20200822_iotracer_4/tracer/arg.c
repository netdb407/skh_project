#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/sysmacros.h>
#include <stdlib.h>
#include <blkid/blkid.h>
#include <time.h>

#include "arg.h"
#include "argument/arg.h"
#include "file_name.h"
#include "file/file.h"

#define _4MiB (4*1024*1024)

struct arg_option ops[] = {
	{'o', "output", ARG_OPTION_VALUE, "log for tracing data"},
	{'m', "dm", ARG_OPTION_VALUE, "skhynix device manager path"},
	{'d', "disable_dm", ARG_OPTION_NO_VALUE, "disable skhynix device manager"},
	{'i', "interval", ARG_OPTION_VALUE, "device manager interval"},
	{'D', "daemon", ARG_OPTION_NO_VALUE, "daemonize"},
	{'b', "buffer", ARG_OPTION_VALUE, "buffer size for file write"},
	{'p', "parse_size", ARG_OPTION_VALUE, "parse byte for part parse"},
	{'w', "parse_window", ARG_OPTION_VALUE, "parse window for part parse"},
	{'t', "parse_output", ARG_OPTION_VALUE, "parse window for part parse"},
	{0, "watch directory", ARG_OPTION_MANDATORY, "directory to track"},
	{0, 0, 0, 0},
};

static void setup(void *private)
{
	struct conf *conf = private;
	memset(conf, 0, sizeof(struct conf));

	conf->buffer_size = 4096;
	conf->interval_dfdevice = 60;
	conf->device_manager_path = "/usr/bin/drive-manager";
}

void conf_close(void *private)
{
	struct conf *conf = private;
	fclose(conf->iotrace_file);
	free(conf->watch_directory);
	free(conf->whole_device);
}

static dev_t ____get_devno(char *path)
{
	dev_t dev = 0;
	struct stat st;
	char *name = NULL;
	blkid_probe pr = NULL;

	if (stat(path, &st) < 0) {
		printf("%s\n", path);
		perror("stat");
		return 0;
	}

	name = blkid_devno_to_devname(st.st_dev);
	pr = blkid_new_probe_from_filename(name);
	free(name);
	dev = blkid_probe_get_wholedisk_devno(pr);
	blkid_free_probe(pr);

	return dev;
}

static int __create_log_directory(char *value, void *private)
{
	struct conf *conf = private;
	char path[PATH_MAX];
	struct stat st;

	if (stat(value, &st) < 0) {
		if (errno == ENOENT) {
			int r = mkdir(value, 0755);
			if (r < 0) {
				fprintf(stderr, "%s directory create failed\n", value);
				return -1;
			}

			if (stat(value, &st) < 0) {
				fprintf(stderr, "%s stat failed\n", value);
				return -1;
			}

		} else {
			fprintf(stderr, "%s stat failed\n", value);
			return -1;
		}
	}

	conf->log_dev = ____get_devno(value);
	if (conf->log_dev == 0) {
		fprintf(stderr, "dev failed\n");
		return -1;
	}


	if (!S_ISDIR(st.st_mode)) {
		fprintf(stderr, "%s is not directory\n", value);
		return -1;
	}

	sprintf(path, "%s/%s", value, LOG_FILE);
	conf->iotrace_file = fopen(path, "w");
	if (conf->iotrace_file == NULL) {
		fprintf(stderr, "%s file open failed\n", path);
		return -1;
	}

	return 0;
}

static void __watch_directory(char *value, void *private)
{
	struct conf *conf = private;

	dev_t dev = ____get_devno(value);
	if (dev == 0) {
		fprintf(stderr, "dev failed\n");
		arg_err(ops, ERR_WATCH_NOT_FOUND);
	}

	conf->watch_directory = strdup(value);
	conf->dev = dev;
	conf->whole_device = blkid_devno_to_devname(dev);
	if (!conf->whole_device) {
		fprintf(stderr, "whole device name cannot get\n");
		arg_err(ops, ERR_WATCH_NOT_FOUND);
	}
}

static int __str_to_int(char *str)
{
	int ret = 0;
	char *tmp = NULL;

	ret = strtol(str, &tmp, 10);
	if (*tmp) {
		arg_err(ops, -1);
	}

	return ret;
}

static void parser(char key, char *value, void *private)
{
	struct conf *conf = private;
	int r = 0;
	switch (key) {
	case 'o': 
		conf->output = value;
		r = __create_log_directory(value, conf);
		if (r < 0) {
			arg_err(ops, ERR_CREATE_LOG_FAILED);
		}
		break;
	case 'm':
		conf->device_manager_path = value;
		break;
	case 'i':
		conf->interval_dfdevice = __str_to_int(value);
		break;
	case 'D':
		conf->daemon = 1;
		break;
	case 'd':
		conf->disable_device_manager = 1;
		break;
	case 'b':
		conf->buffer_size = __str_to_int(value);
		break;
	case 'p':
		conf->parse_byte = __str_to_int(value);
		break;
	case 'w':
		conf->parse_window = __str_to_int(value);
		break;
	case 't':
		conf->parse_output = value;
		break;
	case 0: 
		__watch_directory(value, conf);
		break;
	default:
		break;
	}
}

int conf_parser(int argc, char *argv[], void *private)
{
	struct conf *conf = private;
	int r = 0;
	setup(private);
	int nr_man = arg_parse(argc, argv, ops, parser, private);
	if (conf->iotrace_file == NULL) {
		conf->output = "output";
		r = __create_log_directory("output", conf);
		if (r < 0) {
			fprintf(stderr, "create log file failed\n");
			arg_err(ops, ERR_CREATE_LOG_FAILED);
		}
	}

	if (nr_man != 1) {
		//		LOG(conf, "start failed, check program arguments");
		arg_err(ops, -1);
	}

	if (conf->log_dev == conf->dev) {
		//LOG(conf, "start failed, output directory and trace device are same");
		arg_err(ops, ERR_DEV_CONFLICT);
	}

	if (!conf->disable_device_manager) {
		struct stat st;
		if (stat(conf->device_manager_path, &st) < 0) {
			//	LOG(conf, "start failed, device manager is not found");
			arg_err(ops, ERR_DM_NOT_FOUND);
		}

		if (!(st.st_mode & (S_IXUSR|S_IXGRP|S_IXOTH))) {
			//	LOG(conf, "start failed, device manager is not excutable");
			arg_err(ops, ERR_DM_NOT_FOUND);
		}
	}

	if (conf->parse_byte > 0) {
		if (conf->parse_output == NULL) {
			conf->parse_output = conf->output;
		}

		if (conf->parse_window == 0) {
			conf->parse_window = conf->interval_dfdevice;
		}
	}

	return 0;
}
