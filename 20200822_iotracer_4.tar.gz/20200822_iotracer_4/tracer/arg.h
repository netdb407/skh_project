#ifndef ARG_H_QZYXCBR3
#define ARG_H_QZYXCBR3

#include <sys/types.h>
#include <stdio.h>

#define ERR_DEV_CONFLICT (100)
#define ERR_CREATE_LOG_FAILED (101)
#define ERR_DM_NOT_FOUND (102)
#define ERR_DM_NOT_SUPPORT (103)
#define ERR_WATCH_NOT_FOUND (104)

struct conf {
	FILE *iotrace_file;
	char *watch_directory;
	dev_t dev;
	dev_t log_dev;
	int interval_dfdevice;
	char *device_manager_path;
	char *whole_device;
	int daemon;
	int disable_device_manager;
	int buffer_size;
	char *output;

	// for part parse
	int parse_byte;
	int parse_window;
	char *parse_output;
};

int conf_parser(int argc, char *argv[], void *private);
void conf_close(void *private);


#endif /* end of include guard: ARG_H_QZYXCBR3 */
