#!/usr/bin/env python

import pandas
from matplotlib import pyplot
import argparse
import datetime
from pandas.plotting import register_matplotlib_converters
import matplotlib.dates as mdates
import matplotlib
register_matplotlib_converters()
matplotlib.rcParams.update({'font.size': 18})

parser = argparse.ArgumentParser()
parser.add_argument('ycbs')
parser.add_argument('trace')
parser.add_argument('dmdu')

args = parser.parse_args()

# TITLE=["Number of IO","Size of IO","Latency","Kernel Time","Driver Time","Device Time"]

def dmdu(dmdu, start_idx):
    series = pandas.read_csv(dmdu)
    PLOT_DATE = list(map(datetime.datetime.fromtimestamp, series["time"]))
    print("dmdu", PLOT_DATE[-1])

    TITLE=["delta_disk_usage","waf","gc","nand_write"]
    length = len(TITLE)
    for i in range(length):
        original = list(series[TITLE[i]])
        data = []
        s = 0
        for item in original:
            s = s+item
            data.append(s)
        series["acc_"+TITLE[i]] = data

    TITLE=["delta_disk_usage","acc_delta_disk_usage", "waf", "acc_waf" ,"gc", "acc_gc", "nand_write", "acc_nand_write"]
    length = len(TITLE)
    for i in range(length):
        ax[i+start_idx].plot(PLOT_DATE, series[TITLE[i]], 'b-')
        ax[i+start_idx].set_ylabel(TITLE[i])

def ycbs(ycbs):
    fig, ax = pyplot.subplots(4, 1)
    gr = pandas.read_csv(ycbs).groupby("OPERATION")

    TITLE=["READ", "INSERT"]
    length = len(TITLE)
    try:
        for idx, val in enumerate(TITLE):
            series = gr.get_group(val)
            date = series["TIME"]/1000
            ax[idx*2].plot(date, series["LATENCY"], 'b-', color="C0")
            ax[idx*2].set_ylabel(val)
            ax[idx*2].xaxis.set_visible(False)
            ax[idx*2].yaxis.set_label_position("right")
            ax[idx*2+1].plot(date, series["WHAT"]/10, 'b-', color="C0")
            ax[idx*2+1].set_ylabel(val+" ops")
            ax[idx*2+1].xaxis.set_visible(False)
            ax[idx*2+1].yaxis.set_label_position("right")
    except:
        pass
    ax[-1].xaxis.set_visible(True)
    fig.set_size_inches(16, 9)
    fig.tight_layout()
    fig.savefig("01.ycsb.png")

ycbs(args.ycbs)
#trace(args.trace, 3)
#dmdu(args.dmdu, 9)

window_series = pandas.read_csv(args.trace)
window_series["IOPS"] = window_series["Number of IO"]/10
window_series["MBPS"] = window_series["Size of IO"]/1024/1024/10
window_date = window_series["Window Time"]

dmdu_series = pandas.read_csv(args.dmdu)

original = dmdu_series["delta_disk_usage"]
data = []
s = 0
for item in original:
    s = s+item
    data.append(s)
dmdu_series["acc_delta_disk_usage"] = data
dmdu_series["acc_delta_disk_usage"] = dmdu_series["acc_delta_disk_usage"]/1024/1024/1024/1024/2
print(dmdu_series["acc_delta_disk_usage"])

dmdu_date = dmdu_series["time"]

def set_axis(ax, label, date, series, color="C0"):
    ax.plot(date, series, 'b-', color=color)
    ax.set_ylabel(label)
    ax.xaxis.set_visible(False)
    ax.yaxis.set_label_position("right")

fig, ax = pyplot.subplots(3, 1)
set_axis(ax[0], "Latency", window_date, window_series["Latency"])
set_axis(ax[1], "IOPS", window_date, window_series["IOPS"])
set_axis(ax[2], "MBPS", window_date, window_series["MBPS"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("02.latency_iops_mbps.png")

fig, ax = pyplot.subplots(1, 1)
set_axis(ax, "disk usage", dmdu_date, dmdu_series["acc_delta_disk_usage"])
ax.set_ylim(top=1, bottom=0)
ax.xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("03.disk_usage.png")

fig, ax = pyplot.subplots(3, 1)
set_axis(ax[0], "gc", dmdu_date, dmdu_series["gc"])
set_axis(ax[1], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[2], "nand_write", dmdu_date, dmdu_series["nand_write"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("04.gc_waf_nandwrite.png")

fig, ax = pyplot.subplots(2, 1)
set_axis(ax[0], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[1], "IOPS", window_date, window_series["IOPS"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("05.waf_iops.png")

fig, ax = pyplot.subplots(2, 1)
set_axis(ax[0], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[1], "MBPS", window_date, window_series["MBPS"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("06.waf_mbps.png")

fig, ax = pyplot.subplots(2, 1)
set_axis(ax[0], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[1], "Latency", window_date, window_series["Latency"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("07.waf_latency.png")

fig, ax = pyplot.subplots(2, 1)
set_axis(ax[0], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[1], "Kernel Time", window_date, window_series["Kernel Time"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("08.waf_kernel.png")

fig, ax = pyplot.subplots(2, 1)
set_axis(ax[0], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[1], "Driver Time", window_date, window_series["Driver Time"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("09.waf_driver.png")

fig, ax = pyplot.subplots(2, 1)
set_axis(ax[0], "waf", dmdu_date, dmdu_series["waf"])
set_axis(ax[1], "Device Time", window_date, window_series["Device Time"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("10.waf_device.png")

gr = pandas.read_csv(args.ycbs).groupby("OPERATION")
series = gr.get_group("READ")
date = series["TIME"]/1000

fig, ax = pyplot.subplots(3, 1)
set_axis(ax[0], "READ", date, series["LATENCY"])
set_axis(ax[1], "READ ops", date, series["WHAT"]/10)
set_axis(ax[2], "Latency", window_date, window_series["Latency"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("11.read_latency.png")

series = gr.get_group("INSERT")
date = series["TIME"]/1000

fig, ax = pyplot.subplots(3, 1)
set_axis(ax[0], "INSERT", date, series["LATENCY"])
set_axis(ax[1], "INSERT ops", date, series["WHAT"]/10)
set_axis(ax[2], "Latency", window_date, window_series["Latency"])
ax[-1].xaxis.set_visible(True)
fig.set_size_inches(16, 9)
fig.tight_layout()
fig.savefig("12.insert_latency.png")
