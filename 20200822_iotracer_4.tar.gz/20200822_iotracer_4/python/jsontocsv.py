#!/usr/bin/python

import pandas
import csv
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('source')
parser.add_argument('target')

args = parser.parse_args()

df = pandas.read_json(args.source)
df = df['records']
print(df[0].keys())

go = open(args.target, 'w')
writer = csv.DictWriter(go, fieldnames=df[0].keys()) 
writer.writeheader();

for line in df:
    #p = pandas.DataFrame.from_dict(line)
    writer.writerow(line)

#df.to_csv("go.csv")
