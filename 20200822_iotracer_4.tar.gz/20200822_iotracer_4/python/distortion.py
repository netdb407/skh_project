#!/usr/bin/env python
import ctypes as ct
from bcc import BPF
import sys # for exit
import os

class Data(ct.Structure):
    _fields_ = [
        ("type", ct.c_int),
        ("time", ct.c_uint64),
        ("dev", ct.c_int),
        ("pid", ct.c_uint64),
        ("off", ct.c_int),
        ("len", ct.c_int)
    ]

if not os.geteuid() == 0:
    sys.exit("run app as root");


file_content = """
#include <uapi/linux/ptrace.h>
#include <uapi/linux/uio.h>
#include <linux/mount.h>
#include <linux/fs.h>
#include <linux/uio.h>

enum {
    BLOCK_BIO_BACKMERGE = 1,
    BLOCK_BIO_COMPLETE,
    BLOCK_BIO_QUEUE,
    BLOCK_DIRTY_BUFFER,
    BLOCK_PLUG,
    BLOCK_RQ_INSERT,
    BLOCK_RQ_REMAP,
    BLOCK_SLEEPRQ,
    BLOCK_TOUCH_BUFFER,
    BLOCK_BIO_BOUNCE,
    BLOCK_BIO_FRONTMERGE,
    BLOCK_BIO_REMAP,
    BLOCK_GETRQ,
    BLOCK_RQ_COMPLETE,
    BLOCK_RQ_ISSUE,
    BLOCK_RQ_REQUEUE,
    BLOCK_SPLIT,
    BLOCK_UNPLUG,
    VFS_WRITE_START,
    VFS_WRITE_END,
    NVME_SQ,
    NVME_COMPLETE_RQ,
    VFS_WRITE,
    VFS_WRITEV,
    VFS_READ,
    VFS_READV,
    VFS_MMAP
};

BPF_PERF_OUTPUT(events);

struct event {
    int type;
    uint64_t time;
    int dev;
    uint64_t pid;
    int off;
    int len;
};

static inline int filter_dev(int dev)
{
    int major = dev>>20;
    int minor = dev&((1<<20)-1);

    if (major == MAJOR_VALUE && minor == MINOR_VALUE) {
        return 0;
    }

    return 1; // filter this
}

TRACEPOINT_PROBE(block, block_bio_remap) {
    struct event ev = {.type = BLOCK_BIO_REMAP};
    ev.time = bpf_ktime_get_ns();
    ev.dev = args->dev;
    if(filter_dev(ev.dev)) {
	    return 0;
    }
    ev.pid = bpf_get_current_pid_tgid();
    ev.off = args->sector;
    ev.len = args->nr_sector;

    events.perf_submit(args, &ev, sizeof(struct event));
    return 0;
}

int do_sync(struct pt_regs *ctx,
            struct file *file, unsigned long addr,
            unsigned long len, unsigned long prot,
            unsigned long flag, unsigned long pgoff)
{
    struct event ev = {.type = VFS_MMAP};
    struct inode *inode = file->f_mapping->host;
    mode_t mode;

    if (inode == NULL) {
        return 0;
    }

    mode = inode->i_mode;
    if (!S_ISREG(mode)) {
        return 0;
    }

    ev.time = bpf_ktime_get_ns();
    ev.dev = inode->i_ino;
    ev.pid = bpf_get_current_pid_tgid();
    ev.off = pgoff;
    ev.len = len;

    events.perf_submit(ctx, &ev, sizeof(struct event));
    return 0;
}

int do_write(struct pt_regs *ctx,
             struct file *file, const char __user *buf,
             size_t count, loff_t *pos)
{
    mode_t mode;
    struct event ev = {.type=VFS_WRITE};

    if (file->f_inode == NULL) {
        return 0;
    }

    mode = file->f_inode->i_mode;
    if (!S_ISREG(mode)) {
        return 0;
    }

    ev.time = bpf_ktime_get_ns();
    ev.dev = file->f_inode->i_ino;
    ev.pid = bpf_get_current_pid_tgid();
    ev.off = *pos;
    ev.len = count;

    events.perf_submit(ctx, &ev, sizeof(struct event));
    return 0;
}

int do_read(struct pt_regs *ctx,
            struct file *file, const char __user *buf,
            size_t count, loff_t *pos)
{
    mode_t mode;
    struct event ev = {.type=VFS_READ};

    if (file->f_inode == NULL) {
        return 0;
    }

    mode = file->f_inode->i_mode;
    if (!S_ISREG(mode)) {
        return 0;
    }

    ev.time = bpf_ktime_get_ns();
    ev.dev = file->f_inode->i_ino;
    ev.pid = bpf_get_current_pid_tgid();
    ev.off = *pos;
    ev.len = count;

    events.perf_submit(ctx, &ev, sizeof(struct event));
    return 0;
}

int do_writev(struct pt_regs *ctx,
              struct file *file, struct iov_iter *iter,
              loff_t *pos, rwf_t flags)
{
    mode_t mode;
    struct event ev = {.type=VFS_WRITEV};

    if (file->f_inode == NULL) {
        return 0;
    }

    mode = file->f_inode->i_mode;
    if (!S_ISREG(mode)) {
        return 0;
    }

    ev.time = bpf_ktime_get_ns();
    ev.dev = file->f_inode->i_ino;
    ev.pid = bpf_get_current_pid_tgid();
    ev.off = *pos;
    ev.len = iter->count;

    events.perf_submit(ctx, &ev, sizeof(struct event));
    return 0;
}

int do_readv(struct pt_regs *ctx,
             struct file *file, struct iov_iter *iter,
             loff_t *pos, rwf_t flags)
{
    mode_t mode;
    struct event ev = {.type=VFS_READV};

    if (file->f_inode == NULL) {
        return 0;
    }

    mode = file->f_inode->i_mode;
    if (!S_ISREG(mode)) {
        return 0;
    }

    ev.time = bpf_ktime_get_ns();
    ev.dev = file->f_inode->i_ino;
    ev.pid = bpf_get_current_pid_tgid();
    ev.off = *pos;
    ev.len = iter->count;

    events.perf_submit(ctx, &ev, sizeof(struct event));
    return 0;
}
"""

file_content = file_content.replace("MAJOR_VALUE", "8");
file_content = file_content.replace("MINOR_VALUE", "0");
b = BPF(text=file_content)

EVENT_TYPE = {
        0:'unknown',
        1:'BLOCK_BIO_BACKMERGE',
        2:'BLOCK_BIO_COMPLETE',
        3:'BLOCK_BIO_QUEUE',
        4:'BLOCK_DIRTY_BUFFER',
        5:'BLOCK_PLUG',
        6:'BLOCK_RQ_INSERT',
        7:'BLOCK_RQ_REMAP',
        8:'BLOCK_SLEEPRQ',
        9:'BLOCK_TOUCH_BUFFER',
        10:'BLOCK_BIO_BOUNCE',
        11:'BLOCK_BIO_FRONTMERGE',
        12:'BLOCK_BIO_REMAP',
        13:'BLOCK_GETRQ',
        14:'BLOCK_RQ_COMPLETE',
        15:'BLOCK_RQ_ISSUE',
        16:'BLOCK_RQ_REQUEUE',
        17:'BLOCK_SPLIT',
        18:'BLOCK_UNPLUG',
        19:'VFS_WRITE_START',
        20:'VFS_WRITE_END',
        23:"VFS_WRITE",
        24:"VFS_WRITEV",
        25:"VFS_READ",
        26:"VFS_READV",
        27:"VFS_MMAP"
        }

b.attach_kprobe(event="do_iter_write", fn_name="do_writev")
b.attach_kprobe(event="__vfs_write", fn_name="do_write")
b.attach_kprobe(event="do_iter_read", fn_name="do_readv")
b.attach_kprobe(event="__vfs_read", fn_name="do_read")
b.attach_kprobe(event="vm_mmap_pgoff", fn_name="do_sync")

mypid = os.getpid()

vfs = 0
block = 0

def printf(fmt, *args):
    sys.stdout.write(fmt % args)

def print_event(cpu, data, size):
    global vfs, block
    event = ct.cast(data, ct.POINTER(Data)).contents
    if (event.pid>>32) == mypid:
        return

    event.cpu = cpu;
    event.sec = event.time / 1000000000;

    if event.type == 12:
        printf("|%18.9f|%-20s|%3d|%5d|%5d|%5d|%5d|%10d|%11d|\n", event.sec, EVENT_TYPE[event.type], event.cpu, event.pid>>32, event.pid&0xFFFFFFFF, event.dev>>20, event.dev&((1<<20)-1), event.off, event.len);
        block = block + event.len*512
    else :
        printf("|%18.9f|%-20s|%3d|%5d|%5d|%5d|%10d|%11d|\n", event.sec, EVENT_TYPE[event.type], event.cpu, event.pid>>32, event.pid&0xFFFFFFFF, event.dev, event.off, event.len);
        vfs = vfs + event.len


b["events"].open_perf_buffer(print_event, page_cnt=1024*64)
while 1:
    try:
        b.perf_buffer_poll()
    except KeyboardInterrupt:
        break

print("vfs : " + str(vfs) + " block : " + str(block))
