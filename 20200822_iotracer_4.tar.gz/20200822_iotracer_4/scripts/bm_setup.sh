#!/bin/bash

JQ="jq -r"

json=""
while read line
do
	json+="$line"
done

ssh-keygen -N '' -f ~/.ssh/id_rsa <<< n

nr=$(echo "$json" | $JQ '.meta.hostnames | length')

for (( i = 0; i < $nr; i++ )); do
	host=$(echo "$json" | $JQ .meta.hostnames[$i].hostname)
	ssh-copy-id root@$host
done
