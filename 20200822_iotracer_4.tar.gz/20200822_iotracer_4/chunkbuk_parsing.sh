#!/bin/bash
set -euo pipefail

PATH=/home/biosvos/xfs/facebook
RID=159

IP_F=193
IP=203.255.92.${IP_F}

SRC=${PATH}/${IP}/${RID}
DEST=${PATH}/${IP_F}
time ./bin/ioparser -t 99.99999 -w 10 ${SRC} $DEST
time ./python/jsontocsv.py $DEST/trace.json $DEST/trace.csv
time ./python/jsontocsv.py $DEST/dmdu.json $DEST/dmdu.csv

IP_F=194
IP=203.255.92.${IP_F}

SRC=${PATH}/${IP}/${RID}
DEST=${PATH}/${IP_F}
time ./bin/ioparser -t 99.99999 -w 10 ${SRC} $DEST
time ./python/jsontocsv.py $DEST/trace.json $DEST/trace.csv
time ./python/jsontocsv.py $DEST/dmdu.json $DEST/dmdu.csv

IP_F=195
IP=203.255.92.${IP_F}

SRC=${PATH}/${IP}/${RID}
DEST=${PATH}/${IP_F}
time ./bin/ioparser -t 99.99999 -w 10 ${SRC} $DEST
time ./python/jsontocsv.py $DEST/trace.json $DEST/trace.csv
time ./python/jsontocsv.py $DEST/dmdu.json $DEST/dmdu.csv
