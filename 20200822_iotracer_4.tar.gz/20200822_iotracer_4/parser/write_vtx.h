#ifndef WRITE_H_XWQYDADK
#define WRITE_H_XWQYDADK

#include <inttypes.h>
#include <time.h>

enum {WRITE_DMDU, WRITE_RAW, WRITE_FLOW, WRITE_WWINDOW, WRITE_RWINDOW, WRITE_DWINDOW, WRITE_PROCESS, WRITE_VFS_READ, WRITE_VFS_WRITE, WRITE_VFS_WINDOW_WRITE, WRITE_VFS_WINDOW_READ, NR_WRITE};

struct write_data {
	int type; // dmdu, flow, threshold, window
	void *t_data;
};

struct window {
	uint64_t window;
	uint64_t latency;
	uint64_t kernel_time;
	uint64_t driver_time;
	uint64_t device_time;
	uint64_t max;
	uint64_t min;
	uint64_t io_size;
	uint64_t nr_flow;
	uint16_t streamid;
};

struct flow {
	uint64_t time;
	uint64_t latency;
	uint64_t kernel_time;
	uint64_t driver_time;
	uint64_t device_time;
	uint64_t io_size;
	uint64_t sector;
	char mode;
	uint16_t streamid;
};

struct raw {
	uint64_t block_bio_queue;
	uint64_t block_getrq;
	uint64_t nvme_sq;
	uint64_t block_rq_complete;
	uint64_t io_size;
	int start_correct;
	int end_correct;

	uint64_t sector;
	uint16_t streamid;
};

struct vfs {
	uint8_t mode; // READ or WRITE
	uint64_t time;
	uint64_t ptid;
	uint64_t off;
	uint32_t len;
	uint64_t latency;
	uint16_t streamid;
};

#define VFS_WINDOW_ALL 65535

struct vfs_window {
	uint64_t time;
	uint64_t total_size;
	uint64_t avg_latency;
	uint16_t streamid;
	uint64_t count;
};

struct threshold {
	uint64_t max;
	uint64_t min;
};

struct dmdu {
	struct timespec time;
	int64_t delta_disk_usage;
	double waf; // written_to_tlc_user - write_from_host
	int64_t gc; // written_to_tlc_user/write_from_host
	uint64_t nand_write; // written_to_tlc_user;
};

struct process {
	uint64_t time;
	int tgid; // PID
	int pid; // TID
	char *comm;
};

struct write_conf {
	char *sp_data; // alloc 256
	struct buffer *buf;
};

struct write_vtx {
	struct write_conf write_conf;
	struct vertex *write_vtx;
};

struct write_data *write_data_alloc(int type);
int window_header(char *dst);
int window_write(char *dst, struct window *w);
int flow_header(char *dst);
int flow_write(char *dst, struct flow *f);
int raw_header(char *dst);
int raw_write(char *dst, struct raw *r);
int threshold_header(char *dst);
int threshold_write(char *dst, struct threshold *th);
int dmdu_header(char *dst);
int dmdu_write(char *dst, struct dmdu *dd);
int process_header(char *dst);
int process_write(char *dst, struct process *ps);
int vfs_header(char *dst);
int vfs_write(char *dst, struct vfs *f);
int vfs_window_header(char *dst);
int vfs_window_write(char *dst, struct vfs_window *f);

struct write_vtx *write_start(struct buffer *buf, int append);
void write_stop(struct write_vtx *w);

#endif /* end of include guard: WRITE_H_XWQYDADK */
