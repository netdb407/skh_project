#include <inttypes.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include <assert.h>

#include "list/list.h"
#include "write_vtx.h"
#include "debug.h"
#include "vertex/vertex.h"
#include "buffer/buffer.h"
#include "trace_vtx.h"
#include "../share/event.h"
#include "bt.h"

#define NS_FMT "%"PRIu64".%.9"PRIu64
#define NS_ARG(time) (time)/1000000000UL, (time)%1000000000UL
#define TNS ((uint64_t)1000000000ULL)

char *types[] = {
	"None",
	"BLOCK_BIO_QUEUE",
	"BLOCK_GETRQ",
	"BLOCK_RQ_ISSUE",
	"NVME_SQ",
	"BLOCK_RQ_COMPLETE_W",
	"BLOCK_RQ_COMPLETE_R",
	"BLOCK_RQ_COMPLETE_D",
	"VFS_WRITE",
	"VFS_READ"
};

// RBTREE
struct tree_node {
	uint64_t sector;
	struct list list;
};

static int tree_compare(void *ta, void *tb)
{
	struct tree_node *a = ta;
	struct tree_node *b = tb;

	return (b->sector < a->sector) - (a->sector < b->sector);
}

static void ifraw_send(int check, struct rbtree *rb, struct vertex *wvtx)
{
	if (check == 0) {
		return ;
	}

	struct raw *r = NULL;
	struct write_data *d = NULL;

	d = write_data_alloc(WRITE_RAW);
	assert(d);
	r = d->t_data;

	r->block_bio_queue = rb->first;
	r->block_getrq = rb->getq;
	r->nvme_sq = rb->sq;
	r->block_rq_complete = rb->complete;

	r->io_size = rb->io_size;
	r->sector = rb->sector;
	r->streamid = rb->streamid;

	r->start_correct = rb->start_correct;
	r->end_correct = rb->end_correct;

	vertex_put(wvtx, d);
}

static void tree_free(void *data, void *private)
{
	struct make_flow_conf *conf = private;
	struct tree_node *node = data;
	struct list *pos = NULL;
	struct rbtree *cur = NULL;
	printf("tree_free\n");

	list_for_del(&node->list, pos, cur) {
		ifraw_send(conf->enable_raw, cur, conf->write_vtx);
		free(cur);
	}

	free(node);
}
// END RBTREE

static void *read_bcc_handler(void __attribute__((unused)) *data, void *private)
{
	struct read_bcc_conf *conf = private;
	struct event *ev = NULL;
	uint64_t r_size = 0;

	xalloc(ev, sizeof(struct event));
	r_size = buffer_pop(conf->buffer, ev, sizeof(struct event));
	if (r_size == 0) {
		free(ev);
		return VERTEX_QUIT;
	}

	switch (ev->type) {
	case BLOCK_BIO_QUEUE:
		++conf->nr_bio_queue;
		break;
	case BLOCK_GETRQ:
		++conf->nr_bio_getrq;
		break;
	case BLOCK_RQ_ISSUE:
		++conf->nr_rq_issue;
		break;
	case NVME_SQ:
		++conf->nr_nvme_sq;
		break;
	case BLOCK_RQ_COMPLETE_R:
	case BLOCK_RQ_COMPLETE_W:
	case BLOCK_RQ_COMPLETE_D:
		++conf->nr_rq_complete;
		break;
	default:
		break;
	}

	return ev;
}

static void __sector_free(struct make_flow_conf *conf, struct rbtree *rb)
{
	struct tree_node tmp = {0}, *search = NULL;
	tmp.sector = rb->sector;
	search = bt_get(conf->tree, &tmp);
	if (search == NULL) {
		return ;
	}

	struct rbtree *node = NULL;
	struct list *pos = NULL;

	assert(!list_empty(&search->list));

	list_for(&search->list, pos, node) {
		if (node == rb) {
			break;
		}
	}

	list_del(pos);
	free(rb);

	if (list_empty(&search->list)) {
		search = bt_del(conf->tree, &tmp);
		free(search);
	}
}

static void start_sorted_add(struct make_flow_conf *conf, struct rbtree *rb)
{
	struct list *pos = NULL;
	struct rbtree *cur = NULL;
	int r = 0;

	list_reserve_for(&conf->start_sorted_list, pos, cur) {
		if (cur->new_time < rb->new_time) {
			r = list_add(pos, rb);
			assert(r == 0);
			break;
		}
	}

	if (pos == &conf->start_sorted_list) { // 한바퀴 순회
		r = list_add(pos, rb);
		assert(r == 0);
	}
}

static void rotate_add(uint64_t *arr, uint64_t value)
{
	int i = 0;
	for (i = 0; i < 4; ++i) {
		arr[i] = arr[i+1];
	}

	arr[i] = value;
}

static uint64_t rotate_avg(uint64_t *arr)
{
	uint64_t sum = 0;
	int i = 0;
	int nr_missing = 0;

	for (i = 0; i < 5; ++i) {
		if (arr[i] == 0) {
			++nr_missing;
		}
		sum += arr[i];
	}

	if (nr_missing == 5) {
		return 0;
	}

	if (nr_missing) {
		sum += arr[nr_missing]*nr_missing;
	}

	return sum/5;
}

static void rb2flow_and_pass2flow_and_pass2window(struct make_flow_conf *conf,
						  struct rbtree *rb)
{
	struct flow *flow = NULL;
	if (rb->first == 0 || rb->getq == 0 || rb->sq == 0 || rb->complete == 0 ||
	    rb->io_size == 0) {
		return ;
	}

	xalloc(flow, sizeof(struct flow));
	flow->time = rb->complete;
	flow->latency = rb->complete - rb->first;
	flow->kernel_time = rb->getq - rb->first;
	flow->driver_time = rb->sq - rb->getq;
	flow->device_time = rb->complete - rb->sq;
	flow->io_size = rb->io_size;
	flow->mode = rb->mode;
	flow->sector = rb->sector;
	flow->streamid = rb->streamid;

	// pass to flow
	struct write_data *d = write_data_alloc(WRITE_FLOW);
	memcpy(d->t_data, flow, sizeof(struct flow));
	vertex_put(conf->write_vtx, d);

	// pass to window
	vertex_put(conf->next_vtx, flow);
}

/** 
 * @brief 일정 시간이 지나면 메모리에서 제거
 * 
 * @param conf
 * @param ev
 */
static void start_sorted_check(struct make_flow_conf *conf, struct event *ev)
{
	struct rbtree *cur = NULL;
	while (conf->start_sorted_list.next != &conf->start_sorted_list) { 
		cur = conf->start_sorted_list.next->data;
		assert(ev->time >= cur->new_time);
		if ((ev->time - cur->new_time) < TNS*5) {
			break;
		}

		rb2flow_and_pass2flow_and_pass2window(conf, cur);
		list_del(conf->start_sorted_list.next);
		ifraw_send(conf->enable_raw, cur, conf->write_vtx);
		__sector_free(conf, cur);
	}
}

static int event_rb_level(struct event *ev)
{
	int level = 0;
	switch (ev->type) {
	case BLOCK_BIO_QUEUE:
		level = 1;
		break;
	case BLOCK_GETRQ:
		level = 2;
		break;
	case BLOCK_RQ_ISSUE:
		level = 3;
		break;
	case NVME_SQ:
		level = 4;
		break;
	case BLOCK_RQ_COMPLETE_R:
	case BLOCK_RQ_COMPLETE_W:
	case BLOCK_RQ_COMPLETE_D:
		level = 5;
		break;
	default:
		assert(0);
		level = 10;
		break;
	}

	return level;
}

static struct rbtree *tree_search_rb(struct tree_node *node, int level)
{
	struct list *pos = NULL;
	struct rbtree *rb = NULL;
	list_for(&node->list, pos, rb) {
		if (level > rb->current_level) {
			return rb;
		}
	}

	return NULL;
}

static struct rbtree *sector_upsert(struct make_flow_conf *conf, struct event *ev)
{
	struct tree_node tmp = {0}, *search = NULL;
	int r = 0;
	struct rbtree *rb = NULL;
	int event_level = event_rb_level(ev);
	
	tmp.sector = ev->off;

	search = bt_get(conf->tree, &tmp);
	if (search == NULL) {
		xalloc(search, sizeof(struct tree_node));
		search->sector = ev->off;
		list_init(&search->list);
		r = bt_put(conf->tree, search);
		assert(r == 0);
		
		xalloc(rb, sizeof(struct rbtree));
		rb->new_time = ev->time;
		rb->sector = ev->off;
		rb->current_level = event_level;
		rb->mode = 'W';

		r = list_add_tail(&search->list, rb);
		assert(r == 0);
		start_sorted_add(conf, rb);

		return rb;
	} else {
		rb = tree_search_rb(search, event_level);
		if (rb == NULL) {
			xalloc(rb, sizeof(struct rbtree));
			rb->new_time = ev->time;
			rb->sector = ev->off;
			rb->current_level = event_level;
			rb->mode = 'W';

			r = list_add_tail(&search->list, rb);
			assert(r == 0);
			start_sorted_add(conf, rb);

			return rb;
		}

		rb->current_level = event_level;
		return rb;
	}
}

static void vfs_handle(struct make_flow_conf *conf, struct event *ev,
		       int type, int mode)
{
	struct vfs *vfs = NULL;
	struct vfs *tmp = NULL;
	struct write_data *d = write_data_alloc(type);
	assert(d);
	vfs = d->t_data;
	vfs->mode = mode;
	vfs->time = ev->time;
	vfs->ptid = ev->ptid;
	vfs->off = ev->off;
	vfs->len = ev->len;
	vfs->latency = ev->private;
	vfs->streamid = ev->streamid;
	tmp = malloc(sizeof(struct vfs));
	assert(tmp);
	*tmp = *vfs;
	vertex_put(conf->write_vtx, d);
	vertex_put(conf->vfs_window_vtx, tmp);
	free(ev);
}

static void *make_flow_handler(void *data, void *private)
{
	struct make_flow_conf *conf = private;
	struct event *ev = data;
	struct rbtree *rb = NULL;

	if (ev->type == VFS_WRITE) {
		vfs_handle(conf, ev, WRITE_VFS_WRITE, 1);
		return NULL;
	} else if (ev->type == VFS_READ) {
		vfs_handle(conf, ev, WRITE_VFS_READ, 0);
		return NULL;
	}

	start_sorted_check(conf, ev);

	rb = sector_upsert(conf, ev);
	assert(rb);

	if (ev->len > 0) {
		rb->io_size = ev->len*512;
	}

	switch (ev->type) {
	case BLOCK_BIO_QUEUE:
		rb->first = ev->time;
		break;
	case BLOCK_GETRQ:
		rb->getq = ev->time;
		if (rb->first) {
			rotate_add(conf->start5, rb->getq - rb->first);
		} else { // queue 시간 보정
			rb->first = rb->getq - rotate_avg(conf->start5);
			rb->start_correct = 1;
		}
		break;
	case BLOCK_RQ_ISSUE:

		break;
	case NVME_SQ:
		rb->sq = ev->time;
		rb->streamid = ev->streamid;

		// 일단 complete 보정
		rb->complete = rotate_avg(conf->end5) + rb->sq;
		rb->end_correct = 1;
		break;
	case BLOCK_RQ_COMPLETE_R:
	case BLOCK_RQ_COMPLETE_W:
	case BLOCK_RQ_COMPLETE_D:
		// 보정했던 것을 원래의 event값으로 변경
		rb->complete = ev->time;
		rb->end_correct = 0;
		if (rb->sq) {
			rotate_add(conf->end5, rb->complete - rb->sq);
		}

		if (ev->type == BLOCK_RQ_COMPLETE_R) {
			rb->mode = 'R';
		} else if (ev->type == BLOCK_RQ_COMPLETE_W) {
			rb->mode = 'W';
		} else if (ev->type == BLOCK_RQ_COMPLETE_D) {
			rb->mode = 'D';
		}
		break;
	default:
		break;
	}

	free(ev);

	return NULL;
}

static void window_accumulate(struct window *window, uint64_t calc_window, struct flow *flow)
{
	window->window = calc_window;

	if (window->max < flow->latency) {
		window->max = flow->latency;
	}

	if (window->min > flow->latency) {
		window->min = flow->latency;
	}

	window->streamid = flow->streamid;
	window->latency += flow->latency;
	window->kernel_time += flow->kernel_time;
	window->device_time += flow->device_time;
	window->driver_time += flow->driver_time;
	window->io_size += flow->io_size;
	++window->nr_flow;
}

static void window_merge(struct window *window, struct window *data)
{
	window->latency += data->latency;
	window->kernel_time += data->kernel_time;
	window->device_time += data->device_time;
	window->driver_time += data->driver_time;
	window->io_size += data->io_size;
	window->nr_flow += data->nr_flow;

	if (data->max > window->max) {
		window->max = data->max;
	}

	if (data->min < window->min) {
		window->min = data->min;
	}
}

static void window_summary(struct window *window)
{
	window->latency /= window->nr_flow;
	window->kernel_time /= window->nr_flow;
	window->device_time /= window->nr_flow;
	window->driver_time /= window->nr_flow;
}

static void __window_group(struct list *window, uint64_t current_window, struct vertex *wvtx, int mode)
{
	struct list *pos = NULL;
	struct window *entry = NULL;
	int nr = 0;
	struct window total_window = {0};
	struct write_data *d = NULL;
	struct window *tmp = {0};
	struct list total = {0};

	list_init(&total);

	total_window.window = current_window;
	total_window.streamid = VFS_WINDOW_ALL;
	total_window.max = 0;
	total_window.min = UINT64_MAX;

	list_for_del (window, pos, entry) {
		++nr;
		d = write_data_alloc(mode);
		tmp = d->t_data;
		*tmp = *entry;

		window_merge(&total_window, tmp);

		window_summary(tmp);

		vertex_put(wvtx, d);
		free(entry);
	}

	if (nr > 1) {
		d = write_data_alloc(mode);
		memcpy(d->t_data, &total_window, sizeof(struct window));
		window_summary(d->t_data);
		vertex_put(wvtx, d);
	}
}

static void *make_window_handler(void *data, void *private) // and sorting
{
	struct make_window_conf *conf = private;
	struct flow *flow = data;
	uint64_t calc_window = 0;

	calc_window = (flow->time/conf->window_size)*conf->window_size;

	// FIXME window size 가 0인 경우 처리해야 함
	if (calc_window != conf->current_window) { // 다를 경우 + window size가 0일 경우
		__window_group(&conf->window[0], conf->current_window, conf->write_vtx, WRITE_RWINDOW);
		__window_group(&conf->window[1], conf->current_window, conf->write_vtx, WRITE_WWINDOW);
		__window_group(&conf->window[2], conf->current_window, conf->write_vtx, WRITE_DWINDOW);

		list_init(&conf->window[0]);
		list_init(&conf->window[1]);
		list_init(&conf->window[2]);
		conf->current_window = calc_window;
	}

	// upsert 
	int idx = 0;
	switch (flow->mode) {
	case 'R':
		idx=0;
		break;
	case 'W':
		idx=1;
		break;
	case 'D':
		idx=2;
		break;
	default:
		BRK();
		break;
	}

	struct list *pos;
	struct window *entry = NULL;

	list_for (&conf->window[idx], pos, entry) {
		if (entry->streamid == flow->streamid) {
			break;
		}
	}

	if (pos == &conf->window[idx]) { // 새로 넣어야 함, 위에서 추가 못함
		entry = malloc(sizeof(struct window));
		assert(entry);
		memset(entry, 0, sizeof(struct window));
		list_add_tail(&conf->window[idx], entry);
		entry->min = UINT64_MAX;
	}

	window_accumulate(entry, calc_window, flow);
	free(flow);

	return NULL;
}

static void vfs_window_accumulate(struct vfs_window *vw, uint64_t calc_window, struct vfs *vfs)
{
	vw->time = calc_window;
	vw->streamid = vfs->streamid;
	vw->total_size += vfs->len;
	vw->avg_latency += vfs->latency;
	++vw->count;
}

static void vfs_window_merge(struct vfs_window *vw, struct vfs_window *data)
{
	vw->count += data->count;
	vw->total_size += data->total_size;
	vw->avg_latency += data->avg_latency;
}

static void vfs_window_summary(struct vfs_window *vw)
{
	vw->avg_latency /= vw->count;
}

static void __vfs_window_group(struct list *window, uint64_t current_window, struct vertex *wvtx, int mode)
{
	struct list *pos = NULL;
	struct vfs_window *entry = NULL;
	int nr = 0;
	struct vfs_window total_window = {0};
	struct write_data *d = NULL;
	struct vfs_window *tmp = {0};

	total_window.time = current_window;
	total_window.streamid = VFS_WINDOW_ALL;

	list_for_del (window, pos, entry) {
		++nr;
		d = write_data_alloc(mode);
		assert(d);
		tmp = d->t_data;
		*tmp = *entry;

		vfs_window_merge(&total_window, entry);

		vfs_window_summary(tmp);

		vertex_put(wvtx, d);
		free(entry);
	}

	if (nr > 1) {
		vfs_window_summary(&total_window);
		d = write_data_alloc(mode);
		*(struct vfs_window *)d->t_data = total_window;

		vertex_put(wvtx, d);
	}
}

static void *make_vfs_window_handler(void *data, void *private)
{
	struct make_vfs_window_conf *conf = private;
	struct vfs *vfs = data;
	uint64_t calc_window = 0;
	struct list *pos = NULL;
	struct vfs_window *entry = NULL;
	struct vfs_window *vw = NULL;

	calc_window = (vfs->time/conf->window_size)*conf->window_size;

	if (conf->current_window != calc_window) {
		__vfs_window_group(&conf->window[0], conf->current_window, conf->write_vtx, WRITE_VFS_WINDOW_READ);
		__vfs_window_group(&conf->window[1], conf->current_window, conf->write_vtx, WRITE_VFS_WINDOW_WRITE);
		
		list_init(&conf->window[0]);
		list_init(&conf->window[1]);
		conf->current_window = calc_window;
	}

	// upsert 
	int idx = vfs->mode;

	list_for (&conf->window[idx], pos, entry) {
		if (entry->streamid == vfs->streamid) { // 기존에 이미 streamid가 할당되어있는 경우 
			vfs_window_accumulate(entry, calc_window, vfs);
			break;
		}
	}

	if (pos == &conf->window[idx]) { // 기존에 streamid가 할당되지 않아서 새로 넣어야 함
		vw = malloc(sizeof(struct vfs_window));
		assert(vw);
		memset(vw, 0, sizeof(struct vfs_window));

		list_add_tail(&conf->window[idx], vw);

		vfs_window_accumulate(vw, calc_window, vfs);
	}
	// end upsert
	free(vfs);

	return NULL;
}

struct trace_vtx *trace_start(struct buffer *buf, int window_size, struct vertex *write_vtx, int enable_raw)
{
	struct trace_vtx *vtx = NULL;
	struct vertex *make_window_vtx = NULL;
	struct vertex *make_flow_vtx = NULL;
	struct vertex *make_vfs_window = NULL;
	xalloc(vtx, sizeof(struct trace_vtx));

	vtx->read_bcc_vtx = vertices(0, read_bcc_handler, &vtx->read_bcc_conf);
	make_window_vtx = vertex(make_window_handler, &vtx->make_window_conf);
	make_flow_vtx = vertex(make_flow_handler, &vtx->make_flow_conf);
	make_vfs_window = vertex(make_vfs_window_handler, &vtx->make_vfs_window_conf);

	vtx->read_bcc_conf.buffer = buf;

	vtx->make_window_conf.current_window = UINT64_MAX;
	vtx->make_window_conf.window_size = (uint64_t)(window_size)*TNS;
	list_init(&vtx->make_window_conf.window[0]);
	list_init(&vtx->make_window_conf.window[1]);
	list_init(&vtx->make_window_conf.window[2]);
	vtx->make_window_conf.write_vtx = write_vtx;
	vtx->make_flow_conf.write_vtx = write_vtx;
	vtx->make_flow_conf.tree = bt_alloc(tree_compare);
	vtx->make_flow_conf.enable_raw = enable_raw;
	vtx->make_flow_conf.next_vtx = make_window_vtx;
	vtx->make_flow_conf.vfs_window_vtx = make_vfs_window;
	list_init(&vtx->make_flow_conf.start_sorted_list);

	vtx->make_vfs_window_conf.write_vtx = write_vtx;
	vtx->make_vfs_window_conf.window_size = (uint64_t)(window_size)*TNS;
	vtx->make_vfs_window_conf.current_window = UINT64_MAX;
	list_init(&vtx->make_vfs_window_conf.window[0]);
	list_init(&vtx->make_vfs_window_conf.window[1]);

	edge(vtx->read_bcc_vtx, make_flow_vtx);

	vertex_start(make_vfs_window);
	vertex_start(make_window_vtx);
	vertex_start(vtx->read_bcc_vtx);
	return vtx;
}

void trace_stop(struct trace_vtx *vtx)
{
	vertex_stop(vtx->read_bcc_vtx);
	{
		struct list *pos = NULL;
		struct rbtree *rb = NULL;
		list_for_del(&vtx->make_flow_conf.start_sorted_list, pos, rb) {
			(void)rb;
			rb2flow_and_pass2flow_and_pass2window(&vtx->make_flow_conf, rb);
			ifraw_send(vtx->make_flow_conf.enable_raw, rb, vtx->make_flow_conf.write_vtx);
			__sector_free(&vtx->make_flow_conf, rb);
		}
	}

	// make_window_handler
	vertex_stop(vtx->make_flow_conf.next_vtx);

	__window_group(&vtx->make_window_conf.window[0], vtx->make_window_conf.current_window, vtx->make_window_conf.write_vtx, WRITE_RWINDOW);
	__window_group(&vtx->make_window_conf.window[1], vtx->make_window_conf.current_window, vtx->make_window_conf.write_vtx, WRITE_WWINDOW);
	__window_group(&vtx->make_window_conf.window[2], vtx->make_window_conf.current_window, vtx->make_window_conf.write_vtx, WRITE_DWINDOW);

	{
		bt_free(vtx->make_flow_conf.tree, tree_free, &vtx->make_flow_conf);
	}

	vertex_stop(vtx->make_flow_conf.vfs_window_vtx);

	__vfs_window_group(&vtx->make_vfs_window_conf.window[0], vtx->make_vfs_window_conf.current_window, vtx->make_vfs_window_conf.write_vtx, WRITE_VFS_WINDOW_READ);
	__vfs_window_group(&vtx->make_vfs_window_conf.window[1], vtx->make_vfs_window_conf.current_window, vtx->make_vfs_window_conf.write_vtx, WRITE_VFS_WINDOW_WRITE);

	printf("queue : %lu getrq : %lu issue : %lu nvme_sq : %lu complete : %lu\n",
	       vtx->read_bcc_conf.nr_bio_queue,
	       vtx->read_bcc_conf.nr_bio_getrq,
	       vtx->read_bcc_conf.nr_rq_issue,
	       vtx->read_bcc_conf.nr_nvme_sq,
	       vtx->read_bcc_conf.nr_rq_complete);

	free(vtx);
}
