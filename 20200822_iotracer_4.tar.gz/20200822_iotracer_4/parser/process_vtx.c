#include <inttypes.h>
#include <stdio.h>

#include "process_vtx.h"
#include "write_vtx.h"
#include "debug.h"

struct pid_raw { // same with tracer/process.c
	uint64_t time;
	int tgid; // PID
	int pid; // TID
};

struct process_pass_conf {
	struct vertex *write_vtx;
};

void *read_process_handler(void __attribute__((unused)) *data, void *private)
{
	struct buffer *buf = private;
	uint64_t r_size = 0;
	struct pid_raw raw = {0};
	struct process *process = NULL;
	int slen = 0;

	r_size = buffer_pop(buf, &raw, sizeof(struct pid_raw));
	if (r_size == 0) {
		return VERTEX_QUIT;
	}

	xalloc(process, sizeof(struct process));

	buffer_pop(buf, &slen, sizeof(int));
	xalloc(process->comm, slen+1);
	if (slen > 0) {
		buffer_pop(buf, process->comm, slen);
	}
	process->time = raw.time;
	process->pid = raw.pid;
	process->tgid = raw.tgid;
	process->comm[slen] = '\0';

	//printf("%ld, %d %d %s\n", process->time, process->pid, process->tgid, process->comm);

	return process;
}

void *process_pass_handler(void *data, void *private)
{
	struct vertex *write_vtx = private;
	struct process *process = data;
	struct write_data *d = NULL;
	d = write_data_alloc(WRITE_PROCESS);
	memcpy(d->t_data, process, sizeof(struct process));
	vertex_put(write_vtx, d);

	free(process);

	return NULL;
}

struct process_vtx *process_start(struct vertex *write_vtx, struct buffer *buf)
{
	struct process_vtx *vtx = NULL;
	struct vertex *process_pass_vtx = NULL;

	xalloc(vtx, sizeof(struct process_vtx));

	vtx->vtx = vertices(0, read_process_handler, buf);
	process_pass_vtx = vertex(process_pass_handler, write_vtx);

	edge(vtx->vtx, process_pass_vtx);

	vertex_start(vtx->vtx);

	//printf("hello\n");

	return vtx;
}

void process_stop(struct process_vtx *vtx)
{
	vertex_stop(vtx->vtx);
	free(vtx);
}
