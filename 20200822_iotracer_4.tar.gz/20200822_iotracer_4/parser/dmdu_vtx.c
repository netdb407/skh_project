#include <time.h>
#include <stdlib.h>
#include <stdio.h>

#include "buffer/buffer.h"
#include "vertex/vertex.h"
#include "debug.h"
//`o#include "write.h"
#include "write_vtx.h"
#include "dmdu_vtx.h"

struct dmdu_raw { // same with tracer/iotracer.c
	struct timespec time;
	unsigned long usage;
	unsigned long long written_to_tlc_user;
	unsigned long long write_from_host;
};

void *read_dmdu_handler(void __attribute__((unused)) *data, void *private)
{
	struct read_dmdu_conf *conf = private;
	uint64_t r_size;
	struct dmdu_raw *raw = NULL;

	xalloc(raw, sizeof(struct dmdu_raw));

	r_size = buffer_pop(conf->buffer, raw, sizeof(struct dmdu_raw));
	if (r_size == 0) {
		free(raw);
		return VERTEX_QUIT;
	}

	return raw;
}

void *dmdu_merge_handler(void *data, void *private)
{
	struct dmdu_merge_conf *conf = private;
	struct dmdu_raw *raw = data;
	struct dmdu dmdu;

	if (conf->prev) {
		uint64_t wfh =(raw->write_from_host - conf->prev->write_from_host);
		uint64_t wttu =(raw->written_to_tlc_user - conf->prev->written_to_tlc_user);
		dmdu.time = raw->time;
		dmdu.delta_disk_usage = raw->usage - conf->prev->usage;
		dmdu.gc = wttu - wfh;
		if (wfh) {
			dmdu.waf = (double)wttu/(double)wfh;
		} else {
			dmdu.waf = 0;
		}
		dmdu.nand_write = wttu;

		{
			struct write_data *d = write_data_alloc(WRITE_DMDU);
			memcpy(d->t_data, &dmdu, sizeof(struct dmdu));
			vertex_put(conf->write_vtx, d);
		}

		free(conf->prev);
	} else {
		{
			memset(&dmdu, 0, sizeof(struct dmdu));
			dmdu.delta_disk_usage = raw->usage;
			struct write_data *d = write_data_alloc(WRITE_DMDU);
			memcpy(d->t_data, &dmdu, sizeof(struct dmdu));
			vertex_put(conf->write_vtx, d);
		}
	}

	conf->prev = raw;
	return NULL;
}

struct dmdu_vtx *dmdu_start(struct vertex *write_vtx, struct buffer *buf)
{
	struct dmdu_vtx *vtx = NULL;
	struct vertex *dmdu_merge_vtx = NULL;

	xalloc(vtx, sizeof(struct dmdu_vtx));

	vtx->read_dmdu_conf.buffer = buf;
	vtx->dmdu_merge_conf.write_vtx = write_vtx;

	dmdu_merge_vtx = vertex(dmdu_merge_handler, &vtx->dmdu_merge_conf);
	CHECK(dmdu_merge_vtx);

	vtx->read_dmdu_vtx = vertices(0, read_dmdu_handler, &vtx->read_dmdu_conf);
	CHECK(vtx->read_dmdu_vtx);

	edge(vtx->read_dmdu_vtx, dmdu_merge_vtx);
	vertex_start(vtx->read_dmdu_vtx);

	return vtx;
}

void dmdu_stop(struct dmdu_vtx *vtx)
{
	vertex_stop(vtx->read_dmdu_vtx);
	free(vtx->dmdu_merge_conf.prev);
	free(vtx);
}
