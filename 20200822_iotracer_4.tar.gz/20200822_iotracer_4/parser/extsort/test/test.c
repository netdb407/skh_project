#include <inttypes.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <time.h>
#include <limits.h>
#include <stdio.h>

#include "extsort.h"

#define INT2VOIDP(i) (void*)(uintptr_t)(i)
#define VOIDP2INT(i) (int)(uintptr_t)(i)

int mycompare(const void *a, const void *b)
{
	const int *_a = a;
	const int *_b = b;

	return (*_b < *_a) - (*_a < *_b);
}

ssize_t myread(void *private, void *buf, size_t nbyte)
{
	return read(VOIDP2INT(private), buf, nbyte);
}

void generate_1000_example()
{
	int n = 0;
	int fd = 0;
	int i = 0;
	ssize_t sz_write = 0;

	srand(time(NULL));
	fd = creat("test.txt", 0644);
	assert(fd > 0);

	for (i = 0; i < 1000; ++i) {
		n = rand()%INT_MAX;
		sz_write = write(fd, &n, sizeof(int));
		assert(sz_write == sizeof(int));
	}

	close(fd);
}

void just_read_and_print()
{
	int n = 0;
	int fd = 0;
	int i = 0;
	ssize_t sz_write = 0;

	fd = open("output.txt", O_RDONLY);
	assert(fd > 0);

	for (i = 0; i < 1000; ++i) {
		sz_write = read(fd, &n, sizeof(int));
		assert(sz_write == sizeof(int));
		printf("%d\n", n);
	}

	close(fd);
}

int main(void)
{
	struct extsort ext = {0};
	int fd = 0;
	generate_1000_example();
	fd = open("test.txt", O_RDONLY);
	assert(fd > 0);

	ext.ecmp = mycompare;
	ext.eread = myread;
	ext.tmplate = "template.XXXXXX";
	ext.output = "output.txt";
	ext.nmemb = 100;
	ext.size = sizeof(int);
	ext.private = INT2VOIDP(fd);

	extsort(&ext);

	close(fd);
	just_read_and_print();
	return 0;
}
