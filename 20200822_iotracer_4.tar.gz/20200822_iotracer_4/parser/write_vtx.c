#include <stdio.h>
#include <inttypes.h>
#include <unistd.h>

#include "vertex/vertex.h"
#include "buffer/buffer.h"
#include "file/file.h"
#include "write_vtx.h"
#include "debug.h"

#define NS_FMT "%"PRIu64".%.9"PRIu64
#define NS_ARG(time) (time)/1000000000UL, (time)%1000000000UL

int window_header(char *dst)
{
	return sprintf(dst, "Window Time,Number of IO,Size of IO,Latency,Kernel Time,Driver Time,Device Time,max,min,streamid\n");
}

int window_write(char *dst, struct window *w)
{
	int r = 0;
	r = sprintf(dst, ""NS_FMT",%"PRIu64",%"PRIu64","NS_FMT","NS_FMT","NS_FMT","NS_FMT","NS_FMT","NS_FMT",", NS_ARG(w->window), w->nr_flow, w->io_size, NS_ARG(w->latency), NS_ARG(w->kernel_time), NS_ARG(w->driver_time), NS_ARG(w->device_time), NS_ARG(w->max), NS_ARG(w->min));
	if (w->streamid == VFS_WINDOW_ALL) {
		r += sprintf(&dst[r], "ALL\n");
	} else {
		r += sprintf(&dst[r], "%u\n", w->streamid);
	}

	return r;
}

int flow_header(char *dst)
{
	return sprintf(dst, "Time,Mode,Offset,Size of IO,Latency,Kernel Time,Driver Time,Device Time,streamid\n");
}

int flow_write(char *dst, struct flow *f)
{ 
	return sprintf(dst, ""NS_FMT",%c,%"PRIu64",%"PRIu64","NS_FMT","NS_FMT","NS_FMT","NS_FMT",%u\n", 
		NS_ARG(f->time),f->mode, f->sector, f->io_size, NS_ARG(f->latency) , NS_ARG(f->kernel_time) , NS_ARG(f->driver_time) , NS_ARG(f->device_time), f->streamid);
}

int raw_header(char *dst)
{
	return sprintf(dst, "Sector,Size of IO,streamid,block_bio_queue,block_getrq,nvme_sq,block_rq_complete\n");
}

int raw_write(char *dst, struct raw *r)
{
	int sr = 0;
	sr = sprintf(dst, "%"PRIu64",%"PRIu64",%u,",
		    r->sector, r->io_size, r->streamid);

	if (r->start_correct) {
		sr += sprintf(&dst[sr], "-");
	}

	sr += sprintf(&dst[sr], ""NS_FMT","NS_FMT","NS_FMT",", 
		NS_ARG(r->block_bio_queue), NS_ARG(r->block_getrq), 
		NS_ARG(r->nvme_sq));

	if (r->end_correct) {
		sr += sprintf(&dst[sr], "-");
	}

	sr += sprintf(&dst[sr], ""NS_FMT"\n", 
		      NS_ARG(r->block_rq_complete));

	return sr;
}

int threshold_header(char *dst)
{
	return sprintf(dst, "best,worst\n");
}

int threshold_write(char *dst, struct threshold *th)
{
	return sprintf(dst, ""NS_FMT","NS_FMT"\n", NS_ARG(th->min), NS_ARG(th->max));
}

int dmdu_header(char *dst)
{
	return sprintf(dst, "time,delta_disk_usage,waf,gc,nand_write\n");
}

int dmdu_write(char *dst, struct dmdu *dd)
{
	return sprintf(dst, "%ld,%"PRId64",%lf,%"PRId64",%"PRIu64"\n", 
		dd->time.tv_sec, dd->delta_disk_usage, dd->waf, dd->gc, dd->nand_write);
}

int process_header(char *dst)
{
	return sprintf(dst, "time,pid,tid,command\n");
}

int process_write(char *dst, struct process *ps)
{
	int r = sprintf(dst, "%ld,%d,%d,%s\n", ps->time/1000000000UL, ps->tgid, ps->pid, ps->comm);
	free(ps->comm);
	return r;
}

int vfs_header(char *dst)
{
	return sprintf(dst, "time,pid,tid,offset,length,latency,streamid\n");
}

int vfs_write(char *dst, struct vfs *v)
{
	return sprintf(dst, ""NS_FMT",%"PRIu64",%"PRIu64",%"PRIu64",%u,"NS_FMT",%u\n", 
		NS_ARG(v->time), v->ptid>>32, v->ptid&0xFFFFFFFF, v->off, v->len, NS_ARG(v->latency), v->streamid);
}

int vfs_window_header(char *dst)
{
	return sprintf(dst, "time,count,total_size,avg_latency,streamid\n");
}

int vfs_window_write(char *dst, struct vfs_window *f)
{
	int r = 0;
	r = sprintf(dst, ""NS_FMT",%"PRIu64",%"PRIu64","NS_FMT",", NS_ARG(f->time), f->count, f->total_size, NS_ARG(f->avg_latency));

	if (f->streamid == VFS_WINDOW_ALL) {
		r += sprintf(&dst[r], "ALL\n");
	} else {
		r += sprintf(&dst[r], "%u\n", f->streamid);
	}

	return r;
}

struct write_data *write_data_alloc(int type)
{
	struct write_data *new = NULL;
	int size = 0;
	switch (type) {
	case WRITE_DMDU:
		size = sizeof(struct dmdu);
		break;
	case WRITE_FLOW:
		size = sizeof(struct flow);
		break;
	case WRITE_RAW:
		size = sizeof(struct raw);
		break;
//	case WRITE_THRESHOLD:
//		size = sizeof(struct threshold);
//		break;
	case WRITE_WWINDOW:
	case WRITE_RWINDOW:
	case WRITE_DWINDOW:
		size = sizeof(struct window);
		break;
	case WRITE_PROCESS:
		size = sizeof(struct process);
		break;
	case WRITE_VFS_READ:
	case WRITE_VFS_WRITE:
		size = sizeof(struct vfs);
		break;
	case WRITE_VFS_WINDOW_READ:
	case WRITE_VFS_WINDOW_WRITE:
		size = sizeof(struct vfs_window);
		break;
	default:
		BRK();
		break;
	}

	size += sizeof(struct write_data);

	xalloc(new, size);

	new->type = type;
	new->t_data = &new[1];

	return new;
}

static int write_data_to_str(int type, void *data, char *res)
{
	int ret = 0;
	switch (type) {
	case WRITE_DMDU:
		ret = dmdu_write(res, data);
		break;
	case WRITE_FLOW:
		ret = flow_write(res, data);
		break;
	case WRITE_RAW:
		ret = raw_write(res, data);
		break;
//	case WRITE_THRESHOLD:
//		ret = threshold_write(res, data);
//		break;
	case WRITE_WWINDOW:
	case WRITE_RWINDOW:
	case WRITE_DWINDOW:
		ret = window_write(res, data);
		break;
	case WRITE_PROCESS:
		ret = process_write(res, data);
		break;
	case WRITE_VFS_READ:
	case WRITE_VFS_WRITE:
		ret = vfs_write(res, data);
		break;
	case WRITE_VFS_WINDOW_READ:
	case WRITE_VFS_WINDOW_WRITE:
		ret = vfs_window_write(res, data);
		break;
	default:
		fprintf(stderr, "what is this type? %d\n", type);
		BRK();
		ret = -1;
		break;
	}

	return ret;
}

void *write_handler(void *data, void *private)
{
	struct write_conf *conf = private;
	struct write_data *w = data;
	int ret = 0;

	ret = write_data_to_str(w->type, w->t_data, conf->sp_data);
	if (ret == -1) {
		return NULL; // FIXME
	}
	buffer_push(&conf->buf[w->type], conf->sp_data, ret);

	free(data);

	return NULL;
}

struct write_vtx *write_start(struct buffer *buf, int append)
{
	struct write_vtx *w = NULL;
	int ret = 0;
	xalloc(w, sizeof(struct write_vtx));

	w->write_conf.buf = buf;
	xalloc(w->write_conf.sp_data, 8192);

	w->write_vtx = vertex(write_handler, &w->write_conf);
	CHECK(w->write_vtx);

	if (append == 0) {
		ret = dmdu_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_DMDU], w->write_conf.sp_data, ret);

		ret = flow_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_FLOW], w->write_conf.sp_data, ret);

		ret = raw_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_RAW], w->write_conf.sp_data, ret);

		ret = window_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_WWINDOW], w->write_conf.sp_data, ret);

		ret = window_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_RWINDOW], w->write_conf.sp_data, ret);

		ret = window_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_DWINDOW], w->write_conf.sp_data, ret);

		ret = process_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_PROCESS], w->write_conf.sp_data, ret);

		ret = vfs_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_VFS_READ], w->write_conf.sp_data, ret);

		ret = vfs_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_VFS_WRITE], w->write_conf.sp_data, ret);

		ret = vfs_window_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_VFS_WINDOW_WRITE], w->write_conf.sp_data, ret);

		ret = vfs_window_header(w->write_conf.sp_data);
		CHECK(ret > 0);
		buffer_push(&buf[WRITE_VFS_WINDOW_READ], w->write_conf.sp_data, ret);
	}

	vertex_start(w->write_vtx);

	return w;
}

void write_stop(struct write_vtx *w)
{
	int i = 0;
	vertex_stop(w->write_vtx);

	for (i = 0; i < NR_WRITE; ++i) {
		buffer_send(&w->write_conf.buf[i]);
		close((int64_t)w->write_conf.buf[i].private);
		buffer_deinit(&w->write_conf.buf[i]);
	}

	free(w->write_conf.sp_data);
	free(w);
}
