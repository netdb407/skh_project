#ifndef TRACE_VTX_H_ZMF1PN0R
#define TRACE_VTX_H_ZMF1PN0R

#include <inttypes.h>

#include "list/list.h"

struct make_window_conf {
	uint64_t window_size;
	uint64_t current_window;
	struct list window[3]; // READ. WRITE, and DISCARD
	int nr_flow;
	struct vertex *write_vtx;
};

struct make_vfs_window_conf {
	uint64_t window_size;
	uint64_t current_window;
	struct list window[2]; // READ and WRITE
	int nr_flow;
	struct vertex *write_vtx;
};

struct read_bcc_conf {
	struct buffer *buffer;
	uint64_t nr_event;
	uint64_t nr_bio_queue;
	uint64_t nr_bio_getrq;
	uint64_t nr_rq_issue;
	uint64_t nr_nvme_sq;
	uint64_t nr_rq_complete;
//	int counter[12];
};

struct rbtree {
	uint64_t sector;
	uint64_t new_time;
	uint64_t sq, complete, first, getq, io_size;
	uint16_t streamid;
	char mode; // 'R' read, 'W' write, 'D' discard
	int current_level;

	int start_correct;
	int end_correct;
	// 1 : first
	// 2 : getq
	// 3 : issue
	// 4 : nvme_sq
	// 5 : complete
};

struct make_flow_conf {
	struct vertex *write_vtx;
	struct vertex *next_vtx;
	struct vertex *vfs_window_vtx;

	uint64_t cut_time;
	//uint64_t nr_flow;

//	uint64_t total_size;
	int enable_raw;
	struct bt *tree;
	struct list start_sorted_list;

	uint64_t start5[5];
	uint64_t end5[5];
};

struct trace_vtx {
	struct read_bcc_conf read_bcc_conf;
	struct make_flow_conf make_flow_conf;
	struct make_window_conf make_window_conf;
	struct make_vfs_window_conf make_vfs_window_conf;
	struct vertex *read_bcc_vtx;
};

struct trace_vtx *trace_start(struct buffer *buf, int window_size, struct vertex *write_vtx, int enable_raw);
void trace_stop(struct trace_vtx *vtx);

#endif /* end of include guard: TRACE_VTX_H_ZMF1PN0R */
