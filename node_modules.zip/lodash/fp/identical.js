module.exports = require('./eq');
