module.exports = require('./isMatch');
