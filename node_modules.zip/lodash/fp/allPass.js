module.exports = require('./overEvery');
