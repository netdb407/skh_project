module.exports = require('./matchesProperty');
