module.exports = require('./ary');
