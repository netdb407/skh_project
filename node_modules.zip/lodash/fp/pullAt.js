var convert = require('./convert'),
    func = convert('pullAt', require('../pullAt'));

func.placeholder = require('./placeholder');
module.exports = func;
