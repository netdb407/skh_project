module.exports = require('./assignInAll');
