module.exports = require('./spread');
