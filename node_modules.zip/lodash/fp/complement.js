module.exports = require('./negate');
