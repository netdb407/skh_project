module.exports = require('./invert');
