var convert = require('./convert'),
    func = convert('overArgs', require('../overArgs'));

func.placeholder = require('./placeholder');
module.exports = func;
