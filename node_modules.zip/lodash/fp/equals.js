module.exports = require('./isEqual');
