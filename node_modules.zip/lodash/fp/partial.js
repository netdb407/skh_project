var convert = require('./convert'),
    func = convert('partial', require('../partial'));

func.placeholder = require('./placeholder');
module.exports = func;
