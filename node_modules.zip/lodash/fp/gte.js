var convert = require('./convert'),
    func = convert('gte', require('../gte'));

func.placeholder = require('./placeholder');
module.exports = func;
