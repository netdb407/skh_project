module.exports = require('./toPairsIn');
