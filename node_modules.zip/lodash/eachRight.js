module.exports = require('./forEachRight');
