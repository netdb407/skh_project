#!/usr/bin/env python
import ctypes as ct
from bcc import BPF
import sys # for exit
import os
from dialog import Dialog

class Data(ct.Structure):
    _fields_ = [
        ("type", ct.c_int),
        ("time", ct.c_ulonglong),
        ("dev", ct.c_int),
        ("pid", ct.c_ulonglong),
        ("off", ct.c_int),
        ("len", ct.c_int)
    ]


if not os.geteuid() == 0:
    sys.exit("run app as root");

d = Dialog(dialog="dialog")
# Dialog.set_background_title() requires pythondialog 2.13 or later
d.set_background_title("My little program")

allset = set(["BLOCK_BIO_BACKMERGE", "BLOCK_BIO_COMPLETE", "BLOCK_BIO_QUEUE", "BLOCK_DIRTY_BUFFER", "BLOCK_PLUG", "BLOCK_RQ_INSERT", "BLOCK_RQ_REMAP", "BLOCK_SLEEPRQ", "BLOCK_TOUCH_BUFFER", "BLOCK_BIO_BOUNCE", "BLOCK_BIO_FRONTMERGE", "BLOCK_BIO_REMAP", "BLOCK_GETRQ", "BLOCK_RQ_COMPLETE", "BLOCK_RQ_ISSUE", "BLOCK_RQ_REQUEUE", "BLOCK_SPLIT", "BLOCK_UNPLUG"])

code, tags = d.checklist("What sandwich toppings do you like?",
    choices=[
        ("BLOCK_BIO_BACKMERGE", "", True),
        ("BLOCK_BIO_COMPLETE", "", True),
        ("BLOCK_BIO_QUEUE", "", True),
        ("BLOCK_DIRTY_BUFFER", "", True),
        ("BLOCK_PLUG", "", True),
        ("BLOCK_RQ_INSERT", "", True),
        ("BLOCK_RQ_REMAP", "", True),
        ("BLOCK_SLEEPRQ", "", True),
        ("BLOCK_TOUCH_BUFFER", "", True),
        ("BLOCK_BIO_BOUNCE", "", True),
        ("BLOCK_BIO_FRONTMERGE", "", True),
        ("BLOCK_BIO_REMAP", "", True),
        ("BLOCK_GETRQ", "", True),
        ("BLOCK_RQ_COMPLETE", "", True),
        ("BLOCK_RQ_ISSUE", "", True),
        ("BLOCK_RQ_REQUEUE", "", True),
        ("BLOCK_SPLIT", "", True),
        ("BLOCK_UNPLUG", "", True),
    ],
    title="Do you prefer ham or spam?",
    backtitle="And now, for something "
    "completely different...")

if code == d.CANCEL:
    sys.exit(0);

detachlist = allset - set(tags)



with open('../share/event.c', 'r') as content_file:
    file_content = content_file.read()

file_content = file_content.replace("MAJOR_VALUE", "8");
file_content = file_content.replace("MINOR_VALUE", "0");
b = BPF(text=file_content)

EVENT_TYPE = {
        0:'unknown',
        1:'BLOCK_BIO_BACKMERGE',
        2:'BLOCK_BIO_COMPLETE',
        3:'BLOCK_BIO_QUEUE',
        4:'BLOCK_DIRTY_BUFFER',
        5:'BLOCK_PLUG',
        6:'BLOCK_RQ_INSERT',
        7:'BLOCK_RQ_REMAP',
        8:'BLOCK_SLEEPRQ',
        9:'BLOCK_TOUCH_BUFFER',
        10:'BLOCK_BIO_BOUNCE',
        11:'BLOCK_BIO_FRONTMERGE',
        12:'BLOCK_BIO_REMAP',
        13:'BLOCK_GETRQ',
        14:'BLOCK_RQ_COMPLETE',
        15:'BLOCK_RQ_ISSUE',
        16:'BLOCK_RQ_REQUEUE',
        17:'BLOCK_SPLIT',
        18:'BLOCK_UNPLUG',
        19:'VFS_WRITE_START',
        20:'VFS_WRITE_END'
        }

for detach in detachlist:
    print("block:"+ detach.lower())
    b.detach_tracepoint("block:"+detach.lower())

def printf(fmt, *args):
    sys.stdout.write(fmt % args)

def print_event(cpu, data, size):
    event = ct.cast(data, ct.POINTER(Data)).contents

    event.cpu = cpu;
    event.sec = event.time / 1000000000;

    printf("|%18.9f|%-20s|%3d|%5d|%5d|%5d|%5d|%10d|%11d|\n", event.sec, EVENT_TYPE[event.type], event.cpu, event.pid>>32, event.pid&0xFFFFFFFF, event.dev>>20, event.dev&((1<<20)-1), event.off, event.len);

b["events"].open_perf_buffer(print_event, page_cnt=1024*64)
while 1:
    try:
        b.perf_buffer_poll()
    except KeyboardInterrupt:
        exit()
