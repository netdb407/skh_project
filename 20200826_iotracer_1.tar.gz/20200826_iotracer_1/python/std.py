#!/usr/bin/env python

from functional import seq
import math
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('flow')
parser.add_argument('window')
parser.add_argument('dmdu')

args = parser.parse_args()

print("latency_avg,latency_std,kernel_avg,kernel_std,driver_avg,driver_std,device_avg,device_std,tail_latency_95,tail_latency_99,tail_latency_99.99,mbps,iops,gc_avg,gc_std,waf_avg,waf_std,nand_write_avg,nand_write_std")


def avg_std(lst):
    nr = lst.len()
    mean = lst.average()
    var_min = lst.cartesian([mean])
    var_sum = var_min.map(lambda x: x[0] - x[1]).map(lambda x: x*x).sum()
    return [mean, math.sqrt(var_sum/nr)]

def longlatency(lst):
    l = lst.len()
    n = [0.95, 0.99, 0.9999]
    sort = lst.sorted()
    ret = []
    for item in n:
        ret.append(sort[int(l*item)])

    return ret
    
f = seq.csv(args.flow).tail()

result = []

for i in range(2, 6):
    latency = f.map(lambda x: float(x[i]))
    result.extend(avg_std(latency))

#print(result)

result.extend(longlatency(f.map(lambda x: float(x[2]))))

f = seq.csv(args.window).tail()
mbps = f.map(lambda x: float(x[2])).sum()
iops = f.map(lambda x: float(x[1])).sum()
first = f.map(lambda x: float(x[0])).first()
last = f.map(lambda x: float(x[0])).last()
dif = last - first + 10
result.extend([mbps/dif/1024/1024, iops/dif])

f = seq.csv(args.dmdu).tail()
gc = f.map(lambda x: float(x[3]))
waf = f.map(lambda x: float(x[2]))
nand = f.map(lambda x: float(x[4]))

result.extend(avg_std(gc))
result.extend(avg_std(waf))
result.extend(avg_std(nand))

print(result)
