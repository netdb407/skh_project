#!/usr/bin/env python

import pandas
from matplotlib import pyplot
import argparse
import datetime
from pandas.plotting import register_matplotlib_converters
import matplotlib.dates as mdates
register_matplotlib_converters()

parser = argparse.ArgumentParser()
parser.add_argument('-i', '--iotracer', action='append', required=True)

args = parser.parse_args()

g_all_length = 14*len(args.iotracer)
g_idx = 0
g_fig, g_ax = pyplot.subplots(g_all_length, 1)

def append_axis(title, date, series):
    global g_idx
    g_ax[g_idx].plot_date(date, series, 'b-')
    g_ax[g_idx].set_ylabel(title)
    g_ax[g_idx].xaxis.set_visible(False)
    g_ax[g_idx].yaxis.set_label_position("right")
    #ax[g_dix].set_xlim(left=datetime.datetime.fromtimestamp(0), right=max_date)
    g_idx = g_idx + 1

def append_line():
    global g_idx
    line = 

def trace(trace):
    #global max_date
    series = pandas.read_csv(trace)
    PLOT_DATE = list(map(datetime.datetime.fromtimestamp, series["Window Time"]))
    print(PLOT_DATE[-1])
    #if max_date < PLOT_DATE[-1]:
    #    max_date = PLOT_DATE[-1]

    TITLE=["Number of IO","Size of IO","Latency","Kernel Time","Driver Time","Device Time"]
    length = len(TITLE)
    for i in range(length):
        append_axis(TITLE[i], PLOT_DATE, series[TITLE[i]])

def dmdu(dmdu):
    #global max_date
    series = pandas.read_csv(dmdu)
    PLOT_DATE = list(map(datetime.datetime.fromtimestamp, series["time"]))
    print("dmdu", PLOT_DATE[-1])
    #if max_date < PLOT_DATE[-1]:
    #    max_date = PLOT_DATE[-1]

    TITLE=["delta_disk_usage","waf","gc","nand_write"]
    length = len(TITLE)
    for i in range(length):
        original = list(series[TITLE[i]])
        data = []
        s = 0
        for item in original:
            s = s+item
            data.append(s)
        series["acc_"+TITLE[i]] = data

    TITLE=["delta_disk_usage","acc_delta_disk_usage", "waf", "acc_waf" ,"gc", "acc_gc", "nand_write", "acc_nand_write"]
    length = len(TITLE)
    for i in range(length):
        append_axis(TITLE[i], PLOT_DATE, series[TITLE[i]])


for path in args.iotracer:
    trace(path+"/trace.csv")
    dmdu(path+"/dmdu.csv")

#parser.add_argument('trace1')
#parser.add_argument('dmdu1')
#parser.add_argument('trace2')
#parser.add_argument('dmdu2')
#parser.add_argument('trace3')
#parser.add_argument('dmdu3')

#print(args)
#print(args.iotracer)
# 14*3
#all_length = len(all_title)
#max_date = datetime.datetime.fromtimestamp(0)

def date_fn(arg1):
    return datetime.datetime.fromtimestamp(arg1/1000) + datetime.timedelta(seconds=args.difftime)
def ycbs(ycbs, start_idx):
    global max_date
    gr = pandas.read_csv(ycbs).groupby("OPERATION")

    TITLE=["INSERT", "READ", "READ-FAILED"]
    length = len(TITLE)
    try:
        for i in range(length):
            series = gr.get_group(TITLE[i])
            date = list(map(date_fn, series["TIME"]))
            if max_date < date[-1]:
                max_date = date[-1]
            print(date[-1])
            ax[i+start_idx].plot_date(date, series["LATENCY"], 'b-')
            ax[i+start_idx].set_ylabel(TITLE[i])
    except:
        pass

g_ax[g_all_length-1].xaxis.set_visible(True)
g_ax[g_all_length-1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))

g_fig.set_size_inches(18, 120)
g_fig.savefig("nice.png")
