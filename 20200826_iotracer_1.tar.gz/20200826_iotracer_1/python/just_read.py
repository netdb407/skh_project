#!/usr/bin/env python

from ctypes import *
import sys

def printf(fmt, * args):
  sys.stdout.write(fmt % args)

EVENT_TYPE = {
  0: 'unknown',
  1: 'BLOCK_BIO_BACKMERGE',
  2: 'BLOCK_BIO_COMPLETE',
  3: 'BLOCK_BIO_QUEUE',
  4: 'BLOCK_DIRTY_BUFFER',
  5: 'BLOCK_PLUG',
  6: 'BLOCK_RQ_INSERT',
  7: 'BLOCK_RQ_REMAP',
  8: 'BLOCK_SLEEPRQ',
  9: 'BLOCK_TOUCH_BUFFER',
  10: 'BLOCK_BIO_BOUNCE',
  11: 'BLOCK_BIO_FRONTMERGE',
  12: 'BLOCK_BIO_REMAP',
  13: 'BLOCK_GETRQ',
  14: 'BLOCK_RQ_COMPLETE',
  15: 'BLOCK_RQ_ISSUE',
  16: 'BLOCK_RQ_REQUEUE',
  17: 'BLOCK_SPLIT',
  18: 'BLOCK_UNPLUG',
  19: 'VFS_WRITE_START',
  20: 'VFS_WRITE_END',
  21: 'NVME_SQ',
  22: 'NVME_COMPLETE_RQ'
}

class YourStruct(Structure):
  _fields_ = [('type', c_int), ('time', c_ulonglong), ('dev', c_int), ('pid', c_ulonglong), ('off', c_int), ('len', c_int)]

with open('/home/biosvos/workspace/disksnoop/c/output/trace.log', 'rb') as file:
  item = YourStruct()
  while file.readinto(item) == sizeof(item):
    printf("|%18.9f|%-20s|%5d|%5d|%5d|%5d|%10d|%11d|\n", item.time / 1000000000, EVENT_TYPE[item.type], item.pid >> 32, item.pid & 0xFFFFFFFF, item.dev >> 20, item.dev & ((1 << 20) - 1), item.off, item.len);
