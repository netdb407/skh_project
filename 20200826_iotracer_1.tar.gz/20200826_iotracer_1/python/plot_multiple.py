#!/usr/bin/env python

import pandas
from matplotlib import pyplot
import argparse
import datetime
from pandas.plotting import register_matplotlib_converters
import matplotlib.dates as mdates
register_matplotlib_converters()

parser = argparse.ArgumentParser()
parser.add_argument('ycsb')
parser.add_argument('difftime', type=int)
parser.add_argument('trace1')
parser.add_argument('dmdu1')
parser.add_argument('trace2')
parser.add_argument('dmdu2')
parser.add_argument('trace3')
parser.add_argument('dmdu3')

args = parser.parse_args()

max_date = datetime.datetime.fromtimestamp(0)
min_date = datetime.datetime.fromtimestamp(0)

def series_max_min(se):
    count = int(se.count()*0.01)
    ma = se.nlargest(count).tail(1)
    mi = se.nsmallest(count).tail(1)
    return (ma.values[0], mi.values[0])

def setting_axis(axis, title, date, series, color="C0"):
    global max_date, min_date
    #ma, mi = series_max_min(series)
    #print(date.index(min_date))
    new_date = list(filter(lambda x: x> min_date, date))
    dif = len(date) - len(new_date)
    #print(series[dif:])
    #axis.set_ylim(top=ma, bottom=mi)
    #axis.plot_date(date, series, 'b-', c=color)
    #axis.plot_date(date, series, c=color, ms=1)
    #axis.plot_date(new_date, series[dif:], c=color, ms=1)
    axis.plot_date(new_date, series[dif:], 'b-', c=color, ms=1)
    axis.set_ylabel(title)
    axis.xaxis.set_visible(False)
    axis.yaxis.set_label_position("right")

    #print(date.describe())
    #print(series.describe())
    #print(series.get[min_date])
    axis.set_xlim(left=min_date, right=max_date)

def date_fn(arg1):
    return datetime.datetime.fromtimestamp(arg1/1000) + datetime.timedelta(seconds=args.difftime)

def ycsb(ycbs):
    global max_date, min_date
    gr = pandas.read_csv(ycbs).groupby("OPERATION")

    TITLE=["INSERT", "READ", "READ-FAILED"]
    length = len(TITLE)
    fig, ax = pyplot.subplots(6, 1)
#    try:
    for i in range(length):
        series = gr.get_group(TITLE[i])
        date = list(map(date_fn, series["TIME"]))
        max_date = date[-1]
        min_date = date[0]
        #setting_axis(ax[i], TITLE[i], date, series["LATENCY"])
        setting_axis(ax[i*2], TITLE[i], date, series["LATENCY"])
        setting_axis(ax[i*2+1], TITLE[i] + "ops", date, series["WHAT"])
        #ax.set_legend(loc="upper right")
    fig.set_size_inches(25.6, 9.6)
    print(fig.get_size_inches())
    #fig.legend(loc="upper right")
#    except:
#        pass
#    ax[2].xaxis.set_visible(True)
#    ax[2].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
    fig.savefig("ycsb.png")

ycsb(args.ycsb)

def expand_dmdu(dmdu):
    series = pandas.read_csv(dmdu)
    TITLE=["delta_disk_usage","waf","gc","nand_write"]
    length = len(TITLE)
    for i in range(length):
        original = list(series[TITLE[i]])
        data = []
        s = 0
        for item in original:
            s = s+item
            data.append(s)
        series["acc_"+TITLE[i]] = data
    
    return series

seriesA = pandas.read_csv(args.trace1)
dateA = list(map(datetime.datetime.fromtimestamp, seriesA["Window Time"]))

seriesB = pandas.read_csv(args.trace2)
dateB = list(map(datetime.datetime.fromtimestamp, seriesB["Window Time"]))

seriesC = pandas.read_csv(args.trace3)
dateC = list(map(datetime.datetime.fromtimestamp, seriesC["Window Time"]))


TITLE=["Number of IO","Size of IO","Latency","Kernel Time","Driver Time","Device Time"]
length = len(TITLE)
for i in range(length):
    fig, ax = pyplot.subplots(1, 1)
    setting_axis(ax, TITLE[i], dateA, seriesA[TITLE[i]], "C0")
    setting_axis(ax, TITLE[i], dateB, seriesB[TITLE[i]], "C1")
    setting_axis(ax, TITLE[i], dateC, seriesC[TITLE[i]], "C2")

    if TITLE[i] == "Latency":
        print(seriesA["Latency"].std())
        print(seriesA["Latency"].mean())
        std = seriesA["Latency"].std()
        mean = seriesA["Latency"].mean()
        #setting_axis(ax, TITLE[i], [min_date, max_date], [std+mean, std+mean], "C5")
        ax.plot_date([min_date, max_date], [std+mean, std+mean], 'b-', c="C3", ms=1)
        ax.plot_date([min_date, max_date], [std-mean, std-mean], 'b-', c="C3", ms=1)
        #std = seriesA["Latency"].std()
        #ax.errorbar(dateA, seriesA[TITLE[i]], std, linestyle='None', marker='^')
        #setting_axis(ax, TITLE[i], dateC, seriesC[TITLE[i]], "C2")


    m = []
    n = []
    ma, mi = series_max_min(seriesA[TITLE[i]])
    m.append(ma)
    n.append(mi)
    ma, mi = series_max_min(seriesB[TITLE[i]])
    m.append(ma)
    n.append(mi)
    ma, mi = series_max_min(seriesC[TITLE[i]])
    m.append(ma)
    n.append(mi)
    #ax.set_ylim(top=max(m), bottom=min(n))

    ax.xaxis.set_visible(True)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))

    fig.set_size_inches(25.6, 4.8)
    print(fig.get_size_inches())
    fig.legend(["node1", "node2", "node3"], loc="upper right")
    fig.savefig(TITLE[i] + ".png")

dmdu_a = expand_dmdu(args.dmdu1)
dmdu_date_a = list(map(datetime.datetime.fromtimestamp, dmdu_a["time"]))

dmdu_b = expand_dmdu(args.dmdu2)
dmdu_date_b = list(map(datetime.datetime.fromtimestamp, dmdu_b["time"]))

dmdu_c = expand_dmdu(args.dmdu3)
dmdu_date_c = list(map(datetime.datetime.fromtimestamp, dmdu_c["time"]))

TITLE=["delta_disk_usage","acc_delta_disk_usage", "waf", "acc_waf" ,"gc", "acc_gc", "nand_write", "acc_nand_write"]
length = len(TITLE)
for i in range(length):
    fig, ax = pyplot.subplots(1, 1)
    setting_axis(ax, TITLE[i], dmdu_date_a, dmdu_a[TITLE[i]], "C0")
    setting_axis(ax, TITLE[i], dmdu_date_b, dmdu_b[TITLE[i]], "C1")
    setting_axis(ax, TITLE[i], dmdu_date_c, dmdu_c[TITLE[i]], "C2")

    m = []
    n = []
    ma, mi = series_max_min(dmdu_a[TITLE[i]])
    m.append(ma)
    n.append(mi)
    ma, mi = series_max_min(dmdu_b[TITLE[i]])
    m.append(ma)
    n.append(mi)
    ma, mi = series_max_min(dmdu_c[TITLE[i]])
    m.append(ma)
    n.append(mi)
    #ax.set_ylim(top=max(m), bottom=min(n))

    ax.xaxis.set_visible(True)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))

    fig.set_size_inches(25.6, 4.8)
    print(fig.get_size_inches())
    fig.legend(["node1", "node2", "node3"], loc="upper right")
    fig.savefig(TITLE[i] + ".png")
