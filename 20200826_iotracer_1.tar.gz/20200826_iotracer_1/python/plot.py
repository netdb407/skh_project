#!/usr/bin/env python

import pandas
from matplotlib import pyplot
import argparse
import datetime
from pandas.plotting import register_matplotlib_converters
import matplotlib.dates as mdates
register_matplotlib_converters()

parser = argparse.ArgumentParser()
parser.add_argument('trace1')
parser.add_argument('dmdu1')
parser.add_argument('trace2')
parser.add_argument('dmdu2')
parser.add_argument('trace3')
parser.add_argument('dmdu3')

args = parser.parse_args()

# 14*3
#all_length = len(all_title)
all_length = 42
print(all_length)
fig, ax = pyplot.subplots(all_length, 1)
max_date = datetime.datetime.fromtimestamp(0)

def date_fn(arg1):
    return datetime.datetime.fromtimestamp(arg1/1000) + datetime.timedelta(seconds=args.difftime)

def trace(trace, start_idx):
    global max_date
    series = pandas.read_csv(trace)
    PLOT_DATE = list(map(datetime.datetime.fromtimestamp, series["Window Time"]))
    print(PLOT_DATE[-1])
    if max_date < PLOT_DATE[-1]:
        max_date = PLOT_DATE[-1]

    TITLE=["Number of IO","Size of IO","Latency","Kernel Time","Driver Time","Device Time"]
    length = len(TITLE)
    for i in range(length):
        ax[i+start_idx].plot_date(PLOT_DATE, series[TITLE[i]], 'b-')
        ax[i+start_idx].set_ylabel(TITLE[i])

def dmdu(dmdu, start_idx):
    global max_date
    series = pandas.read_csv(dmdu)
    PLOT_DATE = list(map(datetime.datetime.fromtimestamp, series["time"]))
    print("dmdu", PLOT_DATE[-1])
    if max_date < PLOT_DATE[-1]:
        max_date = PLOT_DATE[-1]

    TITLE=["delta_disk_usage","waf","gc","nand_write"]
    length = len(TITLE)
    for i in range(length):
        original = list(series[TITLE[i]])
        data = []
        s = 0
        for item in original:
            s = s+item
            data.append(s)
        series["acc_"+TITLE[i]] = data

    TITLE=["delta_disk_usage","acc_delta_disk_usage", "waf", "acc_waf" ,"gc", "acc_gc", "nand_write", "acc_nand_write"]
    length = len(TITLE)
    for i in range(length):
        ax[i+start_idx].plot_date(PLOT_DATE, series[TITLE[i]], 'b-')
        ax[i+start_idx].set_ylabel(TITLE[i])

def ycbs(ycbs, start_idx):
    global max_date
    gr = pandas.read_csv(ycbs).groupby("OPERATION")

    TITLE=["INSERT", "READ", "READ-FAILED"]
    length = len(TITLE)
    try:
        for i in range(length):
            series = gr.get_group(TITLE[i])
            date = list(map(date_fn, series["TIME"]))
            if max_date < date[-1]:
                max_date = date[-1]
            print(date[-1])
            ax[i+start_idx].plot_date(date, series["LATENCY"], 'b-')
            ax[i+start_idx].set_ylabel(TITLE[i])
    except:
        pass

trace(args.trace1, 0)
dmdu(args.dmdu1, 6)
trace(args.trace2, 14)
dmdu(args.dmdu2, 20)
trace(args.trace3, 28)
dmdu(args.dmdu3, 34)

for i in range(all_length):
    ax[i].xaxis.set_visible(False)
    ax[i].yaxis.set_label_position("right")
    ax[i].set_xlim(left=datetime.datetime.fromtimestamp(0), right=max_date)

ax[all_length-1].xaxis.set_visible(True)
ax[all_length-1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
pyplot.show()

fig.set_size_inches(18, 120)
fig.savefig("nice.png")
