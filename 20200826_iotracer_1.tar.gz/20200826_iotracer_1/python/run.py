#!/usr/bin/env python
from bcc import BPF
import sys # for exit
import os

if not os.geteuid() == 0:
    sys.exit("run app as root");

class cio:
    def __init__(self, event):
        self.vfs_start = True
        self.vfs_end   = False

        self.insert   = False
        self.complete = False

        self.track = [event]
        self.sector = set()
        self.write_size = event.len

    def sector_is_in(self, sector):
        return sector in self.sector

    def append(self, event):
        if event.type == 20: # VFS_END
            self.vfs_end = True

        if event.type == 14: # RQ_COMPLETE
            self.complete = True
            self.write_size = self.write_size - (event.len*512)

        if event.type == 6: # RQ_INSERT
            self.insert = True
            self.sector.add(event.off)

        self.track.append(event)

    def is_end(self):
        return self.write_size <= 0 and self.vfs_end and self.complete and self.insert

    def pr(self):
        print_list(self.track)


io_track = {};
b = BPF(src_file="../share/event.c")

#b.attach_kprobe(event="vfs_write", fn_name="on_write_start")
#b.attach_kretprobe(event="vfs_write", fn_name="on_write_end")

EVENT_TYPE = {
        0:'unknown',
        1:'BLOCK_BIO_BACKMERGE',
        2:'BLOCK_BIO_COMPLETE',
        3:'BLOCK_BIO_QUEUE',
        4:'BLOCK_DIRTY_BUFFER',
        5:'BLOCK_PLUG',
        6:'BLOCK_RQ_INSERT',
        7:'BLOCK_RQ_REMAP',
        8:'BLOCK_SLEEPRQ',
        9:'BLOCK_TOUCH_BUFFER',
        10:'BLOCK_BIO_BOUNCE',
        11:'BLOCK_BIO_FRONTMERGE',
        12:'BLOCK_BIO_REMAP',
        13:'BLOCK_GETRQ',
        14:'BLOCK_RQ_COMPLETE',
        15:'BLOCK_RQ_ISSUE',
        16:'BLOCK_RQ_REQUEUE',
        17:'BLOCK_SPLIT',
        18:'BLOCK_UNPLUG',
        19:'VFS_WRITE_START',
        20:'VFS_WRITE_END'
        }

def event_start(event):
    if event.pid in io_track:
        io_track[event.pid].append(event)
    else :
        io_track[event.pid] = cio(event)

def just_add(event):
    if event.pid == 0:
        print("pid zero")

    if event.pid in io_track:
        io_track[event.pid].append(event)
        if io_track[event.pid].is_end():
            io_track[event.pid].pr()
            del io_track[event.pid]

def missing_pid(event):
    for key, io in io_track.items():
        if io.sector_is_in(event.off):
            io.append(event)
            if io.is_end():
                io.pr()
                del io_track[key]
            break

def nothing(event):
    pass

EVENT_FN = {
        'unknown'              : nothing,
        'BLOCK_BIO_BACKMERGE'  : just_add,
        'BLOCK_BIO_COMPLETE'   : just_add,
        'BLOCK_BIO_QUEUE'      : just_add,
        'BLOCK_DIRTY_BUFFER'   : nothing,
        'BLOCK_PLUG'           : just_add,
        'BLOCK_RQ_INSERT'      : just_add,
        'BLOCK_RQ_REMAP'       : just_add,
        'BLOCK_SLEEPRQ'        : just_add,
        'BLOCK_TOUCH_BUFFER'   : nothing,
        'BLOCK_BIO_BOUNCE'     : just_add,
        'BLOCK_BIO_FRONTMERGE' : just_add,
        'BLOCK_BIO_REMAP'      : just_add,
        'BLOCK_GETRQ'          : just_add,
        'BLOCK_RQ_COMPLETE'    : missing_pid,
        'BLOCK_RQ_ISSUE'       : just_add,
        'BLOCK_RQ_REQUEUE'     : just_add,
        'BLOCK_SPLIT'          : just_add,
        'BLOCK_UNPLUG'         : just_add,
        'VFS_WRITE_START'      : event_start,
        'VFS_WRITE_END'        : just_add
        }

def printf(fmt, *args):
    sys.stdout.write(fmt % args)

def print_list(l):
    printf("\n|%18s|%-20s|%3s|%5s|%5s|%5s|%5s|%10s|%11s|etc\n", 
            "time", "type", "cpu", "tgid", "pid",  "major",  "minor",  "sector",  "len")
    for event in l:
        printf("|%18.9f|%-20s|%3d|%5d|%5d|%5d|%5d|%10d|%11d|\n",
                event.sec, EVENT_TYPE[event.type], event.cpu, event.pid>>32, event.pid&0xFFFFFFFF, event.dev>>20, event.dev&((1<<20)-1), event.off, event.len);

def print_event(cpu, data, size):
    event = b["events"].event(data)

    event.cpu = cpu;
    event.sec = event.time / 1000000000;

    print("%-18.9f" % (event.sec), "{0: <22}".format(EVENT_TYPE[event.type]), event.cpu, event.pid>>32, event.pid&0xFFFFFFFF, event.dev>>20, event.dev&((1<<20)-1), event.off, event.len);

    #EVENT_FN[EVENT_TYPE[event.type]](event)

b["events"].open_perf_buffer(print_event, page_cnt=1024*64)
while 1:
    try:
        b.perf_buffer_poll()
    except KeyboardInterrupt:
        exit()
