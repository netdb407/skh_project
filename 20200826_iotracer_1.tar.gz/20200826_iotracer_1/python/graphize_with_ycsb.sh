#!/bin/bash
set -euo pipefail

path=/home/biosvos/xfs/facebook
csv=facebook.csv
time=14709

#path=/home/biosvos/xfs/news
#csv=news.csv
#time=14523

#path=/home/biosvos/xfs/contents
#csv=caching.csv
#time=11341

./plot_multiple.py $csv $time $path/193/trace.csv $path/193/dmdu.csv $path/194/trace.csv $path/194/dmdu.csv $path/195/trace.csv $path/195/dmdu.csv
