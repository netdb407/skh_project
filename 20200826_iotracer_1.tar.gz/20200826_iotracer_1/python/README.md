pacman -S dialog
pip install pythondialog
