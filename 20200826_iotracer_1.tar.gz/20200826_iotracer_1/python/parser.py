#!/usr/bin/python
# -*- coding: utf-8 -*-

from ctypes import *
import sys
import argparse
import sys
import codecs, json

parser = argparse.ArgumentParser()
parser.add_argument('LogDirectory')
args = parser.parse_args()

WINDOW_SIZE = 1
last_window = 0
g_windows = []
g_windows.append({
    'latency': 0.0,
    'kernel_time': 0.0,
    'driver_time': 0.0,
    'device_time': 0.0,
    'io_size': 0
    })


class cio:

    def __init__(self, event):
        self.track = [event]
        self.write_size = event.len
        self.complete = False
        self.cq = False

    def append(self, event):
        if event.type == 14:  # RQ_COMPLETE
            self.complete = True
            self.write_size = self.write_size - event.len

        if event.type == 22:  # CQ
            self.cq = True

        self.track.append(event)

    def extend(self, event):
        self.track.extend(event)
        self.write_size = self.write_size + event[0].len

    def is_end(self):
        return self.write_size <= 0 and self.complete and self.cq

    def pr(self):
        print_list(self.track)


io_track = {}


def printf(fmt, *args):
    sys.stdout.write(fmt % args)


EVENT_TYPE = {
    0: 'unknown',
    1: 'BLOCK_BIO_BACKMERGE',
    2: 'BLOCK_BIO_COMPLETE',
    3: 'BLOCK_BIO_QUEUE',
    4: 'BLOCK_DIRTY_BUFFER',
    5: 'BLOCK_PLUG',
    6: 'BLOCK_RQ_INSERT',
    7: 'BLOCK_RQ_REMAP',
    8: 'BLOCK_SLEEPRQ',
    9: 'BLOCK_TOUCH_BUFFER',
    10: 'BLOCK_BIO_BOUNCE',
    11: 'BLOCK_BIO_FRONTMERGE',
    12: 'BLOCK_BIO_REMAP',
    13: 'BLOCK_GETRQ',
    14: 'BLOCK_RQ_COMPLETE',
    15: 'BLOCK_RQ_ISSUE',
    16: 'BLOCK_RQ_REQUEUE',
    17: 'BLOCK_SPLIT',
    18: 'BLOCK_UNPLUG',
    19: 'VFS_WRITE_START',
    20: 'VFS_WRITE_END',
    21: 'NVME_SQ',
    22: 'NVME_COMPLETE_RQ',
    }


class YourStruct(Structure):

    _fields_ = [
        ('type', c_int),
        ('time', c_ulonglong),
        ('dev', c_int),
        ('pid', c_ulonglong),
        ('off', c_int),
        ('len', c_int),
        ]


with open(args.LogDirectory + '/trace.log', 'rb') as file:
    result = []
    x = YourStruct()
    while file.readinto(x) == sizeof(x):
        result.append(x)
        x = YourStruct()


def event_start(event):
    if event.pid in io_track:
        print("hey")
        io_track[event.off].append(event)
    else:
        io_track[event.off] = cio(event)

printf(
'|%s|%s|%s|%11s|%s|%s|%s|\n'
, "Window Time", "Number of IO", "Size of IO", "Average", "Kernel Time", "Driver Time", "Device Time")

g_records = {}
g_records['records'] = [] 
def SAVE_AS_JSON(wind):
    rec = g_records['records']
    rec.append({
            'Window Time' : last_window * WINDOW_SIZE,
            'Number of IO' : len(g_windows),
            'Size of IO' : wind['io_size'],
            'Latency' : wind['latency'] / float(len(g_windows)),
            'Kernel Time' : wind['kernel_time'] / float(len(g_windows)),
            'Driver Time' : wind['driver_time'] / float(len(g_windows)),
            'Device Time' : wind['device_time'] / float(len(g_windows))
            })

def just_add(event):
    global g_windows
    global last_window

    if event.off in io_track:
        io = io_track[event.off]
        io.append(event)
        if io.is_end():
            first = io.track[0]
            last = io.track[-1]
            window = int(last.sec / WINDOW_SIZE)
            if window == last_window:
                kernel_time = 0.0
                driver_time = 0.0
                device_time = 0.0
                io_size = 0
                for item in io.track:
                    if item.type == 6 or item.type == 1 or item.type \
                        == 13:  # Insert or Backmerge or GetQ
                        kernel_time = item.sec
                    if item.type == 21:  # SQ
                        driver_time = item.sec
                    if item.type == 14:  # BLOCK_RQ_COMPLETE
                        device_time = item.sec
                        io_size = item.len
                device_time = device_time - driver_time
                if device_time < 0:
                  io.pr()
                  sys.exit(-1)
                driver_time = driver_time - kernel_time
                kernel_time = kernel_time - first.sec
                g_windows.append({
                    'latency': last.sec - first.sec,
                    'kernel_time': kernel_time,
                    'driver_time': driver_time,
                    'device_time': device_time,
                    'io_size': io_size
                    })
            else:
                sum_window = {
                    'latency': 0.0,
                    'kernel_time': 0.0,
                    'driver_time': 0.0,
                    'device_time': 0.0,
                    'io_size': 0
                    }
                for w in g_windows:
                    sum_window['latency'] = sum_window['latency'] \
                        + w['latency']
                    sum_window['kernel_time'] = sum_window['kernel_time'
                            ] + w['kernel_time']
                    sum_window['driver_time'] = sum_window['driver_time'
                            ] + w['driver_time']
                    sum_window['device_time'] = sum_window['device_time'
                            ] + w['device_time']
                    sum_window['io_size'] = sum_window['io_size'
                            ] + w['io_size']

                SAVE_AS_JSON(sum_window);
                g_windows = []

                kernel_time = 0.0
                driver_time = 0.0
                device_time = 0.0
                io_size = 0
                for item in io.track:
                    if item.type == 6 or item.type == 1 or item.type \
                        == 13:  # Insert or Backmerge or GetQ
                        kernel_time = item.sec
                    if item.type == 21:  # SQ
                        driver_time = item.sec
#                    if item.type == 22:  # CQ  ##### CQ가 마지막이 아니여서 뺌
#                        device_time = item.sec
                    if item.type == 14:  # BLOCK_RQ_COMPLETE
                        device_time = item.sec
                        io_size = item.len

                device_time = device_time - driver_time
                driver_time = driver_time - kernel_time
                kernel_time = kernel_time - first.sec

                g_windows.append({
                    'latency': last.sec - first.sec,
                    'kernel_time': kernel_time,
                    'driver_time': driver_time,
                    'device_time': device_time,
                    'io_size': io_size
                    })

                last_window = window

            del io_track[event.off]


def back_merge(event):
    if event.off in io_track:
        io = io_track[event.off]
        io.append(event)

        diff = 8
        while True:
            if event.off - diff in io_track:
                back = io_track[event.off - diff]
                back.extend(io.track)
                del io_track[event.off]
                break
            diff = diff + 8

def bio_split(event):
    if event.off in io_track:
        diff = event.len - event.off

        aio = io_track[event.off]
        ori_len = aio.track[0].len
        aio.write_size = diff

        bio = YourStruct()
        bio.type = 12  # BLOCK_REMAP
        bio.time = aio.track[0].time
        bio.sec = bio.time/1000000000
        bio.dev = aio.track[0].dev
        bio.pid = aio.track[0].pid
        bio.off = event.len
        bio.len = ori_len - diff
        event_start(bio)


def nothing(event):
    pass


def print_list(l):
    printf(
        '''
|%18s|%-20s|%5s|%5s|%5s|%5s|%10s|%11s|
''',
        'time',
        'type',
        'tgid',
        'pid',
        'major',
        'minor',
        'sector',
        'len',
        )
    for item in l:
        printf(
            '|%18.9f|%-20s|%5d|%5d|%5d|%5d|%10d|%11d|\n',
            item.time / 1000000000,
            EVENT_TYPE[item.type],
            item.pid >> 32,
            item.pid & 0xFFFFFFFF,
            item.dev >> 20,
            item.dev & (1 << 20) - 1,
            item.off,
            item.len,
            )

EVENT_FN = {
    'unknown': nothing,
    'BLOCK_BIO_BACKMERGE': back_merge,
    'BLOCK_BIO_COMPLETE': just_add,
    'BLOCK_BIO_QUEUE': just_add,
    'BLOCK_DIRTY_BUFFER': nothing,
    'BLOCK_PLUG': just_add,
    'BLOCK_RQ_INSERT': just_add,
    'BLOCK_RQ_REMAP': just_add,
    'BLOCK_SLEEPRQ': just_add,
    'BLOCK_TOUCH_BUFFER': nothing,
    'BLOCK_BIO_BOUNCE': just_add,
    'BLOCK_BIO_FRONTMERGE': just_add,
    'BLOCK_BIO_REMAP': event_start,
    'BLOCK_GETRQ': just_add,
    'BLOCK_RQ_COMPLETE': just_add,
    'BLOCK_RQ_ISSUE': just_add,
    'BLOCK_RQ_REQUEUE': just_add,
    'BLOCK_SPLIT': bio_split,
    'BLOCK_UNPLUG': just_add,
    'VFS_WRITE_START': event_start,
    'VFS_WRITE_END': just_add,
    'NVME_SQ': just_add,
    'NVME_COMPLETE_RQ': just_add,
    }

for item in result:
    item.sec = item.time / 1000000000
    EVENT_FN[EVENT_TYPE[item.type]](item)

print(json.dumps(g_records, indent=4))
