#!/bin/bash
set -euo pipefail

path=/home/biosvos/xfs/facebook

./plot.py $path/193/trace.csv $path/193/dmdu.csv $path/194/trace.csv $path/194/dmdu.csv $path/195/trace.csv $path/195/dmdu.csv
