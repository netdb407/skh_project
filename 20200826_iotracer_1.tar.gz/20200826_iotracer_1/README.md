# Archlinux
## 기본 툴 설치
```
pacman -S python-virtualenv netperf iperf3 llvm linux-headers git cmake clang base-devel jq libbsd --noconfirm --needed
skhynix 드라이브 매니저 설치
```
## install bcc
```
git clone --depth=1 https://github.com/iovisor/bcc.git
mkdir bcc/build; cd bcc/build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr
make -j$(nproc)
sudo make install
```

## iotracer build
```
cd /PATH/TO/iotracer
mkdir build
cd build
cmake ..
make
```
# Fedora30
## source 기반 설치
```
dnf upgrade
dnf groupinstall "Development Tools"
dnf install cmake bcc-devel gcc-c++ libblkid-devel
```
## rpm 기반 설치
```
dnf upgrade
reboot
dnf install iotracer.rpm # dependency에 의해 repository 접근이 가능하여야 함
```

# Centos7(개발중)
## 기본 툴 설치
```
yum install deltarpm
yum upgrade
yum groupinstall "Development Tools"
yum install bcc-devel cmake libblkid-devel
```
## disksnoop build
patch -p1 < centos7.patch
- 기본적으로 Archlinux disksnoop build와 같으며, 에러가 나는 부분에 대해서 CMakeLists.txt가 변경되야 함

# 공통
## 실행 파일
### /usr/local/bin/iotracer
```
Usage: [OPTION...] <watch directory> 

        -o, --output value            log for tracing data
        -m, --dm value                skhynix device manager path
        -d, --disable_dm              disable skhynix device manager
        -i, --interval value          device manager interval
        -D, --daemon                  daemonize
        -b, --buffer value            buffer size for file write
        <watch directory>             directory to track
```
- output 옵션 : trace한 정보와 iotracer의 로그를 저장하는 __디렉토리__
	- dmdu.bin    : 디스크 사용량 및 드라이버 매니저 정보 (바이너리 형태)
		- 분산되어 저장됨
	- trace.bin   : tracepoint 정보 (바이너리 형태)
		- 분산되어 저장됨
	- iotrace.log : iotracer 상태 정보 (Text)
- dm 옵션 : skhynix에서 제공하는 driver manager의 절대 경로 위치
	- dmdu.bin에 드라이버 정보가 저장됨
	- disable\_dm 옵션을 사용해 driver manager 안쓰는 것도 가능
- disable\_dm 옵션 : driver manager 미사용
- interval 옵션 : driver manager 및 디스크 사용량 측정 시간 간격, 초단위
	- driver manager를 계속 실행하면, 저장장치의 성능 저하가 있을꺼라는 추측에 의한 옵션, 테스트를 해봐야함
- buffer : dmdu.bin, trace.bin 을 쓸 때, 한번에 쓰는 크기, 바이트 단위
	- tracepoint가 생길때마다 쓰면 성능 저하가 심함
- \<watch directory> : 추적하려는 NVMe 장치의 mount point, 즉, 디렉토리

### /usr/local/bin/ioparser
```
Usage: [OPTION...] <input> <output> 

        -t, --threshold value         set threshold
        -w, --window value            window size
        <input>                       log directory
        <output>                      output directory
```
- threshold 옵션 : 99.99, 99.9999 와 같은 최악, 최상의 값을 찾기위한 설정 값
- window : 요약 정보를 만드는 윈도우 크기, 초 단위
	- 주의 : iotracer의 -i 옵션과 유사하나 다른 정보임
- \<input> : iotracer 에서 지정한 output directory
- \<output> : input directory를 해석해서 저장하는 output __디렉토리__
	- raw.json       : flow 한개 한개를 저장한 파일
	- trace.json     : window 시간 만큼의 요약 정보 파일
	- dmdu.json      : WAF, GC, NAND_WRITE, 디스크 사용량 변화량을 저장하는 정보 파일
	- threshold.json : 최고/최저를 판단하는 latency 기준 값

## 스크립트 사용법
- 스크립트는 기본적으로 ssh에 의해 동작하므로, 키젠 생성 및 배포를 통해 비밀번호 입력없이 로그인되는 것을 추천함
- key 생성 및 배포
```
cat /dev/zero | ssh-keygen -q -N ""
ssh-copy-id "HOSTNAME"
```
### bm\_start.sh
```
cd /PATH/TO/iotracer/scripts
cat example.conf | ./bm_start.sh | tee running.log
```
### bm\_stop.sh
```
cd /PATH/TO/iotracer/scripts
./bm_stop.sh running.log
```
- 참고 : 위의 running.log는 위의 start 커맨드를 실행한 후 tee 커맨드에 의해 만들어진 파일임
### bm\_result.sh
```
cd /PATH/TO/iotracer/scripts
cat example.conf | ./bm_result.sh
```
- 참고 : 위 커맨드를 실행하면, ioparser에 의해 생성되는 파일이 커맨드를 실행한 위치에서 생성됨

### example.conf
```
{
	"meta": {
		"type": "NOSQL",
		"hostnames": [
			{"hostname" : "127.0.0.1"}
		]
	},
	"instance": "cassandra",
	"watch_directory": "/mnt/nvme",
	"device_manager": "/home/users/drive-manager",
	"window_size": 10,
	"threshold": 99.9999,
	"result": "/home/users/output"
}
```
- meta -> hostnames -> hostname : 여러개 있을 수 있으며, iotracer가 실행되는 호스트를 지칭함
- watch_directory : nvme가 장착된 mount point __디렉토리__
- device_manager : skhynix에서 제공하는 드라이버 매니저의 위치
- window_size : 요약 파일을 만드는 window의 크기, 초 단위
- threshold : 최대, 최악 io를 추리기 위한 값
- result : 결과가 저장되는 위치
- __주의__ : 위 설정에서의 위치는 iotracer, ioparser가 실행되는 호스트 상에서의 디렉토리 위치임
