#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <assert.h>
#include <inttypes.h>
#include <sys/sysmacros.h> // major, minor
#include <limits.h>
#include <errno.h>
#include <time.h>
#include <bsd/libutil.h>
#include <pthread.h>

#include "../share/event.h"
#include "buffer/buffer.h"
#include "debug.h"
#include "arg.h"
#include "argument/arg.h"
#include "vertex/vertex.h"
#include "file/file.h"
#include "tprocess.h"
#include "store.h"

#define NS_FMT "%"PRIu64".%.9"PRIu64
#define NS_ARG(time) (time)/1000000000UL, (time)%1000000000UL

struct vertex *g_trace_store_vtx;

/**
 * @brief bcc 추적 시작
 *
 * @return 0 성공, -1 실패
 */
int track(void);

/**
 * @brief 특정 디바이스의 event를 bcc를 통해 추출
 *
 * @param major 추적할 장치의 major 번호
 * @param minor 추적할 장치의 minor 번호
 * @param handler 추적한 Event 데이터를 처리할 콜백 함수
 *
 * @return 0 성공, -1 실패
 */
int track_init(int major, int minor, void (*handler)(void *data));

/**
 * @brief bcc에서 event를 얻어올때 실행되는 함수
 *
 * @param data event 설계문서 참조
 */
static void trace_handler(void *data)
{
	struct event *ev = store_alloc(STORE_BCC, sizeof(struct event));
	CHECK_ERR(ev);
	memcpy(ev, data, sizeof(struct event));
	vertex_put(g_trace_store_vtx, ev);
}

// DFD STRUCT
struct merge {
	struct timespec time;
	unsigned long usage;
	unsigned long long written_to_tlc_user;
	unsigned long long write_from_host;
};

// DISK USAGE --> DU
typedef struct du_conf {
	int interval_dfdevice;
	char *watch_directory;
	pthread_cond_t cond;
	pthread_mutex_t lock;
} du_conf;
//typedef struct conf du_conf;
#include <sys/statvfs.h>

/**
 * @brief sleep을 하기 전, 다른 함수의 수행으로 인해 지연이 생긴 만큼 제거하고 쉬는 함수
 *
 * @param interval sleep 하려는 시간
 *
 * @return sleep후의 시간
 */
static struct timespec __sleep_interval(pthread_cond_t *cond, pthread_mutex_t *lock,
			       int interval)
{
	int r = 0;
	struct timespec now = {0};

	clock_gettime(CLOCK_REALTIME, &now);
	printf("sleep %ld %ld\n", now.tv_sec, now.tv_nsec);

	now.tv_sec = (now.tv_sec/interval+1)*interval;
	now.tv_nsec = 0;

	pthread_mutex_lock(lock);

	printf("sleep %ld %ld\n", now.tv_sec, now.tv_nsec);
	r = pthread_cond_timedwait(cond, lock, &now);
	if (r == 0) {
		now.tv_sec = 0;
	}

	pthread_mutex_unlock(lock);

	if (r) {
		clock_gettime(CLOCK_BOOTTIME, &now);
		now.tv_nsec = 0;
	}
	return now;
}

/**
 * @brief disk의 사용량을 byte 단위로 확인하는 함수
 *
 * @param path 임의의 파일 혹은 디렉토리에 접근해 그 파일의 사용량이 아니라 그 파일을 저장하는 디스크의 사용량을 확인
 *
 * @return byte단위 디스크 사용량
 */
static unsigned long __disk_usage(char *path)
{
	struct statvfs st;
	int r = 0;
	r = statvfs(path, &st);
	if (r < 0) {
		printf("%s\n", path);
		perror("what ? ");
		return 0;
	}

	return (st.f_blocks - st.f_bfree) * st.f_bsize;
}

/**
 * @brief 디스크의 사용량을 일정 시간마다 확인해주는 함수
 *
 * @param data quit 여부 판단
 * @param private 설정
 *
 * @return 디스크 사용량 전달
 */
static void *du_handler(void *data, void *private)
{
	du_conf *conf = private;
	struct merge *dfd = NULL;
	struct timespec now = {0};

	if (data == VERTEX_QUIT) {
		return VERTEX_QUIT;
	}

	now = __sleep_interval(&conf->cond, &conf->lock, conf->interval_dfdevice); // 먼저 쉬고
	if (now.tv_sec == 0) {
		return VERTEX_QUIT;
	}

	dfd = malloc(sizeof(struct merge));
	CHECK(dfd);
	memset(dfd, 0, sizeof(struct merge));

	dfd->time = now;
	dfd->usage = __disk_usage(conf->watch_directory);
	CHECK(dfd->usage);

	return dfd;
}
// END DISK USAGE

// DEVICE MANAGER --> DM
typedef struct dm_conf {
	struct conf *conf;
	char command[PATH_MAX];
	//	"/home/biosvos/Downloads/drive-manager smart /dev/nvme0n1 | grep -A1 \"Write From Host\" | cut -d'|' -f 8 | sed 's/^[ \t]*//;s/[ \t]*$//'"
	pthread_cond_t cond;
	pthread_mutex_t lock;
} dm_conf;

/**
 * @brief 문자열 숫자를 숫자로 반환
 *
 * @param str 문자형태의 숫자
 *
 * @return 숫자
 */
static unsigned long long __str_to_ull(char *str)
{
	unsigned long long ret = 0;
	char *tmp = NULL;

	ret = strtoull(str, &tmp, 10);
	assert(!*tmp);

	return ret;
}

/**
 * @brief driver manager를 실행하고, 분석하는 함수
 *
 * @param conf
 * @param dfd driver manager의 정보를 저장할 변수
 *
 * @return 0 함수 성공, -1 함수 실패
 */
static int run_dm(dm_conf *conf, struct merge *dfd)
{
	FILE *fp = NULL;
	char buffer[30];
	char *r;

	fp = popen(conf->command, "r");
	if (fp == NULL) {
		return -1;
	}

	r = fgets(buffer, sizeof(buffer)-1, fp);
	if (r == NULL) {
		return -1;
	}
	buffer[strlen(buffer)-1] = '\0';
	dfd->write_from_host = __str_to_ull(buffer);

	r = fgets(buffer, sizeof(buffer)-1, fp);
	if (r == NULL) {
		return -1;
	}
	buffer[strlen(buffer)-1] = '\0';
	dfd->written_to_tlc_user = __str_to_ull(buffer);

	fclose(fp);

	return 0;
}

/**
 * @brief driver manager를 주기적으로 수행
 *
 * @param data 미사용
 * @param private 설정
 *
 * @return
 */
static void *dm_handler(void *data, void *private)
{
	dm_conf *conf = private;
	struct timespec now;
	struct merge *dfd = NULL;
	struct merge dm;

	if (data == VERTEX_QUIT) {
		return VERTEX_QUIT;
	}

	now = __sleep_interval(&conf->cond, &conf->lock, conf->conf->interval_dfdevice);
	if (now.tv_sec == 0) {
		return VERTEX_QUIT;
	}

	dfd = malloc(sizeof(struct merge));
	CHECK(dfd);
	memset(dfd, 0, sizeof(struct merge));

	run_dm(conf, &dm);

	dfd->time = now;
	dfd->write_from_host = dm.write_from_host;
	dfd->written_to_tlc_user = dm.written_to_tlc_user;

	return dfd;
}

// START DFDDEVICE_FD HANDLER
typedef struct merger_conf {
	struct conf *conf;
	struct merge merge;
} merger_conf;

/**
 * @brief disk usage와 driver manager의 내용을 합쳐 파일에 저장
 *
 * @param data du_handler와 dm_handler로부터 전달받은 데이터
 * @param private 설정
 *
 * @return 미사용
 */
static void *merger_handler(void *data, void *private)
{
	merger_conf *conf = private;
	struct merge *merge = data;
	struct merge *keep_merge = &conf->merge;

	if (keep_merge->time.tv_sec != merge->time.tv_sec) {
		memset(keep_merge, 0, sizeof(struct merge));
	}

	if (merge->usage) { // usage에서 옴
		keep_merge->time = merge->time;
		keep_merge->usage = merge->usage;
	} else { // dm에서 옴
		keep_merge->time = merge->time;
		keep_merge->write_from_host = merge->write_from_host;
		keep_merge->written_to_tlc_user = merge->written_to_tlc_user;
	}

	if ((keep_merge->usage && keep_merge->write_from_host) ||
	    conf->conf->disable_device_manager) {
		struct merge *send = store_alloc(STORE_DMDU, sizeof(struct merge));
		memcpy(send, keep_merge, sizeof(struct merge));
		memset(keep_merge, 0, sizeof(struct merge));
		vertex_put(g_trace_store_vtx, send);
	}

	free(merge);

	return NULL;
}

#define LOG(log, msg)  do { \
	char __log_buff[21]; \
	time_t __log_now = time(NULL); \
	strftime (__log_buff, 20, "%Y-%m-%d %H:%M:%S", localtime (&__log_now)); \
	fprintf((log)->iotrace_file, "%s : "msg"\n", __log_buff); \
} while (0)

#define LOG_FMT(log, msg, ...)  do { \
	char __log_buff[21]; \
	time_t __log_now = time(NULL); \
	strftime (__log_buff, 20, "%Y-%m-%d %H:%M:%S", localtime (&__log_now)); \
	fprintf((log)->iotrace_file, "%s : "msg"\n", __log_buff, __VA_ARGS__); \
} while (0)

int main(int argc, char *argv[])
{
	if (geteuid() != 0) {
		fprintf(stderr, "run app as root\n");
		return -1;
	}

	struct conf conf = {0};
	int r = 0;
	struct vertex *dm_vtx = NULL;
	int ret = 0;
	dm_conf dm_conf = {0};
	pthread_mutex_init(&dm_conf.lock, NULL);
	pthread_cond_init(&dm_conf.cond, NULL);

	conf_parser(argc, argv, &conf);

	LOG(&conf, "start iotrace");

	pid_t pid = getpid();
	struct pidfh *pfh = pidfile_open(NULL, 0600, &pid);
	if (pfh == NULL) {
		printf("alreay running\n");
		exit(-1);
	}

	LOG_FMT(&conf, "iotrace pid %d", getpid());

	if (!conf.disable_device_manager) {
		struct merge mer;
		dm_conf.conf = &conf;
		sprintf(dm_conf.command, "%s smart %s | grep -A1 \"Write From Host\" | cut -d'|' -f 8 | sed 's/^[ \\t]*//;s/[ \\t]*$//'", conf.device_manager_path, conf.whole_device);
		r = run_dm(&dm_conf, &mer);
		if (r < 0) {
			LOG(&conf, "watch device is not support device manager");
			return ERR_DM_NOT_SUPPORT;
		}
	}

	merger_conf merger_conf;
	memset(&merger_conf, 0, sizeof(struct merger_conf));

	merger_conf.conf = &conf;

	struct du_conf du_conf = {0};
	du_conf.interval_dfdevice = conf.interval_dfdevice;
	du_conf.watch_directory = conf.watch_directory;
	pthread_mutex_init(&du_conf.lock, NULL);
	pthread_cond_init(&du_conf.cond, NULL);

	struct vertex *du_vtx = vertices(0, du_handler, &du_conf);
	if (!conf.disable_device_manager) {
		dm_vtx = vertices(0, dm_handler, &dm_conf);
	}
	struct vertex *merger_vtx = vertex(merger_handler, &merger_conf);

	edge(du_vtx, merger_vtx);
	if (!conf.disable_device_manager) {
		edge(dm_vtx, merger_vtx);
	}

	// TRACE

	g_trace_store_vtx = store_start(conf.output, conf.buffer_size, conf.parse_byte, conf.parse_window, conf.parse_output);
	printf("MAJOR %d MINOR %d\n", major(conf.dev), minor(conf.dev));
	ret = track_init(major(conf.dev), minor(conf.dev), trace_handler);
	if (ret < 0) {
		return ret; // trace 불가
	}

	pidfile_write(pfh);

	tprocess_start(g_trace_store_vtx);

	vertex_start(du_vtx);
	if (!conf.disable_device_manager) {
		vertex_start(dm_vtx);
	}

	printf("start track\n");
	ret = track();

	printf("print after CTRL+C\n");

	pthread_mutex_lock(&du_conf.lock);
	pthread_cond_signal(&du_conf.cond);
	pthread_mutex_unlock(&du_conf.lock);
	vertex_stop(du_vtx);
	if (!conf.disable_device_manager) {
		pthread_mutex_lock(&dm_conf.lock);
		pthread_cond_signal(&dm_conf.cond);
		pthread_mutex_unlock(&dm_conf.lock);
		vertex_stop(dm_vtx);
	}

	tprocess_stop();

	store_stop(g_trace_store_vtx);

	LOG(&conf, "stop iotrace");

	conf_close(&conf);

	pidfile_remove(pfh);

	return ret;
}
