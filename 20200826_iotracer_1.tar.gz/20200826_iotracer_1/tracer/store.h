#ifndef STORE_H_SEVL0AKE
#define STORE_H_SEVL0AKE

#include "vertex/vertex.h"

enum {STORE_BCC, STORE_DMDU, STORE_PROCESS, NR_STORE};

void *store_alloc(uint8_t type, size_t size);
struct vertex *store_start(char *output, int buffer_size, int parse_byte, int parse_window, char *parse_output);
void store_stop(struct vertex *vtx);

#endif /* end of include guard: STORE_H_SEVL0AKE */
