#include <unistd.h>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <cassert>
#include <csignal>
#include <thread>
#include <linux/version.h>

//#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0)
//#else
//#define BPF_MAP_TYPE_SK_STORAGE 0
//#endif

#include <bcc/BPF.h>

extern "C" {
	int track(void);
	int track_init(int major, int minor, void (*handler)(void *data));
}

ebpf::BPF bpf;

std::string ReplaceAll(std::string &str, const std::string& from, const std::string& to){
	size_t start_pos = 0; //string처음부터 검사
	while((start_pos = str.find(from, start_pos)) != std::string::npos)  //from을 찾을 수 없을 때까지
	{
		str.replace(start_pos, from.length(), to);
		start_pos += to.length(); // 중복검사를 피하고 from.length() > to.length()인 경우를 위해서
	}
	return str;
}

int tattach(ebpf::BPF *bpf, const char *a, const char *b)
{
	char left[40], right[40];

	sprintf(left, "%s:%s", a, b);
	sprintf(right, "tracepoint__%s__%s", a, b);
	auto attach_res = bpf->attach_tracepoint(left, right);
	if (attach_res.code() != 0) {
		return -1;
	}

	return 0;
}

int attach(ebpf::BPF *bpf, const char *name, const char *handler)
{
	auto attach_res = bpf->attach_kprobe(name, handler);
	if (attach_res.code() != 0) {
		std::cerr << attach_res.msg() << std::endl;
		return -1;
	}

	return 0;
}

int attachret(ebpf::BPF *bpf, const char *name, const char *handler)
{
	auto attach_res = bpf->attach_kprobe(name, handler, 0, BPF_PROBE_RETURN);
//BPF_PROBE_RETURN
	if (attach_res.code() != 0) {
		std::cerr << attach_res.msg() << std::endl;
		return -1;
	}

	return 0;
}

void (*handler)(void *data);

void handle_output(void __attribute__((unused))* cb_cookie, void* data, int __attribute__((unused)) data_size) {
	if (handler) {
		handler(data);
	}
}

int track_init(int major, int minor, void (*handle)(void *data)) 
{
	handler = handle;
	std::string bpf_program = R""""(
#include <uapi/linux/ptrace.h>
#include <linux/fs.h>
#include <linux/blk-mq.h>
#include <linux/kdev_t.h>
#include <linux/mount.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0)
#define bio2disk(__b) ((__b)->bi_disk)
#else
#define bio2disk(__b) ((__b)->bi_bdev->bd_disk)
#endif


#ifndef uint64_t
#define uint64_t u64
#endif

#ifndef uint32_t
#define uint32_t u32
#endif

#ifndef uint16_t
#define uint16_t u16
#endif

#ifndef uint8_t
#define uint8_t u8
#endif

enum {
	BLOCK_BIO_QUEUE = 1,
	BLOCK_GETRQ,
	BLOCK_RQ_ISSUE,
	NVME_SQ,
	BLOCK_RQ_COMPLETE_W,
	BLOCK_RQ_COMPLETE_R,
	BLOCK_RQ_COMPLETE_D,
	VFS_WRITE,
	VFS_READ
};

struct event {
        uint8_t type;
        uint64_t time;

//        uint64_t kernel_time;
//        uint64_t driver_time;
//        uint64_t device_time;

        // pid + tid
        uint64_t ptid;

        uint64_t off;
        uint32_t len;
	uint16_t streamid;

        uint64_t private;
};

static inline int filter_dev(dev_t dev)
{
	int major = dev>>20;
	int minor = dev&((1<<20)-1);

	if (major == MAJOR_VALUE && minor == MINOR_VALUE) {
		return 0;
	}

	return 1; // filter this
}

static inline char get_rw(char *rwbs)
{
	if (rwbs[0] == 'F') {
		return rwbs[1];
	}

	return rwbs[0];
}

BPF_PERF_OUTPUT(eventA);
BPF_PERF_OUTPUT(eventB);
BPF_PERF_OUTPUT(eventC);
BPF_PERF_OUTPUT(eventD);
BPF_PERF_OUTPUT(eventE);
BPF_PERF_OUTPUT(eventF);
BPF_PERF_OUTPUT(eventG);

BPF_HASH(whash, uint64_t, struct event);
BPF_HASH(wvhash, uint64_t, struct event);
BPF_HASH(rhash, uint64_t, struct event);
BPF_HASH(rvhash, uint64_t, struct event);
BPF_HASH(biohash, uint64_t, struct event);

int on_write(struct pt_regs *ctx, struct file *file, const char __user *buf, size_t count, loff_t *pos)
{
        struct event ev = {.type = VFS_WRITE};
        dev_t dev = 0;

        if (!(file->f_mode & S_IFREG)) {
                return 0;
        }

        struct gendisk *disk = file->f_path.mnt->mnt_sb->s_bdev->bd_disk;
        dev = disk->major << 20 | disk->first_minor;

        if(filter_dev(dev)) {
                return 0;
        }

        ev.time = bpf_ktime_get_ns();
        ev.ptid = bpf_get_current_pid_tgid();
        ev.off = *pos;
#ifdef STREAMID
	ev.streamid = file->f_streamid;
#endif

        whash.update(&ev.ptid, &ev);

        return 0;
}

int on_write_end(struct pt_regs *ctx)
{
        struct event *ev = NULL;
        struct event rev = {0};
        uint64_t ptid = bpf_get_current_pid_tgid();
        uint64_t end_time = 0;

        ev = whash.lookup(&ptid);
        if (ev == NULL) {
                return 0;
        }

        end_time = bpf_ktime_get_ns();

        ev->len = PT_REGS_RC(ctx);
        ev->private = end_time - ev->time;

	rev = *ev;

        eventF.perf_submit(ctx, &rev, sizeof(struct event));
        whash.delete(&ptid);
        return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0)
int on_writev(struct pt_regs *ctx, struct file *file, const struct iovec __user *vec, unsigned long vlen, loff_t *pos, rwf_t flags)
#else
int on_writev(struct pt_regs *ctx, struct file *file, const struct iovec __user *vec, unsigned long vlen, loff_t *pos, int flags)
#endif
{
        struct event ev = {.type = VFS_WRITE};
        dev_t dev = 0;

        if (!(file->f_mode & S_IFREG)) {
                return 0;
        }

        struct gendisk *disk = file->f_path.mnt->mnt_sb->s_bdev->bd_disk;
        dev = disk->major << 20 | disk->first_minor;

        if(filter_dev(dev)) {
                return 0;
        }

        ev.time = bpf_ktime_get_ns();
        ev.ptid = bpf_get_current_pid_tgid();
        ev.off = *pos;
#ifdef STREAMID
	ev.streamid = file->f_streamid;
#endif

        wvhash.update(&ev.ptid, &ev);

        return 0;
}

int on_writev_end(struct pt_regs *ctx)
{
        struct event *ev = NULL;
        struct event rev = {0};
        uint64_t ptid = bpf_get_current_pid_tgid();
        uint64_t end_time = 0;

        ev = wvhash.lookup(&ptid);
        if (ev == NULL) {
                return 0;
        }

        end_time = bpf_ktime_get_ns();

        ev->len = PT_REGS_RC(ctx);
        ev->private = end_time - ev->time;

	rev = *ev;

        eventF.perf_submit(ctx, &rev, sizeof(struct event));
        wvhash.delete(&ptid);
        return 0;
}

int on_read(struct pt_regs *ctx, struct file *file, char __user *buf, size_t count, loff_t *pos)
{
        struct event ev = {.type = VFS_READ};
        dev_t dev = 0;

        if (!(file->f_mode & S_IFREG)) {
                return 0;
        }

        struct gendisk *disk = file->f_path.mnt->mnt_sb->s_bdev->bd_disk;
        dev = disk->major << 20 | disk->first_minor;

        if(filter_dev(dev)) {
                return 0;
        }

        ev.time = bpf_ktime_get_ns();
        ev.ptid = bpf_get_current_pid_tgid();
        ev.off = *pos;
#ifdef STREAMID
	ev.streamid = file->f_streamid;
#endif

        rhash.update(&ev.ptid, &ev);

        return 0;
}

int on_read_end(struct pt_regs *ctx)
{
        struct event *ev = NULL;
        struct event rev = {0};
        uint64_t ptid = bpf_get_current_pid_tgid();
        uint64_t end_time = 0;

        ev = rhash.lookup(&ptid);
        if (ev == NULL) {
                return 0;
        }

        end_time = bpf_ktime_get_ns();

        ev->len = PT_REGS_RC(ctx);
        ev->private = end_time - ev->time;

	rev = *ev;

        eventG.perf_submit(ctx, &rev, sizeof(struct event));
        rhash.delete(&ptid);
        return 0;
}

int on_readv(struct pt_regs *ctx, struct file *file, const struct iovec __user *vec, unsigned long vlen, loff_t *pos, int flags)
{
        struct event ev = {.type = VFS_READ};
        dev_t dev = 0;

        if (!(file->f_mode & S_IFREG)) {
                return 0;
        }

        struct gendisk *disk = file->f_path.mnt->mnt_sb->s_bdev->bd_disk;
        dev = disk->major << 20 | disk->first_minor;

        if(filter_dev(dev)) {
                return 0;
        }

        ev.time = bpf_ktime_get_ns();
        ev.ptid = bpf_get_current_pid_tgid();
        ev.off = *pos;
#ifdef STREAMID
	ev.streamid = file->f_streamid;
#endif

        rvhash.update(&ev.ptid, &ev);

        return 0;
}

int on_readv_end(struct pt_regs *ctx)
{
        struct event *ev = NULL;
        struct event rev = {0};
        uint64_t ptid = bpf_get_current_pid_tgid();
        uint64_t end_time = 0;

        ev = rvhash.lookup(&ptid);
        if (ev == NULL) {
                return 0;
        }

        end_time = bpf_ktime_get_ns();

        ev->len = PT_REGS_RC(ctx);
        ev->private = end_time - ev->time;

	rev = *ev;

        eventG.perf_submit(ctx, &rev, sizeof(struct event));
        rvhash.delete(&ptid);
        return 0;
}

TRACEPOINT_PROBE(block, block_rq_issue) {
	struct event ev = {.type = BLOCK_RQ_ISSUE};
	dev_t dev = 0;

	dev = args->dev;
	if(filter_dev(dev)) {
		return 0;
	}

	ev.time = bpf_ktime_get_ns();
	ev.ptid = bpf_get_current_pid_tgid();
	ev.off = args->sector;
	ev.len = args->nr_sector;
	ev.private = get_rw(args->rwbs);

	eventD.perf_submit(args, &ev, sizeof(struct event));
	return 0;
}

TRACEPOINT_PROBE(block, block_getrq) {
	struct event ev = {.type = BLOCK_GETRQ};
	dev_t dev = 0;

	dev = args->dev;
	if(filter_dev(dev)) {
		return 0;
	}

	ev.time = bpf_ktime_get_ns();
	ev.ptid = bpf_get_current_pid_tgid();
	ev.off = args->sector;
	ev.len = args->nr_sector;
	ev.private = get_rw(args->rwbs);

	eventB.perf_submit(args, &ev, sizeof(struct event));
	return 0;
}

TRACEPOINT_PROBE(block, block_rq_complete) {
	struct event ev = {.type = BLOCK_RQ_COMPLETE_W};
	dev_t dev = 0;
	char ch = 0;

	dev = args->dev;
	if(filter_dev(dev)) {
		return 0;
	}

	ev.time = bpf_ktime_get_ns();
	ev.ptid = bpf_get_current_pid_tgid();
	ev.off = args->sector;
	ev.len = args->nr_sector;
	ev.private = get_rw(args->rwbs);

	if (ev.private == 'W') {
		ev.type = BLOCK_RQ_COMPLETE_W;
	} else if (ev.private == 'R') {
		ev.type = BLOCK_RQ_COMPLETE_R;
	} else if (ev.private == 'D') {
		ev.type = BLOCK_RQ_COMPLETE_D;
	}

	eventA.perf_submit(args, &ev, sizeof(struct event));
	return 0;
}

TRACEPOINT_PROBE(block, block_bio_queue) {
	struct event ev = {.type = BLOCK_BIO_QUEUE};
	dev_t dev = 0;

	dev = args->dev;
	if(filter_dev(dev)) {
		return 0;
	}

	ev.time = bpf_ktime_get_ns();
	ev.ptid = bpf_get_current_pid_tgid();
	ev.off = args->sector;
	ev.len = args->nr_sector;
	ev.private = get_rw(args->rwbs);

	eventC.perf_submit(args, &ev, sizeof(struct event));
	return 0;
}

int on_nvme_sq(struct pt_regs *ctx, 
	       struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
{
	struct nvme_ns *ns = hctx->queue->queuedata;
	if (ns == NULL) { // admin command
		return 0;
	}
	
//	struct request *req = bd->rq;
	struct bio *bio = bd->rq->bio;
//	struct gendisk *disk = bio2disk(bio);
	struct gendisk *disk = bd->rq->rq_disk;
	struct event ev = {.type = NVME_SQ};
	dev_t dev = 0;

	dev = disk->major << 20 | disk->first_minor;
	if(filter_dev(dev)) {
		return 0;
	}

	ev.time = bpf_ktime_get_ns();
	ev.ptid = bpf_get_current_pid_tgid();
	ev.off = bio->bi_iter.bi_sector;
	ev.len = bio->bi_vcnt;
#ifdef STREAMID
	ev.streamid = bd->rq->bio->bi_streamid;
#endif

	eventE.perf_submit(ctx, &ev, sizeof(struct event));
	return 0;
}
)"""";

	//std::string bpf_program = buffer.str();
	ReplaceAll(bpf_program, "MAJOR_VALUE", std::to_string(major));
	ReplaceAll(bpf_program, "MINOR_VALUE", std::to_string(minor));

//	std::cout << bpf_program << std::endl;
	auto init_res = bpf.init(bpf_program, {"-DSTREAMID"}, {});
	if (init_res.code() != 0) {
		std::cerr << "this is not stream patch kernel" << std::endl;

		init_res = bpf.init(bpf_program);
		if (init_res.code() != 0) {
			std::cerr << init_res.msg() << std::endl;
			return -1;
		}
	}

	std::string line;

	if (tattach(&bpf, "block", "block_getrq") < 0) {
		printf("%d\n", __LINE__);
		return -1;
	}
	if (tattach(&bpf, "block", "block_rq_complete") < 0) {
		printf("%d\n", __LINE__);
		return -1;
	}
	if (tattach(&bpf, "block", "block_bio_queue") < 0) {
		printf("%d\n", __LINE__);
		return -1;
	}
	if (tattach(&bpf, "block", "block_rq_issue") < 0) {
		printf("%d\n", __LINE__);
		return -1;
	}
	if (attach(&bpf, "vfs_read", "on_read") < 0) {
		return -1;
	}
	if (attach(&bpf, "vfs_readv", "on_readv") < 0) {
		return -1;
	}
	if (attach(&bpf, "vfs_write", "on_write") < 0) {
		return -1;
	}
	if (attach(&bpf, "vfs_writev", "on_writev") < 0) {
		return -1;
	}
	if (attachret(&bpf, "vfs_read", "on_read_end") < 0) {
		return -1;
	}
	if (attachret(&bpf, "vfs_readv", "on_readv_end") < 0) {
		return -1;
	}
	if (attachret(&bpf, "vfs_write", "on_write_end") < 0) {
		return -1;
	}
	if (attachret(&bpf, "vfs_writev", "on_writev_end") < 0) {
		return -1;
	}
	//tattach(&bpf, "nvme", "nvme_sq");
	//tattach(&bpf, "nvme", "nvme_complete_rq");

	if (attach(&bpf, "nvme_queue_rq", "on_nvme_sq") < 0) {
		printf("%d\n", __LINE__);
		return -1;
	};

	return 0;
}

volatile int stop = 0;

void *track_event(void *data)
{
	std::string *str = static_cast<std::string *>(data);
	int r = 0;

	auto perf_buffer = bpf.get_perf_buffer(*str);
	if (perf_buffer) {
		while (stop == 0) {
			r = perf_buffer->poll(-1);
			if (r < 0) {
				break;
			}
		}
	}


	return NULL;
}

static void signal_configure(sigset_t *sctx)
{
	sigemptyset(sctx);
	sigaddset(sctx, SIGINT);
	sigaddset(sctx, SIGTERM);
	pthread_sigmask(SIG_BLOCK, sctx, NULL);
}

static void signal_wait(sigset_t *sctx)
{
	int signal = 0;

	while (sigwait(sctx, &signal) == 0) {
		switch(signal) {
		case SIGINT:
		case SIGTERM:
			return ;
		}
	}
}

int track(void)
{
	sigset_t sig = {0};
	signal_configure(&sig);

	std::string events[] = {"eventA", "eventB", "eventC", "eventD", "eventE", "eventF", "eventG"};
	int nr_thread = sizeof(events)/sizeof(*events);
	pthread_t tid[nr_thread] = {0};
	int i = 0;

	for (i = 0; i < nr_thread; ++i) {
		auto open_res = bpf.open_perf_buffer(events[i], &handle_output, nullptr, nullptr, 4096*4);
		if (open_res.code() != 0) {
			std::cerr << open_res.msg() << std::endl;
			return -1;
		}
		pthread_create(&tid[i], NULL, track_event, &events[i]);
	}

	if (bpf.free_bcc_memory()) {
		std::cerr << "Failed to free llvm/clang memory" << std::endl;
		return 1;
	}

	signal_wait(&sig);
	stop = 1;

	for (i = 0; i < nr_thread; ++i) {
		pthread_cancel(tid[i]);
	}

	for (i = 0; i < nr_thread; ++i) {
		std::cout << "join\n";
		pthread_join(tid[i], NULL);
	}

	return 0;
}
