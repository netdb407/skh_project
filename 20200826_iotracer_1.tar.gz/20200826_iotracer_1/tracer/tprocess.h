#ifndef PROCESS_H_2AUXMZKJ
#define PROCESS_H_2AUXMZKJ

#include "vertex/vertex.h"

int tprocess_start(struct vertex *wvtx);
void tprocess_stop();

#endif /* end of include guard: PROCESS_H_2AUXMZKJ */
