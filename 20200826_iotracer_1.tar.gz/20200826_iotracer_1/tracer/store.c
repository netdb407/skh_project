#include <stdio.h>
#include <inttypes.h>
#include <assert.h>
#include <stdlib.h>
#include <limits.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>

#include "buffer/buffer.h"
#include "file/file.h"
#include "vertex/vertex.h"
#include "store.h"
#include "file_name.h"
#include "../parser/ioparser.h"

struct store_conf {
	int buffer_size;
	struct buffer *output;
	struct vertex *self;
	char *dirname;
	char *current_dir;
	int parse_byte;
	int parse_window;
	char *parse_output;
	int current_store_size;
};

static ssize_t file_whandler(void *private, void *buf, size_t nbyte)
{
	return file_write(private, buf, nbyte);
}

static ssize_t fd_whandler(void *private, void *buf, size_t nbyte)
{
	return write((long)private, buf, nbyte);
}

static char *create_tempdir(char *str)
{
	char *path = malloc(PATH_MAX);
	char *tmp_dirname = NULL;

	sprintf(path, "%s/tmpdir.XXXXXX", str);
	tmp_dirname = mkdtemp (path);
	if (tmp_dirname == NULL)
	{
		perror ("tempdir: error: Could not create tmp directory");
		free(path);
		return NULL;
	}

	return path;
}

#define _4MiB (4*1024*1024)

static int __create_directory(char *output)
{
	struct stat st;
	if (stat(output, &st) < 0) {
		if (errno == ENOENT) {
			int r = mkdir(output, 0755);
			if (r < 0) {
				return -1;
			}

			if (stat(output, &st) < 0) {
				return -1;
			}

		} else {
			return -1;
		}
	}

	return 0;
}


static void __open(struct store_conf *conf, char *output)
{
	char path[PATH_MAX] = "";
	struct file *file = NULL;
	int r = 0;
	long fd = 0;

	conf->output = malloc(sizeof(struct buffer)*NR_STORE);
	assert(conf->output);

	// BCC
	sprintf(path, "%s/%s", output, TRACE_FILE);
	file = file_open(path, FILE_WRITE, _4MiB);
	assert(file);
	r = buffer_init(&conf->output[STORE_BCC], conf->buffer_size, file_whandler, file);
	assert(r == 0);

	// DMDU
	sprintf(path, "%s/%s", output, DMDU_FILE);
	file = file_open(path, FILE_WRITE, _4MiB);
	assert(file);
	r = buffer_init(&conf->output[STORE_DMDU], conf->buffer_size, file_whandler, file);
	assert(r == 0);

	// PROCESS
	sprintf(path, "%s/%s", output, PROCESS_FILE);
	fd = creat(path, 0644);
	assert(file);
	r = buffer_init(&conf->output[STORE_PROCESS], conf->buffer_size, fd_whandler, (void *)fd);
	assert(r == 0);
}

static void __close(struct buffer *output)
{
	int i = 0;
	printf("buffer_send\n");
	for (i = 0; i < NR_STORE; ++i) {
		printf("%d...\n", NR_STORE-i);
		buffer_send(&output[i]);
	}
	printf("end buffer_send\n");

	file_close(output[STORE_BCC].private);
	file_close(output[STORE_DMDU].private);
	close((long)output[STORE_PROCESS].private);

	for (i = 0; i < NR_STORE; ++i) {
		buffer_deinit(&output[i]);
	}

	free(output);
}

struct partparse_conf {
	int is_first;
};

struct partparse {
	char *input;
	char *output;
	int window_size;
	struct buffer *buffers;
};

void *partparse_handler(void *data, void *private)
{
	struct partparse_conf *conf = private;
	struct partparse *d = data;
	char *rmstr = NULL;
	printf("start partparsing %s %s\n", d->input, d->output);

	__close(d->buffers);

	printf("!!!!! %s\n", d->input);
	ioparser(d->input, d->output, d->window_size, !conf->is_first, 0);
	conf->is_first = 0;

	rmstr = malloc(strlen(d->input) + 10);
	sprintf(rmstr, "rm -rf %s", d->input);
	system(rmstr);

	free(rmstr);
	free(d);
	return NULL;
}

void *store_handler(void *data, void *private)
{
	struct store_conf *conf = private;
	uint8_t *type = NULL;
	size_t *size = NULL;
	void *d = data;
	struct partparse *pp = NULL;

	{
		size = data;
		--size;
		type = (uint8_t *)size;
		--type;
	}

	buffer_push(&conf->output[*type], d, *size);

	if (conf->parse_byte > 0) {
		conf->current_store_size += *size;
		if (conf->current_store_size > conf->parse_byte) {
			conf->current_store_size = 0;

			pp = malloc(sizeof(struct partparse));
			pp->input = conf->current_dir;
			pp->output = conf->parse_output;
			pp->window_size = conf->parse_window;
			pp->buffers = conf->output;

			conf->current_dir = create_tempdir(conf->dirname);
			__open(conf, conf->current_dir);
		}
	}

	free(type);
	return pp;
}

void *store_alloc(uint8_t type, size_t size)
{
	uint8_t *alloc = malloc(size + sizeof(size_t) + sizeof(uint8_t));
	assert(alloc);

	*alloc = type;
	size_t *psize = (size_t *)&alloc[1];
	*psize = size;

	return &psize[1];
}

struct vertex *store_start(char *output, int buffer_size, int parse_byte, int parse_window, char *parse_output)
{
	struct store_conf *conf = NULL;
	struct vertex *vtx = NULL;
	int r = 0;

	conf = malloc(sizeof(struct store_conf));
	assert(conf);
	memset(conf, 0, sizeof(struct store_conf));

	r = __create_directory(output);
	assert(r == 0);

	conf->dirname = output;
	conf->parse_byte = parse_byte;
	conf->parse_window = parse_window;
	conf->parse_output = parse_output;

	vtx = vertex(store_handler, conf);
	assert(vtx);

	conf->buffer_size = buffer_size;

	conf->current_dir = conf->dirname;
	if (conf->parse_byte > 0) {
		struct partparse_conf *pconf = malloc(sizeof(struct partparse_conf));
		pconf->is_first = 1;
		struct vertex *partparse_vtx = vertex(partparse_handler, pconf);
		edge(vtx, partparse_vtx);

		conf->current_dir = create_tempdir(conf->dirname);
	}

	__open(conf, conf->current_dir);

	vertex_start(vtx);

	return vtx;
}

void store_stop(struct vertex *vtx)
{
	struct store_conf *conf = vtx->private;


	if (conf->parse_byte) {
		struct partparse * pp = NULL;
		pp = malloc(sizeof(struct partparse));
		pp->input = conf->current_dir;
		pp->output = conf->parse_output;
		pp->window_size = conf->parse_window;
		pp->buffers = conf->output;

		vertex_put(vtx->outvtx, pp);
		vertex_stop(vtx);
	} else {
		vertex_stop(vtx);
		__close(conf->output);
	}

	free(conf);
}
