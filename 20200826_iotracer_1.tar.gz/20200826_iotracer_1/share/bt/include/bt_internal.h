#ifndef BT_INTERNAL_H_YTZC21LZ
#define BT_INTERNAL_H_YTZC21LZ

#include "bt.h"

void __bt_node_insert(struct bt_node *node, int idx, void *data, 
		      struct bt_node *left, struct bt_node *right);
struct bt_node *__bt_node_alloc(void);

#endif /* end of include guard: BT_INTERNAL_H_YTZC21LZ */
