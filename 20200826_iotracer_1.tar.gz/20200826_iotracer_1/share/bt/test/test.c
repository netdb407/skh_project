#include <criterion/criterion.h>
#include <stdio.h>
#include <time.h>
#include <limits.h>
#include "bt_internal.h"
#include "bt.h"
#include "queue.h"

struct stack_node {
	struct bt_node *node;
	struct bt_node *parent;
	int depth;
	int idx;
};

void push(struct queue_head *queue, int depth, struct bt_node *node, struct bt_node *parent, int idx)
{
	struct stack_node *n = NULL;

	n = malloc(sizeof(struct stack_node));
	n->node = node;
	n->depth = depth;
	//n->g_id = g_id;
	//n->pgid = pgid;
	n->parent = parent;
	n->idx = idx;
	enqueue(queue, n);

	//++g_id;
}

void traverse(struct bt *root, char *filename)
{
	struct queue_head *head;
	struct stack_node *n = NULL;
	int i = 0;
	FILE *fp = fopen(filename, "w");

	if (root->node == NULL) {
		return ;
	}

	head = queue_alloc();

	push(head, 0, root->node, NULL, 0);

	fprintf(fp, "digraph g {\nnode [shape = record,height=.1];\n");

	while ((n = dequeue(head))) {
		if (n->parent) {
			fprintf(fp, "\"node%p\":f%d -> \"node%p\"\n", (void*)n->parent, n->idx, (void *)n->node);
			fprintf(fp, "\"node%p\" -> \"node%p\"\n", (void *)n->node, (void *)n->node->parent);
		}
		fprintf(fp, "node%p[label = \"<f0> |", (void *)n->node);
		for (i = 0; i < n->node->usage; ++i) {
			//printf("depth %d %d\n", n->depth, *(int *)n->node->data[i]);
			fprintf(fp,"<f%d> %d|", i*2+1, *(int *)n->node->data[i]);
			if (n->node->children[i]) {
				push(head, n->depth + 1, n->node->children[i], n->node, i*2);
			}
			fprintf(fp, "<f%d> |", i*2+2);
		}

		if (n->node->children[i]) {
			push(head, n->depth + 1, n->node->children[i], n->node, i*2);
		}

		fprintf(fp, "\"]\n");
		free(n);
	}

	fprintf(fp, "}\n");

	queue_free(head);
	fclose(fp);
}

int cmp(void *ta, void *tb)
{
	int *a = ta;
	int *b = tb;

	return (*b < *a) - (*a < *b);
}

void mf(void *a, void __attribute__((unused))*private)
{
	printf("%d\n", *(int *)a);
	free(a);
}

Test(simple, del_forward) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 0; i < 100; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}


	for (i = 0; i < 100; ++i) {
		//printf("del %d\n", i);
		new = bt_del(tree, &i);
		cr_assert(new);
		free(new);
	}

	bt_free_default(tree);
}

Test(internal, add_append) {
	int i = 0;
	int *new = NULL;
	struct bt_node *node = __bt_node_alloc();

	for (i = 0; i < BT_M; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		__bt_node_insert(node, node->usage, new, NULL, NULL);
	}

	for (i = 0; i < BT_M; ++i) {
		cr_assert(*(int *)node->data[i] == i);
	}

	for (i = 0; i < BT_M; ++i) {
		free(node->data[i]);
	}

	free(node);
}

Test(internal, add_mid) {
	int i = 0;
	int *new = NULL;
	struct bt_node *node = __bt_node_alloc();

	for (i = 0; i < BT_M/2; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		__bt_node_insert(node, node->usage, new, NULL, NULL);
	}

	for (i = 0; i < BT_M/2; ++i) {
		new = malloc(sizeof(int));
		*new = BT_M/2+i+1;
		__bt_node_insert(node, node->usage, new, NULL, NULL);
	}

	new = malloc(sizeof(int));
	*new = BT_M/2;
	__bt_node_insert(node, BT_M/2, new, NULL, NULL);

	for (i = 0; i < BT_M; ++i) {
		cr_assert(*(int *)node->data[i] == i, "%d == want(%d) failed", *(int *)node->data[i], i);
	}

	for (i = 0; i < BT_M; ++i) {
		free(node->data[i]);
	}

	free(node);
}

Test(internal, add_backward) {
	int i = 0;
	int *new = NULL;
	struct bt_node *node = __bt_node_alloc();

	for (i = 0; i < BT_M; ++i) {
		new = malloc(sizeof(int));
		*new = BT_M-i-1;
		__bt_node_insert(node, 0, new, NULL, NULL);
	}

	for (i = 0; i < BT_M; ++i) {
		cr_assert(*(int *)node->data[i] == i);
	}

	for (i = 0; i < BT_M; ++i) {
		free(node->data[i]);
	}

	free(node);
}

Test(simple, del_backward) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 0; i < 100; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}

	for (i = 99; i >= 0; --i) {
		new = bt_del(tree, &i);
		cr_assert(new, "delete %d failed", *new);
		free(new);
	}

	bt_free_default(tree);
}

Test(simple, del_fail) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	i = 100;
	new = bt_del(tree, &i);
	cr_assert(new == NULL);

	bt_free_default(tree);
}

Test(simple, add_backward) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 100; i > 100; --i) {
		new = malloc(sizeof(int));
		*new = i;
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}

	bt_free_default(tree);
}

Test(simple, add_balance) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 0; i < 17; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}

	bt_free_default(tree);
}

Test(simple, add_10_dot) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 0; i < 20; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}

	bt_free_default(tree);
}

Test(simple, add_forward) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 0; i < 100; ++i) {
		new = malloc(sizeof(int));
		*new = i;
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}

	bt_free_default(tree);
}

Test(simple, add_random) {
	struct bt *tree = NULL;
	int i = 0;
	int *new = NULL;
	int r = 0;

	srand(time(NULL));

	tree = bt_alloc(cmp);
	cr_assert(tree);

	for (i = 0; i < 100; ++i) {
		new = malloc(sizeof(int));
		*new = rand();
		r = bt_put(tree, new);
		cr_assert(r == 0);
	}

	bt_free_default(tree);
}


struct operation {
	int op;
	int value;
};

enum {OP_PUT, OP_GET, OP_DEL};

int read_operation(FILE *fp, struct operation *op)
{
	int r = 0;
	r = fscanf(fp, "%d,%d", &op->op, &op->value);
	return r == 2;
}

Test(error, error01) {
	struct bt *tree = NULL;
	FILE *fp = fopen("test/error01.res", "r");
	struct operation op = {0};
	int *new = NULL;
	int r = 0;
	int search = 0;
	int idx = 0;
	tree = bt_alloc(cmp);
	cr_assert(tree);

	while (read_operation(fp, &op)) {
		switch (op.op) {
		case OP_PUT:
			new = malloc(sizeof(int));
			*new = op.value;
			r = bt_put(tree, new);
			cr_assert(r == 0);
			break;
		case OP_GET:
			search = op.value;
			new = bt_get(tree, &search);
			cr_assert(*new == search);
			break;
		case OP_DEL:
			search = op.value;
			new = bt_del(tree, &search);
			cr_assert(*new == search);
			free(new);
			++idx;
			break;
		}
	}
	fclose(fp);
	bt_free_default(tree);
}

Test(simple, get_first) {
	struct bt *tree = NULL;
	tree = bt_alloc(cmp);
	cr_assert(tree);
	int search = 0;
	char *tmp = NULL;

	tmp = bt_get(tree, &search);
	cr_assert(tmp == NULL);

	bt_free_default(tree);
}
