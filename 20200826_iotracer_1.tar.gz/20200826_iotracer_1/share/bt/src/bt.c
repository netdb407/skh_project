#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "bt.h"

void bt_init(struct bt *tree, bt_cmp_fn cmp)
{
	tree->cmp = cmp;
	tree->node = NULL;
}

struct bt *bt_alloc(bt_cmp_fn cmp)
{
	struct bt *tree = NULL;

	tree = malloc(sizeof(struct bt));
	bt_init(tree, cmp);

	return tree;
}

struct bt_node *__bt_node_alloc(void)
{
	struct bt_node *node = NULL;
		
	node = malloc(sizeof(struct bt_node));
	memset(node, 0, sizeof(struct bt_node));

	return node;
}

void __bt_node_insert(struct bt_node *node, int idx, void *data, 
		      struct bt_node *left, struct bt_node *right)
{
//	assert(node->children[0] == NULL);
	int i = 0;
	if (node->usage == 0) {
		assert(idx == 0);
	} else if (idx == 0) {
		for (i = node->usage; i > idx; --i) {
			node->children[i+1] = node->children[i];
			node->data[i] = node->data[i-1];
		}
		node->children[i+1] = node->children[i];
	} else if (idx == node->usage) {
	} else {
		for (i = node->usage; i > idx; --i) {
			node->children[i+1] = node->children[i];
			node->data[i] = node->data[i-1];
		}
		node->children[i+1] = node->children[i];
	}

	if (left) {
		node->children[idx] = left;
	}

	if (right) {
		node->children[idx+1] = right;
	}

	node->data[idx] = data;

	++node->usage;
}

static void __bt_node_delete(struct bt_node *node, int idx)
{
	int i = 0;

	--node->usage;
	for (i = idx; i < node->usage; ++i) {
		node->data[i] = node->data[i+1];
		node->children[i+1] = node->children[i+2];
	}

	node->data[i] = NULL;
	node->children[i+1] = NULL;
}

void __rotate_clockwise(struct bt_node *top, int idx, // idx 주의
			struct bt_node *left, struct bt_node *right)
{
	__bt_node_insert(right, 0, top->data[idx], left->children[left->usage], NULL);
	if (left->children[left->usage]) {
		left->children[left->usage]->parent = right;
	}
	top->data[idx] = left->data[left->usage-1];
	
	__bt_node_delete(left, left->usage-1);
}

void __rotate_counterclockwise(struct bt_node *top, int idx, // idx 주의
			struct bt_node *left, struct bt_node *right)
{
	__bt_node_insert(left, left->usage, top->data[idx], NULL, right->children[0]);
	if (right->children[0]) {
		right->children[0]->parent = left;
	}
	top->data[idx] = right->data[0];

	right->children[0] = right->children[1];
	__bt_node_delete(right, 0);
}


/** 
 * @brief 
 * 
 * @param top
 * @param idx
 * 
 * @return 값이 존재하면, tree->root와 값 교환이 필요??
 * 	NULL : 머지를 하지 않음
 * 	값 존재 : 머지를 진행함
 */
//struct bt_node *__bt_node_merge(struct bt_node *top, int idx)

static struct bt_node *__bt_node_merge(struct bt_node *node)
{
	int i = 0;
	struct bt_node *top = NULL, *left = NULL, *right = NULL;

	top = node->parent;
	if (top == NULL) {
		return NULL;
	}

	int pivot = top->cache_idx;

	if (top->cache_idx == top->usage) {
		pivot -= 1;
		left = top->children[top->cache_idx-1];
		right = node;
	} else {
		left = node;
		right = top->children[top->cache_idx+1];
	}

	if ((left->usage + right->usage + 2) > BT_M) {
		if (left->usage < BT_M/2) {
			__rotate_counterclockwise(top, pivot,
						  left, right);
		} else if (right->usage < BT_M/2) {
			__rotate_clockwise(top, pivot,
					   left, right);
		}
		return NULL;
	}

	__bt_node_insert(left, left->usage, top->data[pivot],
			 left->children[left->usage],
			 right->children[0]);
	if (right->children[0]) {
		right->children[0]->parent = left;
	}
	__bt_node_delete(top, pivot);

	for (i = 0; i < right->usage; ++i) {
		__bt_node_insert(left, left->usage, right->data[i],
				 NULL, right->children[i+1]);
		if (right->children[i+1]) {
			right->children[i+1]->parent = left;
		}
	}
	free(right);

	return top;
}

static struct bt_node *__bt_node_child(struct bt_node *node, int idx)
{
	node->cache_idx = idx;
	return node->children[idx];
}

#define IS_LEAF(node) ((node)->children[0] == NULL)

struct bt_node *__bt_node_most_left(struct bt_node *node, int idx)
{
	struct bt_node *ret = node;
	node = __bt_node_child(node, idx);

	while (node) {
		ret = node;
		node = __bt_node_child(node, 0);
	}

	return ret;
}

static void __bt_free_default_fn(void *data, void __attribute__((unused)) *private)
{
	free(data);
}

void bt_free_default(struct bt *tree)
{
	bt_free(tree, __bt_free_default_fn, NULL);
}

/** 
 * @brief node의 child로 이동
 * 
 * @param cmp
 * @param node
 * @param data
 * @param idx
 *
 * @return 
 * 	ret == node : exact match
 * 	ret == NULL : 못찾음
 * 	ret : 자식으로 한칸 이동
 */
static struct bt_node *__bt_node_search_child(bt_cmp_fn cmp, 
					      struct bt_node *node, void *data)
{
	int i = 0;
	int r = 0;
	struct bt_node *ret = NULL;

	for (i = 0; i < node->usage; ++i) {
		r = cmp(node->data[i], data);
		if (r > 0) {
			ret = __bt_node_child(node, i);
			break;
		}

		if (r == 0) {
			node->cache_idx = i;
			ret = node;
			break;
		}
	}

	if (i == node->usage) {
		ret = __bt_node_child(node, i);
	}

	return ret;
}

/** 
 * @brief 
 * 
 * @param node
 * @param st
 * @param data
 * @param cmp
 * 
 * @return 
 * 	result == 0 : 찾았다
 * 	result == 1 : 못찾았다
 * 	return : 찾는데 가장 최하위 노드
 */
static struct bt_node *__bt_node_search(struct bt_node *node,
					void *data, bt_cmp_fn cmp, int *result)
{
	struct bt_node *tmp = NULL;
	*result = 0;
	while (node && node != tmp) {
		tmp = node;
		node = __bt_node_search_child(cmp, node, data);
	}

	if (node == tmp) { // exact match
		*result = 1;
	}

	return tmp;
}

/** 
 * @brief 
 * 
 * @param node
 * @param top : NULL 일 수 있음
 * @param idx : top이 NULL이면 값 무시
 * 
 * @return top 을 할당하거나 기존의 top 반환
 */
static struct bt_node *__bt_node_grow(struct bt_node *node)
{
	assert(node->usage == BT_M);
	struct bt_node *right = NULL;
	struct bt_node *top = NULL;
	struct bt_node *left = NULL;
	int i = 0;

	left = node;
	top = node->parent;
	if (top == NULL) {
		top = __bt_node_alloc();
	}
	right = __bt_node_alloc();
	right->parent = top;
	left->parent = top;

	for (i = 0; i < BT_M/2; ++i) {
		__bt_node_insert(right, i, left->data[BT_M/2+1+i], 
				 left->children[BT_M/2+1+i], 
				 left->children[BT_M/2+2+i]);
		if (left->children[BT_M/2+1+i]) {
			left->children[BT_M/2+1+i]->parent = right;
		}
		if (left->children[BT_M/2+2+i]) {
			left->children[BT_M/2+2+i]->parent = right;
		}
	}

	__bt_node_insert(top, top->cache_idx, left->data[BT_M/2], 
			 left, right);

	left->usage -= BT_M/2+1;

	return top;
}

/** 
 * @brief 
 * 
 * @param tree
 * @param data
 * 
 * @return 
 * 	0 : 성공
 * 	-1 : 실패
 */
int bt_put(struct bt *tree, void *data)
{
	struct bt_node *node = NULL;
	int r = 0;

	if (tree->node == NULL) {
		tree->node = __bt_node_alloc();
		__bt_node_insert(tree->node, 0, data, NULL, NULL);
		return 0;
	}

	// 1. search
	node = __bt_node_search(tree->node, data, tree->cmp, &r);
	if (r) {
		return -1;
	}

	assert(IS_LEAF(node));
	__bt_node_insert(node, node->cache_idx, data, NULL, NULL);

	while (node && node->usage == BT_M) {
		node = __bt_node_grow(node);
	}

	if (node && node->parent == NULL) {
		tree->node = node;
	}

	return 0;
}

void *bt_get(struct bt *tree, void *data)
{
	int r = 0;
	struct bt_node *node = NULL;

	if (tree->node == NULL) {
		return NULL;
	}

	node = __bt_node_search(tree->node, data, tree->cmp, &r);
	if (r == 0) { // 못찾음
		return NULL;
	}

	return node->data[node->cache_idx];
}

static struct bt_node *__bt_left_max_swap(struct bt_node *node)
{
	struct bt_node *leaf = node;
	leaf = __bt_node_child(leaf, leaf->cache_idx); // left

	while (!IS_LEAF(leaf)) {
		leaf = __bt_node_child(leaf, leaf->usage); // right
	}
	__bt_node_child(leaf, leaf->usage);

	node->data[node->cache_idx] = leaf->data[leaf->cache_idx-1];

	return leaf;
}

void *bt_del(struct bt *tree, void *data)
{
	int r = 0;
	struct bt_node *node = NULL;
	void *ret = NULL;

	if (tree->node == NULL) {
		return NULL;
	}

	node = __bt_node_search(tree->node, data, tree->cmp, &r);
	if (r == 0) { // 못찾음
		return NULL;
	}

	ret = node->data[node->cache_idx];

	if (!IS_LEAF(node)) {
		node = __bt_left_max_swap(node);
	}

	__bt_node_delete(node, node->cache_idx);

	while (node && node->usage < BT_M/2) {
		node = __bt_node_merge(node);
		if (node) {
			if (node->usage == 0) {
				node->children[0]->parent = NULL;
				tree->node = node->children[0];
				free(node);
				break;
			}
		}
	}

	return ret;
}

/** 
 * @brief 
 * 
 * @param tree
 * @param option : 
 * 	0: visit
 * 	1: free
 * @param fr
 * @param private
 */
static void __bt_symmetric(struct bt *tree, int option, 
			   bt_visit_fn fr, void *private)
{
	struct bt_node *node = tree->node;
	struct bt_node *tmp = NULL;

	if (node == NULL) {
		if (option) {
			free(tree);
		}
		return ;
	}

	if (node) {
		node = __bt_node_most_left(node, 0);

		while (node) {
			if (node->usage == node->cache_idx) {
				tmp = node;
				node = node->parent;
				if (option) {
					free(tmp);
				}
			} else {
				fr(node->data[node->cache_idx], private);
				if (!IS_LEAF(node)) {
					node = __bt_node_most_left(node, node->cache_idx+1);
				} else {
					++node->cache_idx;
				}
			}
		}
	}

	if (option) {
		free(tree);
	}
}

void bt_free(struct bt *tree, bt_visit_fn fr, void *private)
{
	__bt_symmetric(tree, 1, fr, private);
}

void bt_traverse(struct bt *tree, bt_visit_fn visit, void *private)
{
	__bt_symmetric(tree, 0, visit, private);
}
