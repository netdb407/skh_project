#!/bin/bash

#./build/test/test

#./build/test/test --filter=simple/add_forward
#f="add_forward"
#dot -Tpng $f > $f.png
#chromium $f.png

#./build/test/test --filter=simple/add_10_dot
#for f in add_forward_*.dot
#do
#	dot -Tpng $f > $f.png
#	chromium $f.png
#done

#./build/test/test --filter=simple/del_forward
#for f in $(ls -v del_forward_*.dot)
#do
#	dot -Tpng $f > $f.png
#	chromium $f.png
#done

#./build/test/test --filter=simple/del_backward
#for f in $(ls -v del_backward_*.dot)
#do
#	dot -Tpng $f > $f.png
#	chromium $f.png
#done

./build/test/test --filter=simple/add_random
for f in $(ls -v add_random_*.dot)
do
	dot -Tpng $f > $f.png
	chromium $f.png
done
