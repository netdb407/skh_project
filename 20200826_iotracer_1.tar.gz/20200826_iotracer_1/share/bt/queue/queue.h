#ifndef QUEUE_H_EZ9ORUG0
#define QUEUE_H_EZ9ORUG0

struct queue {
	void *data;
	struct queue *next;
};

struct queue_head {
	struct queue *first;
	struct queue *last;
};

		
#define QUEUE_HEAD(name) \
	struct queue_head name = {NULL, NULL}

struct queue_head *queue_alloc();
int queue_free(struct queue_head *head);

int enqueue(struct queue_head *head, void *data);
void *dequeue(struct queue_head *head);

#endif /* end of include guard: QUEUE_H_EZ9ORUG0 */
