#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

#include "queue.h"

struct queue_head *queue_alloc()
{
	struct queue_head *head = malloc(sizeof(struct queue_head));
	if (head == NULL) {
		return NULL;
	}
	head->first = NULL;
	head->last = NULL;
	return head;
}

int queue_free(struct queue_head *head)
{
	if (head->first) {
		return -1;
	}

	free(head);
	return 0;
}

int enqueue(struct queue_head *head, void *data)
{
	struct queue *new = NULL;
	new = malloc(sizeof(struct queue));
	if (new == NULL) {
		return -1;
	}

	new->data = data;
	new->next = NULL;

	if (head->first == NULL) {
		assert(head->last == NULL);
		head->first = new;
	} else {
		head->last->next = new;
	}
	head->last = new;

	return 0;
}

void *dequeue(struct queue_head *head)
{
	struct queue *del = NULL;
	void *ret = NULL;

	if (head->first == NULL) {
		return NULL;
	}

	del = head->first;
	head->first = del->next;

	if (head->first == NULL) {
		head->last = NULL;
	}

	ret = del->data;
	free(del);
	return ret;
}
