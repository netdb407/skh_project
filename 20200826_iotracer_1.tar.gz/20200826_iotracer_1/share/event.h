#ifndef EVENT_H_HDSSEXKQ
#define EVENT_H_HDSSEXKQ

#include <inttypes.h>

enum {
	BLOCK_BIO_QUEUE = 1,
	BLOCK_GETRQ,
	BLOCK_RQ_ISSUE,
	NVME_SQ,
	BLOCK_RQ_COMPLETE_W,
	BLOCK_RQ_COMPLETE_R,
	BLOCK_RQ_COMPLETE_D,
	VFS_WRITE,
	VFS_READ
};

struct event {
        uint8_t type;
        uint64_t time;

        // pid + tid
        uint64_t ptid;

        uint64_t off;
        uint32_t len;

	uint16_t streamid;

        uint64_t private;
};

#endif /* end of include guard: EVENT_H_HDSSEXKQ */
