#include <stdlib.h>

#include "list.h"

int list_add(struct list *list, void *data)
{
	struct list *new = NULL;
	new = malloc(sizeof(struct list));
	if (new == NULL) {
		return -1;
	}

	new->data = data;

	list->next->prev = new;
	new->next = list->next;
	new->prev = list;
	list->next = new;
	return 0;
}

void list_del(struct list *list)
{
	list->next->prev = list->prev;
	list->prev->next = list->next;
	free(list);
}
