#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
	echo "parse.h <file name>"
	exit -1
fi

f=$1
echo $f

echo "digraph g {" > t.dot
grep edge $f | grep -oP "\(\K[^\)]*" | awk -F',' '{print $1 " ->" $2}' >> t.dot
grep vertex\( $f | grep -oP '\*\K[^=]*|vertex\(\K[^,]*' | awk 'NR%2{printf "%s[label=",$0;next} {printf "\"%s\"]\n", $0}' >> t.dot
echo "}" >> t.dot

dot -Tpng t.dot > output.png
feh output.png
