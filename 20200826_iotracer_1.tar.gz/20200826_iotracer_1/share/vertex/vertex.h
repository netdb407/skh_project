#ifndef VERTEX_H_T3DBWYBC
#define VERTEX_H_T3DBWYBC

#include <sys/types.h>
#include "stdatomic.h"
#include "ring/ring.h"

struct vertex_share {
	//struct lfq_ctx input;
	struct ring input;
	int nr_thread;
	atomic_int put_penalty;
	atomic_int get_penalty;
};

struct vertex {
	pthread_t tid;
	struct vertex *outvtx;

	struct vertex_share *share;

	void *(*process)(void *item, void *private);
	void *private;

	atomic_int ref_cnt;
	int nr_start;
	void *state;
};

#define VERTEX_QUIT ((void *)-1)

struct vertex *vertex(void *(*func)(void *, void *), void *private);
struct vertex *vertices(int nr, void *(*func)(void *, void *), void *private);

void edge(struct vertex *from, struct vertex *to);

void vertex_put(struct vertex *vtx, void *data);
int vertex_stop(struct vertex *vtx);
int vertex_start(struct vertex *vtx);

#endif /* end of include guard: VERTEX_H_T3DBWYBC */
