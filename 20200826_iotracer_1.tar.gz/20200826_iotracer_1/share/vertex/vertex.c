#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <inttypes.h>

#include "ring/ring.h"
#include "vertex.h"

static int vertex_ref_inc(struct vertex *vtx)
{
	int r = 0;
	if (vtx == NULL) {
		return -1;
	}

	r = atomic_fetch_add(&vtx->ref_cnt, 1);
	return r+1;
}

static int vertex_ref_dec(struct vertex *vtx)
{
	int r = 0;
	if (vtx == NULL) {
		return -1;
	}

	r = atomic_fetch_sub(&vtx->ref_cnt, 1);
	return r-1;
}

void nsleep(uint64_t ns)
{
	struct timespec t = {0};
	t.tv_sec = ns/1000000000UL;
	t.tv_nsec = ns%1000000000UL;
	nanosleep(&t, NULL);
}

#define _1MS (1000000)
static void *vertex_get(struct vertex *vtx)
{
	struct vertex_share *share = vtx->share;
	void *data = NULL;
	int pass = 1;
	int r = 0;

	while ((data = ring_pop(&share->input)) == NULL) { // 데이터 없음
		atomic_fetch_add(&share->put_penalty, 1);
		r = atomic_load(&share->get_penalty);
		if (r <= 0) {
			nsleep(_1MS);
		} else {
			nsleep(_1MS/r);
		}

		sched_yield();
		pass = 0;
	}

	if (pass) {
		r = atomic_fetch_sub(&share->put_penalty, 1);
		if (r < 1) {
			r = atomic_fetch_sub(&share->put_penalty, r-1);
		}
	}

	return data;
}

void vertex_put(struct vertex *vtx, void *data)
{
	struct vertex_share *share = NULL;
	int pass = 1;
	int r = 0;
	if (vtx == NULL || data == NULL) {
		return ;
	}

	share = vtx->share;

	while (ring_push(&share->input, data) < 0) {
		atomic_fetch_add(&share->get_penalty, 1);
		r = atomic_load(&share->put_penalty);
		if (r <= 0) {
			nsleep(_1MS);
		} else {
			nsleep(_1MS/r);
		}
		sched_yield();
		pass = 0;
	}

	if (pass) {
		r = atomic_fetch_sub(&share->get_penalty, 1);
		if (r < 1) {
			r = atomic_fetch_sub(&share->get_penalty, r-1);
		}
	}
}

static inline uint64_t as_nanoseconds(struct timespec* ts) {
	return ts->tv_sec * (uint64_t)1000000000L + ts->tv_nsec;
}

static void ____vertex_stop(struct vertex *vtx)
{
	int i = 0;
	for (i = 0; i < vtx->share->nr_thread; ++i) {
		vertex_put(vtx, VERTEX_QUIT);
	}
}

static void *thread(void *data)
{
	struct vertex *vtx = data;
	struct vertex *out = vtx->outvtx;
	void *item = NULL;
	int ref = 0;

	// for statistics
	uint64_t start, end;
	struct timespec ts;
	uint64_t total_consume_time = 0, nr_consume = 0;

	vertex_ref_inc(out);

	while(1) {
		item = vertex_get(vtx);

		if (item == VERTEX_QUIT) {
			break;
		}

		clock_gettime(CLOCK_REALTIME, &ts);
		start = as_nanoseconds(&ts);
		item = vtx->process(item, vtx->private);
		clock_gettime(CLOCK_REALTIME, &ts);
		end = as_nanoseconds(&ts);
		nr_consume += 1;
		total_consume_time += end - start;

		vertex_put(out, item);
	}

	ref = vertex_ref_dec(out);
	if (ref == 0) {
		____vertex_stop(out);
	}

	// for statistics
	printf("vertex: %p count: %"PRIu64" total time: %"PRIu64".%.9"PRIu64"\n",
	       (void *)vtx, 
	       nr_consume,
	       (total_consume_time)/1000000000UL, (total_consume_time)%1000000000UL);
	return NULL;
}

static void *thread_producer(void *data)
{
	struct vertex *vtx = data;
	struct vertex *out = vtx->outvtx;
	void *item = NULL;
	int ref = 0;

	// for statistics
	uint64_t start, end;
	struct timespec ts;
	uint64_t total_consume_time = 0, nr_consume = 0;

	vertex_ref_inc(out);

	while(1) {
		clock_gettime(CLOCK_REALTIME, &ts);
		start = as_nanoseconds(&ts);
		item = vtx->process(vtx->state, vtx->private);
		clock_gettime(CLOCK_REALTIME, &ts);
		end = as_nanoseconds(&ts);
		nr_consume += 1;
		total_consume_time += end - start;

		if (item == VERTEX_QUIT) {
			break;
		}

		vertex_put(out, item);
	}

	ref = vertex_ref_dec(out);
	if (ref == 0) {
		____vertex_stop(out);
	}

	// for statistics
	printf("vertex: %p count: %"PRIu64" total time: %"PRIu64".%.9"PRIu64"\n",
	       (void *)vtx, 
	       nr_consume,
	       (total_consume_time)/1000000000UL, (total_consume_time)%1000000000UL);

	return NULL;
}

static struct vertex *vertex_setup(int nr, struct vertex_share *share,
				   void *(*func)(void *, void *), void *private)
{
	int i = 0;
	struct vertex *vtx = malloc(sizeof(struct vertex) * nr);
	if (vtx == NULL) {
		return NULL;
	}
	memset(vtx, 0, sizeof(struct vertex) * nr);

	for (i = 0; i < nr; ++i) {
		vtx[i].process = func;
		vtx[i].private = private;
		vtx[i].share = share;
	}

	return vtx;
}

static struct vertex *__vertices(int nr, void *(*func)(void *, void *), void *private)
{
	struct vertex *vtx = NULL;
	struct vertex_share *share = NULL;
	share = malloc(sizeof(struct vertex_share));
	if (share == NULL) {
		return NULL;
	}
	memset(share, 0, sizeof(struct vertex_share));
	if (ring_init(&share->input) < 0) {
		free(vtx);
		return NULL;
	}

	share->nr_thread = nr;
	atomic_init(&share->put_penalty, 0);
	atomic_init(&share->get_penalty, 0);

	vtx = vertex_setup(nr, share, func, private);
	if (vtx == NULL) {
		ring_deinit(&share->input);
		free(vtx);
		return NULL;
	}

	return vtx;
}

static struct vertex *__vertex_none(void *(*func)(void *, void *), void *private)
{
	struct vertex *vtx = NULL;
	vtx = vertex_setup(1, NULL, func, private);
	if (vtx == NULL) {
		free(vtx);
		return NULL;
	}

	return vtx;
}

struct vertex *vertices(int nr, void *(*func)(void *, void *), void *private)
{
	struct vertex *vtx = NULL;

	if (nr) {
		vtx = __vertices(nr, func, private);
	} else {
		vtx = __vertex_none(func, private);
	}

	atomic_init(&vtx->ref_cnt, 0);

	return vtx;
}

struct vertex *vertex(void *(*func)(void *, void *), void *private)
{
	return vertices(1, func, private);
}

static void __edge(struct vertex *from, struct vertex *to)
{
	int i = 0;
	for (i = 0; i < from->share->nr_thread; ++i) {
		from[i].outvtx = to;
	}
}

static void __edge_none(struct vertex *from, struct vertex *to)
{
	from->outvtx = to;
}

void edge(struct vertex *from, struct vertex *to)
{
	if (from->share) {
		__edge(from, to);
	} else {
		__edge_none(from, to);
	}
}

static int __thread_normal(struct vertex *vtx)
{
	int i = 0;
	for (i = 0; i < vtx->share->nr_thread; ++i) {
		if (vtx[i].tid) {
			continue;
		}

		if (pthread_create(&vtx[i].tid, NULL, thread, &vtx[i]) < 0) {
			vtx[i].tid = 0;
			return -1;
		}
	}

	return 0;
}

static int __thread_producer(struct vertex *vtx)
{
	if (vtx->tid) {
		return 0;
	}

	if (pthread_create(&vtx->tid, NULL, thread_producer, vtx) < 0) {
		vtx->tid = 0;
		return -1;
	}

	return 0;
}

static int thread_start(struct vertex *vtx)
{
	int r = 0;

	if (vtx->share) {
		r = __thread_normal(vtx);
	} else {
		r = __thread_producer(vtx);
	}

	return r;
}

int vertex_start(struct vertex *vtx)
{
	int ret = 0;
	int ref = 0;

	ref = vertex_ref_inc(vtx);
	if (ref != 1) {
		return -1;
	}

	while (vtx) {
		ret = thread_start(vtx);
		if (ret < 0) {
			break;
		}

		++vtx->nr_start;

		vtx = vtx->outvtx;
	}

	return ret;
}

int vertex_stop(struct vertex *vtx)
{
	int ret = 0;
	int ref = 0;
	int i = 0;
	struct vertex *next = NULL;

	ref = vertex_ref_dec(vtx);
	if (ref != 0) {
		return -1;
	}

	if (vtx->share) {
		for (i = 0; i < vtx->share->nr_thread; ++i) {
			vertex_put(&vtx[i], VERTEX_QUIT);
		}
	}

	while (vtx) {
		next = vtx->outvtx;
		--vtx->nr_start;

		if (vtx->nr_start) {
			break;
		}

		vtx->state = VERTEX_QUIT;

		if (vtx->share) {
			for (i = 0; i < vtx->share->nr_thread; ++i) {
				if (vtx[i].tid) {
					pthread_join(vtx[i].tid, NULL);
				}
				printf("vertex: %p put penalty %d get penalty %d\n", (void *)&vtx[i], atomic_load(&vtx[i].share->put_penalty), atomic_load(&vtx[i].share->get_penalty));
			}


			ring_deinit(&vtx->share->input);
			free(vtx->share);
			free(vtx);
		} else {
			if (vtx->tid) {
				pthread_join(vtx->tid, NULL);
			}
			free(vtx);
		}

		vtx = next;
	}

	return ret;
}
