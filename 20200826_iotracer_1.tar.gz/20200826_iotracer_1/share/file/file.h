#ifndef FILE_H_R7FTDSZC
#define FILE_H_R7FTDSZC

#include <sys/types.h>

#define FILE_WRITE 7
#define FILE_READ 99

struct file {
	char name[256]; // 파일 이름 // 파일명 + .1 + 처럼 생김
	int name_offset;
	int dfd;
	int g_fd; //  생긴 파일들을 저장 // 256바이트 씩 저장
	int fd;  // 현재 잡고 있는 파일
	size_t limit; // 파일 크기 제한, 제한을 넘을 시, 새로운 파일 생성
	size_t usage;//
	int mode;
};

struct file *file_open(const char *__path, int mode, size_t limit);
void file_close(struct file *f);

ssize_t file_write(struct file *f, void *buf, size_t nbyte);
ssize_t file_read(struct file *f, void *buf, size_t nbyte);

#endif /* end of include guard: FILE_H_R7FTDSZC */
