#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>
#include <sys/stat.h>

#include "debug.h"
#include "file.h"

static void increment(char *str)
{
	int carry = 0;
	while (*str != '\0' || carry) {
		if (!('0' <= *str && *str <= '9') && !carry) {
			fprintf(stderr, "not number\n");
			break;
		}
		carry = 0;

		if (*str == '\0') {
			*str = '1';
			str[1] = '\0';
			break;
		} else {
			*str = *str + 1;
		}

		if (*str == ':') { // '9' 다음이 ':'
			*str = '0';
			carry = 1;
		} else {
			break;
		}

		++str;
	}
}

static void open_current_file(struct file *f)
{
	int r = 0;
	if (f->fd) {
		close(f->fd);
	}
	f->fd = openat(f->dfd, f->name, O_RDWR|O_CREAT, 0644);
	CHECK(f->fd);

	if (f->mode == FILE_WRITE) {
		r = pwrite(f->g_fd, f->name, 256, 0);
		CHECK(r == 256);
	}
}

static void check_usage_and_update(struct file *f)
{
	if (f->usage < f->limit) {
		return ;
	}

	increment(&f->name[f->name_offset+1]);

	open_current_file(f);

	f->usage = 0;

}

static void name_setting(struct file *f)
{
	if (f->mode == FILE_WRITE) {
		int r_size = 0;

		r_size = pread(f->g_fd, f->name, 256, 0);
		if (r_size < 0) {
			fprintf(stderr, "file read error\n");
			close(f->g_fd);
			free(f);
			CHECK(0);
		} else if (r_size == 0) {
			f->name[f->name_offset] = '.';
			f->name[f->name_offset+1] = '0';
			f->name[f->name_offset+2] = '\0';
		}
	} else if (f->mode == FILE_READ) {
		f->name[f->name_offset] = '.';
		f->name[f->name_offset+1] = '0';
		f->name[f->name_offset+2] = '\0';
	}
}


struct file *file_open(const char *__path, int mode, size_t limit)
{
	char *path = strdup(__path);
	CHECK(path);
	char *base = basename(path);
	char *dir = dirname(path);

	struct file *f = malloc(sizeof(struct file));
	if (f == NULL) {
		CHECK(0);
		return NULL;
	}
	memset(f, 0, sizeof(struct file));

	f->mode = mode;
	f->limit = limit;
	f->name_offset = strlen(base);
	strcpy(f->name, base);

//	printf("dir open %s\n", dir);
	f->dfd = open(dir, O_RDONLY);
	CHECK(f->dfd);

//	printf("base %s\n", base);
	f->g_fd = openat(f->dfd, base, O_RDWR|O_CREAT, 0644);
	if (f->g_fd < 0) {
		CHECK_ERR(0);
		free(f);
		return NULL;
	}

	name_setting(f);

	open_current_file(f);

	struct stat st;
	int r = 0;
	r = fstat(f->fd, &st);
	CHECK(r == 0);

	if (f->mode == FILE_WRITE) {
		f->usage = st.st_size;
		lseek(f->fd, f->usage, SEEK_SET);
	}

	check_usage_and_update(f);

	free(path);
	return f;
}

void file_close(struct file *f)
{
	close(f->dfd);
	close(f->g_fd);
	close(f->fd);
	free(f);
}

ssize_t file_write(struct file *f, void *__buf, size_t nbyte)
{
	CHECK(f->mode == FILE_WRITE);
	char *buf = __buf;
	size_t remain = nbyte;
	int w_size = 0;

	while (remain) {
		if (remain > (f->limit-f->usage)) {
			w_size = write(f->fd, &buf[nbyte-remain], f->limit-f->usage);
		} else {
			w_size = write(f->fd, &buf[nbyte-remain], remain);
		}
		CHECK(w_size > 0);
		remain -= w_size;
		f->usage += w_size;
		check_usage_and_update(f);
	}

	return nbyte - remain;
}

ssize_t file_read(struct file *f, void *__buf, size_t nbyte)
{
	CHECK(f->mode == FILE_READ);
	char *buf = __buf;
	size_t remain = nbyte;
	int r_size = 0;

	while (remain) {
		if (remain > (f->limit-f->usage)) {
			r_size = read(f->fd, &buf[nbyte-remain], f->limit-f->usage);
		} else {
			r_size = read(f->fd, &buf[nbyte-remain], remain);
		}
		CHECK(r_size >= 0);

		if (r_size == 0) {
			break;
		}

		remain -= r_size;
		f->usage += r_size;
		check_usage_and_update(f);
	}

	return nbyte - remain;
}
