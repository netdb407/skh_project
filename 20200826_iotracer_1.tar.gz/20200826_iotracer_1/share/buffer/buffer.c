#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include "buffer.h"

// auto commit

void buffer_reset(struct buffer *buf)
{
	buf->offset = 0;
	buf->usage = 0;
}

int buffer_init(struct buffer *buffer, uint64_t capacity,
	       	buffer_handler handler, void *private)
{
	buffer->data = malloc(capacity);
	if (buffer->data == NULL) {
		return -1;
	}
	buffer->private = private;
	buffer->capacity = capacity;
	buffer->handler = handler;

	buffer_reset(buffer);

	return 0;
}

void buffer_deinit(struct buffer *buffer)
{
	free(buffer->data);
}

int buffer_send(struct buffer *buf)
{
	ssize_t size = 0;
	if (buf->usage == buf->offset) {
		return -1;
	}
	size = buf->handler(buf->private, &buf->data[buf->offset], buf->usage - buf->offset);
	if (size <= 0) {
		return -1;
	}

	buf->offset += size;

	return 0;
}

int buffer_recv(struct buffer *buf)
{
	ssize_t size = 0;
	if (buf->capacity == buf->usage) {
		return -1;
	}
	size = buf->handler(buf->private, &buf->data[buf->usage], buf->capacity - buf->usage);
	if (size <= 0) {
		return -1;
	}

	buf->usage += size;

	return 0;
}

static uint64_t __can_fill(uint64_t capacity, uint64_t usage, uint64_t len)
{
	uint64_t remain = capacity - usage;
	if (remain < len) {
		return remain;
	}

	return len;
}

uint64_t buffer_push(struct buffer *buf, void *data, uint64_t len)
{
	int r = 0;
	int can_fill = 0;
	uint64_t remain = len;
	char *cdata = data;

	do {
		if (buf->usage == buf->capacity) {
			r = buffer_send(buf);
			if (r < 0) {
				break;
			}
			if (buf->usage == buf->offset) { // 다보냄
				buffer_reset(buf);
			}
		}
		can_fill = __can_fill(buf->capacity, buf->usage, remain);

		memcpy(&buf->data[buf->usage], &cdata[len-remain], can_fill);
		buf->usage += can_fill;

		remain -= can_fill;
	} while (remain);

	return len - remain;
}
//int buffer_push(struct buffer *buf, void *data, uint64_t len)
//{
//	int r = 0;
//	if (buf->usage + len > buf->capacity) {
//		r = buffer_send(buf);
//		if (r < 0) {
//			return -1;
//		}
//
//		if (buf->usage == buf->offset) {
//			buffer_reset(buf);
//		} else { // unlink
//			memmove(buf->data, &buf->data[buf->offset], buf->usage - buf->offset);
//			buf->usage -= buf->offset;
//			buf->offset = 0;
//		}
//	}
//
//	memcpy(&buf->data[buf->usage], data, len);
//	buf->usage += len;
//
//	return 0;
//}
static uint64_t __can_use(uint64_t usage, uint64_t offset, uint64_t len)
{
	uint64_t usable = usage - offset;
	if (len > usable) {
		return usable;
	}

	return len;
}

uint64_t buffer_pop(struct buffer *buf, void *data, uint64_t len)
{
	uint64_t remain = len;
	char *cdata = data;
	int r = 0;
	uint64_t can_fill = 0;

	do {
		if (buf->usage == buf->offset) {
			buffer_reset(buf);
			r = buffer_recv(buf);
			if (r < 0) {
				break;
			}
		}
		can_fill = __can_use(buf->usage, buf->offset, remain);

		memcpy(&cdata[len-remain], &buf->data[buf->offset], can_fill);
		buf->offset += can_fill;

		remain -= can_fill;
	} while (remain);

	return len - remain;
}

void buffer_print(struct buffer *buf)
{
	printf("capacity : %lu usage : %lu offset : %lu\n", 
	       buf->capacity, buf->usage, buf->offset);
}
