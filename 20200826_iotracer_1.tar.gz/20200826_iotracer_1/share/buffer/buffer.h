#ifndef BUFFER_H_RHBYJ68W
#define BUFFER_H_RHBYJ68W

#include <stdint.h>
#include <sys/types.h>
typedef	ssize_t (*buffer_handler)(void *private, void *buf, size_t nbyte);

struct buffer {
	char *data;
	uint64_t capacity; // const
	uint64_t usage;
	uint64_t offset;
	void *private;
	buffer_handler handler;
};


void buffer_reset(struct buffer *buf);
int buffer_init(struct buffer *buffer, uint64_t capacity, buffer_handler handler, void *private);
void buffer_deinit(struct buffer *buffer);
int buffer_send(struct buffer *buf);
int buffer_recv(struct buffer *buf);
uint64_t buffer_push(struct buffer *buf, void *data, uint64_t len);
uint64_t buffer_pop(struct buffer *buf, void *data, uint64_t len);
void buffer_print(struct buffer *buf);

#endif /* end of include guard: BUFFER_H_RHBYJ68W */
