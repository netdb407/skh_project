#!/bin/bash

JQ="jq -r"
IOTRACER="/home/biosvos/workspace/disksnoop/c/build/iotracer"

if [[ $# -ne 1 ]]; then
	echo "$0 <Status File>"
	exit -1
fi

conf=$1

nr=$($JQ '.status | length' $conf)

for (( i = 0; i < $nr; i++ )); do
	host=$($JQ .status[$i].hostname $conf)
	pid=$($JQ .status[$i].pid $conf)

	ssh -q -t $host "kill -2 $pid" 
done

for (( i = 0; i < $nr; i++ )); do
	host=$($JQ .status[$i].hostname $conf)
	pid=$($JQ .status[$i].pid $conf)

	ssh $host /bin/bash << EOF
	while [[ : ]]; do
		kill -0 $pid && sleep 1 || break;
	done
EOF
done
