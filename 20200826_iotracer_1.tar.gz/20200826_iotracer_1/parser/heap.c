#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "heap.h"

struct heap *heap_alloc(void)
{
	struct heap *h = malloc(sizeof(struct heap));
	if(h == NULL){
		printf("Memory Error!");
		return NULL;
	}
	h->count = 0;
	h->capacity = 1024;
	h->arr = malloc(h->capacity*sizeof(HEAP_ELEMENT)); //size in bytes

	if ( h->arr == NULL){
		printf("Memory Error!");
		return NULL;
	}
	return h;
}

void heap_free(struct heap *h)
{
	free(h->arr);
	free(h);
}

static inline void swap_ull(uint64_t *a, uint64_t *b)
{
	uint64_t tmp = *a;
	*a = *b;
	*b = tmp;
}

void heap_maxpush(struct heap *h, HEAP_ELEMENT key)
{
	uint64_t parent = 0, child = 0;
	if (h->capacity-2 < h->count) {
		printf("heap push over\n");
		h->capacity *= 2;
		h->arr = realloc(h->arr, h->capacity*sizeof(HEAP_ELEMENT)); //size in bytes
	}

	++h->count;
	h->arr[h->count] = key;

	child = h->count;
	parent = child/2;
	while (child > 1 && h->arr[parent] < h->arr[child]) {
		swap_ull(&h->arr[parent], &h->arr[child]);
		child = parent;
		parent = child/2;
	}
}

HEAP_ELEMENT heap_maxpop(struct heap *h)
{
	HEAP_ELEMENT pop;
	uint64_t parent = 0, child = 0;
	if(h->count==0){
		//printf("\n__Heap is Empty__\n");
		return 0;
	}

	pop = h->arr[1];
	swap_ull(&h->arr[1], &h->arr[h->count]);
	--h->count;

	parent = 1;
	child = parent*2;
	if (child + 1 <= h->count) {
		child = (h->arr[child] > h->arr[child + 1]) ? child : child + 1;
	}

	while (child <= h->count && h->arr[parent] < h->arr[child]) {
		swap_ull(&h->arr[parent], &h->arr[child]);
		parent = child;
		child = parent*2;
		if (child + 1 <= h->count) {
			child = (h->arr[child] > h->arr[child + 1]) ? child : child + 1;
		}
	}

	return pop;
}

void heap_minpush(struct heap *h, HEAP_ELEMENT key)
{
	uint64_t parent = 0, child = 0;
	if (h->capacity-2 < h->count) {
		printf("heap push over\n");
		h->capacity *= 2;
		h->arr = realloc(h->arr, h->capacity*sizeof(HEAP_ELEMENT)); //size in bytes
	}

	++h->count;
	h->arr[h->count] = key;

	child = h->count;
	parent = child/2;
	while (child > 1 && h->arr[parent] > h->arr[child]) {
		swap_ull(&h->arr[parent], &h->arr[child]);
		child = parent;
		parent = child/2;
	}
}

HEAP_ELEMENT heap_minpop(struct heap *h)
{
	HEAP_ELEMENT pop;
	uint64_t parent = 0, child = 0;
	if(h->count==0){
		//printf("\n__Heap is Empty__\n");
		return 0;
	}

	pop = h->arr[1];
	swap_ull(&h->arr[1], &h->arr[h->count]);
	--h->count;

	parent = 1;
	child = parent*2;
	if (child + 1 <= h->count) {
		child = (h->arr[child] < h->arr[child + 1]) ? child : child + 1;
	}

	while (child <= h->count && h->arr[parent] > h->arr[child]) {
		swap_ull(&h->arr[parent], &h->arr[child]);
		parent = child;
		child = parent*2;
		if (child + 1 <= h->count) {
			child = (h->arr[child] < h->arr[child + 1]) ? child : child + 1;
		}
	}

	return pop;
}

HEAP_ELEMENT heap_peek(struct heap *h)
{
	if(h->count==0){
		//printf("\n__Heap is Empty__\n");
		return 0;
	}

	return h->arr[1];
}
