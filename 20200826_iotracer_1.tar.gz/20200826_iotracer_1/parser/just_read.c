#include <stdio.h>
#include <inttypes.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>

#include "vertex/vertex.h"
#include "debug.h"
#include "list/list.h"
#include "uthash.h"

enum {
	BLOCK_BIO_BACKMERGE = 1,
	BLOCK_BIO_COMPLETE,
	BLOCK_BIO_QUEUE,
	BLOCK_DIRTY_BUFFER,
	BLOCK_PLUG,
	BLOCK_RQ_INSERT,
	BLOCK_RQ_REMAP,
	BLOCK_SLEEPRQ,
	BLOCK_TOUCH_BUFFER,
	BLOCK_BIO_BOUNCE,
	BLOCK_BIO_FRONTMERGE,
	BLOCK_BIO_REMAP,
	BLOCK_GETRQ,
	BLOCK_RQ_COMPLETE,
	BLOCK_RQ_ISSUE,
	BLOCK_RQ_REQUEUE,
	BLOCK_SPLIT,
	BLOCK_UNPLUG,
	VFS_WRITE_START,
	VFS_WRITE_END,
	NVME_SQ,
	NVME_COMPLETE_RQ
};

char *types[] = {
	"None",
	"BLOCK_BIO_BACKMERGE",
	"BLOCK_BIO_COMPLETE",
	"BLOCK_BIO_QUEUE",
	"BLOCK_DIRTY_BUFFER",
	"BLOCK_PLUG",
	"BLOCK_RQ_INSERT",
	"BLOCK_RQ_REMAP",
	"BLOCK_SLEEPRQ",
	"BLOCK_TOUCH_BUFFER",
	"BLOCK_BIO_BOUNCE",
	"BLOCK_BIO_FRONTMERGE",
	"BLOCK_BIO_REMAP",
	"BLOCK_GETRQ",
	"BLOCK_RQ_COMPLETE",
	"BLOCK_RQ_ISSUE",
	"BLOCK_RQ_REQUEUE",
	"BLOCK_SPLIT",
	"BLOCK_UNPLUG",
	"VFS_WRITE_START",
	"VFS_WRITE_END",
	"NVME_SQ",
	"NVME_COMPLETE_RQ"
};

struct event {
	int type;

	uint64_t time;

	// device info
	int dev;

	// process info
	uint64_t pid;

	// bio or read/write info
	int off;
	int len;
};

#define TNS ((uint64_t)1000000000ULL)                                            
#define UUFMT(time) (time)/TNS, (time)%TNS

void print_event(struct event *ev)
{
	printf("%"PRIu64".%"PRIu64", %s, %d, %d\n", UUFMT(ev->time), types[ev->type], ev->off, ev->len);
}

void *read_handler(void __attribute__((unused)) *data, void *private)
{
	struct event *ev = NULL;
	int *fd = private;
	int r_size = 0;
	ev = malloc(sizeof(struct event));
	CHECK(ev);

	r_size = read(*fd, ev, sizeof(struct event));
	if (r_size != sizeof(struct event)) {
		free(ev);
		return VERTEX_QUIT;
	}

	return ev;
}

void *parse_handler(void *data, void __attribute__((unused)) *private)
{
	struct event *ev = data;
	print_event(ev);
	free(ev);
	return NULL;
}

int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "error parameter\n");
		return -1;
	}
	int fd = open(argv[1], O_RDONLY);
	CHECK(fd);
	struct vertex *read_vtx = vertices(0, read_handler, &fd);
	CHECK(read_vtx);
	struct vertex *parse_vtx = vertex(parse_handler, NULL);
	CHECK(parse_vtx);

	edge(read_vtx, parse_vtx);

	vertex_start(read_vtx);

	vertex_stop(read_vtx);

	close(fd);
	return 0;
}
