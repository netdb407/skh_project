#ifndef HEAP_H_TNHV0ZZG
#define HEAP_H_TNHV0ZZG

#include <inttypes.h>

typedef uint64_t HEAP_ELEMENT;

struct heap {
	HEAP_ELEMENT *arr;
	uint64_t count;
	uint64_t capacity;
};

struct heap *heap_alloc(void);
void heap_free(struct heap *h);
void heap_maxpush(struct heap *h, HEAP_ELEMENT key);
void heap_minpush(struct heap *h, HEAP_ELEMENT key);
HEAP_ELEMENT heap_maxpop(struct heap *h);
HEAP_ELEMENT heap_minpop(struct heap *h);
HEAP_ELEMENT heap_peek(struct heap *h);

#endif /* end of include guard: HEAP_H_TNHV0ZZG */
