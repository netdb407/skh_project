#include <stdio.h>
#include <inttypes.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <limits.h>
#include <sys/stat.h>
#include <float.h>
#include <math.h>
#include <time.h>
#include <assert.h>

#include "ioparser.h"
#include "vertex/vertex.h"
#include "debug.h"
#include "list/list.h"
#include "uthash.h"
#include "file_name.h"
#include "heap.h"
#include "file/file.h"
#include "buffer/buffer.h"
#include "write_vtx.h"
#include "dmdu_vtx.h"
#include "trace_vtx.h"
#include "process_vtx.h"
#include "extsort.h"

#define TNS ((uint64_t)1000000000ULL)
#define NS_FMT "%"PRIu64".%.9"PRIu64
#define NS_ARG(time) (time)/1000000000UL, (time)%1000000000UL

enum {READ_DMDU, READ_TRACE, READ_PROCESS, NR_READ};

ssize_t rhandler(void *private, void *buf, size_t nbyte)
{
	ssize_t r_size = file_read(private, buf, nbyte);
	return r_size;
}

ssize_t fdrhandler(void *private, void *buf, size_t nbyte)
{
	return read((long)private, buf, nbyte);
}

static int __open_log(struct buffer *input, char *value)
{
	char path[PATH_MAX];
	struct stat st;
	struct file *f = NULL;
	int r = 0;
	long fd = 0;

	if (stat(value, &st) < 0) {
		fprintf(stderr, "%s stat failed\n", value);
		return -1;
	}

	if (!S_ISDIR(st.st_mode)) {
		fprintf(stderr, "%s is not directory\n", value);
		return -1;
	}

	sprintf(path, "%s/%s", value, TRACE_FILE);
	fd = open(path, O_RDONLY);
	assert(fd > 0);
	//f = file_open(path, FILE_READ, 4*1024*1024);
	//CHECK(f);
	r = buffer_init(&input[READ_TRACE], 4*1024*1024, fdrhandler, (void *)fd);
	if (r < 0) {
		fprintf(stderr, "buffer init failed\n");
	}

	sprintf(path, "%s/%s", value, DMDU_FILE);
	f = file_open(path, FILE_READ, 4*1024*1024);
	CHECK(f);
	r = buffer_init(&input[READ_DMDU], 4*1024*1024, rhandler, f);
	if (r < 0) {
		fprintf(stderr, "buffer init failed\n");
	}

	sprintf(path, "%s/%s", value, PROCESS_FILE);
	fd = open(path, O_RDONLY);
	CHECK(fd > 0);
	r = buffer_init(&input[READ_PROCESS], 4*1024*1024, fdrhandler, (void *)fd);
	if (r < 0) {
		fprintf(stderr, "buffer init failed\n");
	}

	return 0;
}

ssize_t whandler(void *private, void *buf, size_t nbyte)
{
	int64_t fd = (int64_t)private;
	return write(fd, buf, nbyte);
}

static void __open_path_file(struct buffer *output, int append, char *path)
{
	int dfd = open(path, O_RDONLY);
	int64_t fd = 0;

	int size = 4*1024*1024; // 4 MiB

	int option = O_CREAT|O_WRONLY|O_TRUNC;

	if (append) {
		option = O_WRONLY|O_APPEND;
	}

	fd = openat(dfd, "w_window.csv", option, 0644);
	buffer_init(&output[WRITE_WWINDOW], size, whandler, (void *)fd);

	fd = openat(dfd, "r_window.csv", option, 0644);
	buffer_init(&output[WRITE_RWINDOW], size, whandler, (void *)fd);

	fd = openat(dfd, "d_window.csv", option, 0644);
	buffer_init(&output[WRITE_DWINDOW], size, whandler, (void *)fd);

	fd = openat(dfd, "dmdu.csv", option, 0644);
	buffer_init(&output[WRITE_DMDU], size, whandler, (void *)fd);
//
//	fd = openat(dfd, "threshold.csv", option, 0644);
//	buffer_init(&conf->output[WRITE_THRESHOLD], size, whandler, (void *)fd);

	fd = openat(dfd, "flow.csv", option, 0644);
	buffer_init(&output[WRITE_FLOW], size, whandler, (void *)fd);

	fd = openat(dfd, "raw.csv", option, 0644);
	buffer_init(&output[WRITE_RAW], size, whandler, (void *)fd);

	fd = openat(dfd, "process.csv", option, 0644);
	buffer_init(&output[WRITE_PROCESS], size, whandler, (void *)fd);

	fd = openat(dfd, "vfs_write.csv", option, 0644);
	buffer_init(&output[WRITE_VFS_WRITE], size, whandler, (void *)fd);

	fd = openat(dfd, "vfs_read.csv", option, 0644);
	buffer_init(&output[WRITE_VFS_READ], size, whandler, (void *)fd);

	fd = openat(dfd, "vfs_write_window.csv", option, 0644);
	buffer_init(&output[WRITE_VFS_WINDOW_WRITE], size, whandler, (void *)fd);

	fd = openat(dfd, "vfs_read_window.csv", option, 0644);
	buffer_init(&output[WRITE_VFS_WINDOW_READ], size, whandler, (void *)fd);
	close(dfd);
}

static int __open_output(struct buffer *output, int append, char *value)
{
	struct stat st;

	if (stat(value, &st) < 0) {
		if (errno == ENOENT) {
			int r = mkdir(value, 0755);
			if (r < 0) {
				fprintf(stderr, "%s directory create failed\n", value);
				return -1;
			}
		} else {
			fprintf(stderr, "%s stat failed\n", value);
			return -1;
		}

		if (stat(value, &st) < 0) {
			fprintf(stderr, "%s stat failed\n", value);
			return -1;
		}
	}

	if (!S_ISDIR(st.st_mode)) {
		fprintf(stderr, "%s is not directory\n", value);
		return -1;
	}

	__open_path_file(output, append, value);

	return 0;
}

// unsorted trace to sorted trace
#include "event.h"
int mycompare(const void *a, const void *b)
{
	const struct event *_a = a;
	const struct event *_b = b;

	return (_b->time < _a->time) - (_a->time < _b->time);
}

ssize_t myread(void *private, void *buf, size_t nbyte)
{
	struct file *file = private;

	return file_read(file, buf, nbyte);
}

int ioparser(char *input_dir, char *output_dir, int window, int append, int raw)
{
	struct write_vtx *write_vtx = NULL;
	struct dmdu_vtx  *dmdu_vtx = NULL;
	struct trace_vtx *trace_vtx = NULL;
	struct process_vtx *process_vtx = NULL;

	struct buffer input[NR_READ] = {{0}};
	struct buffer output[NR_WRITE] = {{0}};
	int r = 0;
	int i = 0;

	{ // sorting
		char path[PATH_MAX];
		sprintf(path, "%s/%s", input_dir, TRACE_FILE);
		char temp[PATH_MAX];
		sprintf(temp, "%s/%s", input_dir, "extsort.XXXXXX");
		struct file *f = file_open(path, FILE_READ, 4*1024*1024);
		CHECK(f);

		struct extsort ext = {0};

		ext.ecmp = mycompare;
		ext.eread = myread;
		ext.tmplate = temp;
		ext.output = path;
		ext.nmemb = 1000000;
		ext.size = sizeof(struct event);
		ext.private = f;

		extsort(&ext);
		file_close(f);
	}
	r = __open_log(input, input_dir);
	if (r < 0) {
		return -1;
	}

	r = __open_output(output, append, output_dir);
	if (r < 0) {
		return -1;
	}

	write_vtx = write_start(output, append);
	CHECK(write_vtx);
	dmdu_vtx = dmdu_start(write_vtx->write_vtx, &input[READ_DMDU]);
	CHECK(dmdu_vtx);
	trace_vtx = trace_start(&input[READ_TRACE], window, write_vtx->write_vtx, raw);
	CHECK(trace_vtx);
	process_vtx = process_start(write_vtx->write_vtx, &input[READ_PROCESS]);

	process_stop(process_vtx);
	dmdu_stop(dmdu_vtx);
	trace_stop(trace_vtx);
	write_stop(write_vtx);

	// CLOSE
	close((long)input[READ_TRACE].private);
	file_close(input[READ_DMDU].private);
	close((long)input[READ_PROCESS].private);

	for (i = 0; i < NR_READ; ++i) {
		buffer_deinit(&input[i]);
	}

	return 0;
}
