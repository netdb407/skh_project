#ifndef DMDU_VTX_H_WOWRIKJ5
#define DMDU_VTX_H_WOWRIKJ5

struct read_dmdu_conf {
	struct buffer *buffer;
};

struct dmdu_merge_conf {
	struct dmdu_raw *prev;
	struct vertex *write_vtx;
};

struct dmdu_vtx {
	struct read_dmdu_conf read_dmdu_conf;
	struct dmdu_merge_conf dmdu_merge_conf;
	struct vertex *read_dmdu_vtx;
};

struct dmdu_vtx *dmdu_start(struct vertex *write_vtx, struct buffer *buf);
void dmdu_stop(struct dmdu_vtx *vtx);

#endif /* end of include guard: DMDU_VTX_H_WOWRIKJ5 */
