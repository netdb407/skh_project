#ifndef IOPARSER_H_9WJOP1VN
#define IOPARSER_H_9WJOP1VN

int ioparser(char *input, char *output, int window, int append, int raw);

#endif /* end of include guard: IOPARSER_H_9WJOP1VN */
