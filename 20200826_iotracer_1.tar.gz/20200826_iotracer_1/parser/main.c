#include <stdlib.h>

#include "ioparser.h"
#include "argument/arg.h"

struct program_conf {
	double threshold;
	int window_size;
	int append;
	int enable_raw;

	char *input;
	char *output;
};

struct arg_option op[] = {
	{'t', "threshold", ARG_OPTION_VALUE, "set threshold"},
	{'w', "window", ARG_OPTION_VALUE, "window size"},
	{'a', "append", ARG_OPTION_NO_VALUE, "enable append"},
	{'r', "raw", ARG_OPTION_NO_VALUE, "enable raw file"},
	{0, "input", ARG_OPTION_MANDATORY, "log directory"},
	{1, "output", ARG_OPTION_MANDATORY, "output directory"},
	{0, 0, 0, 0}
};

static double __str_to_double(char *str)
{
	double ret = 0;
	char *tmp = NULL;

	ret = strtod(str, &tmp);
	if (*tmp) {
		arg_err(op, -1);
	}

	return ret;
}

static int __str_to_int(char *str)
{
	int ret = 0;
	char *tmp = NULL;

	ret = strtol(str, &tmp, 10);
	if (*tmp) {
		arg_err(op, -1);
	}

	return ret;
}

static void parser(char key, char *value, void *private)
{
	struct program_conf *conf = private;
	switch (key) {
	case 't':
		conf->threshold = __str_to_double(value);
		break;
	case 'w':
		conf->window_size = __str_to_int(value);
		break;
	case 'a':
		conf->append = 1;
		break;
	case 'r':
		conf->enable_raw = 1;
		break;
	case 0:
		conf->input = value;
		break;
	case 1:
		conf->output = value;
		break;
	default:
		arg_err(op, -1);
		break;
	}
}

int main(int argc, char *argv[])
{
	struct program_conf conf = {0};
	int nr_man = 0;

	conf.window_size = 60;

	nr_man = arg_parse(argc, argv, op, parser, &conf);
	if (nr_man != 2) {
		arg_err(op, -1);
	}
	ioparser(conf.input, conf.output, conf.window_size, conf.append, conf.enable_raw);

	return 0;
}
