#ifndef PROCESS_VTX_H_1AXYUWSG
#define PROCESS_VTX_H_1AXYUWSG

#include "buffer/buffer.h"
#include "vertex/vertex.h"

struct process_vtx {
	struct vertex *vtx;
};

struct process_vtx *process_start(struct vertex *write_vtx, struct buffer *buf);
void process_stop(struct process_vtx *vtx);

#endif /* end of include guard: PROCESS_VTX_H_1AXYUWSG */
