#include <stdio.h>
#include <inttypes.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <limits.h>
#include <sys/stat.h>
#include <float.h>
#include <math.h>
#include <time.h>
#include <assert.h>

#include "vertex/vertex.h"
#include "debug.h"
#include "list/list.h"
#include "uthash.h"
#include "argument/arg.h"
#include "file_name.h"
#include "heap.h"
#include "file/file.h"
#include "buffer/buffer.h"

#define TNS ((uint64_t)1000000000ULL)
#define NS_FMT "%"PRIu64".%.9"PRIu64
#define NS_ARG(time) (time)/1000000000UL, (time)%1000000000UL

enum {
	BLOCK_BIO_BACKMERGE = 1,
	BLOCK_BIO_COMPLETE,
	BLOCK_BIO_QUEUE,
	BLOCK_DIRTY_BUFFER,
	BLOCK_PLUG,
	BLOCK_RQ_INSERT,
	BLOCK_RQ_REMAP,
	BLOCK_SLEEPRQ,
	BLOCK_TOUCH_BUFFER,
	BLOCK_BIO_BOUNCE,
	BLOCK_BIO_FRONTMERGE,
	BLOCK_BIO_REMAP,
	BLOCK_GETRQ,
	BLOCK_RQ_COMPLETE,
	BLOCK_RQ_ISSUE,
	BLOCK_RQ_REQUEUE,
	BLOCK_SPLIT,
	BLOCK_UNPLUG,
	VFS_WRITE_START,
	VFS_WRITE_END,
	NVME_SQ,
	NVME_COMPLETE_RQ
};

char *types[] = {
	"None",
	"BLOCK_BIO_BACKMERGE",
	"BLOCK_BIO_COMPLETE",
	"BLOCK_BIO_QUEUE",
	"BLOCK_DIRTY_BUFFER",
	"BLOCK_PLUG",
	"BLOCK_RQ_INSERT",
	"BLOCK_RQ_REMAP",
	"BLOCK_SLEEPRQ",
	"BLOCK_TOUCH_BUFFER",
	"BLOCK_BIO_BOUNCE",
	"BLOCK_BIO_FRONTMERGE",
	"BLOCK_BIO_REMAP",
	"BLOCK_GETRQ",
	"BLOCK_RQ_COMPLETE",
	"BLOCK_RQ_ISSUE",
	"BLOCK_RQ_REQUEUE",
	"BLOCK_SPLIT",
	"BLOCK_UNPLUG",
	"VFS_WRITE_START",
	"VFS_WRITE_END",
	"NVME_SQ",
	"NVME_COMPLETE_RQ"
};

struct event {
	int type;

	uint64_t time;

	// device info
	int dev;

	// process info
	uint64_t pid;

	// bio or read/write info
	int off;
	int len;
};

struct sector {
	int sector;
	struct list events;
	UT_hash_handle hh;
};

ssize_t rhandler(void *private, void *buf, size_t nbyte)
{
	ssize_t r_size = file_read(private, buf, nbyte);
	return r_size;
}

struct read_bcc_conf {
	struct buffer file_buffer;
//	struct file *file;
	int nr_record;
};

/** 
 * @brief trace.bin 파일을 읽어서 event 전달
 * 
 * @param data 미사용 
 * @param private
 * 
 * @return 읽은 event 정보 전달
 */
void *read_bcc_handler(void __attribute__((unused)) *data, void *private)
{
	struct read_bcc_conf *conf = private;
	struct event *ev = NULL;
	int r_size = 0;
	ev = malloc(sizeof(struct event));
	CHECK(ev);

	r_size = buffer_pop(&conf->file_buffer, ev, sizeof(struct event));
	//if (r_size != sizeof(struct event)) {
	if (r_size < 0) {
		printf("r_size %d\n", r_size);
		printf("read bcc record %d\n", conf->nr_record);
		free(ev);
		return VERTEX_QUIT;
	}

	++conf->nr_record;

	return ev;
}

/** 
 * @brief event가 backmerge일 경우, 이전 bio sector를 추적하고 여기에 현재 flow를 합침
 * 
 * @param search  현재 flow
 * @param sectors sector의 집합
 */
void block_bio_backmerge(struct sector *search, struct sector **sectors)
{
//	struct sector *back = NULL;
//	int back_sector = search->sector;

	// FIXME backmerge 시간 소요가 너무 심함
//	while (1) {
//		back_sector -= 8;
//		HASH_FIND_INT(*sectors, &back_sector, back);
//		if (back) {
//			break;
//		}
//	}
//
//	list_merge(&back->events, &search->events);
	struct event *ev;
	struct list *pos;

	list_for_del(&search->events, pos, ev) {
		free(ev);
	}

	HASH_DEL(*sectors, search);
	free(search);
}

/** 
 * @brief bio 종료 시, sector의 집합에서 현재 flow 제거
 * 
 * @param search 현재 flow
 * @param sectors sector의 집합
 */
void block_rq_complete(struct sector *search, struct sector **sectors)
{
	HASH_DEL(*sectors, search);
	free(search);
}

/** 
 * @brief bio가 나누어 질 때, 나누어지는 bio 생성
 * 
 * @param search 현재 flow
 * @param sectors sector의 집합
 */
void block_split(struct sector *search, struct sector **sectors)
{
	struct sector *new = NULL;
	struct event *split = search->events.prev->data;
	struct event *dup = NULL;

	new = malloc(sizeof(struct sector));
	CHECK(new);
	new->sector = split->len;
	list_init(&new->events);

	HASH_ADD_INT(*sectors, sector, new);

	dup = malloc(sizeof(struct event));
	CHECK(dup);
	memcpy(dup, split, sizeof(struct event));

	list_add_tail(&new->events, dup);
}

/** 
 * @brief bio의 시작, event 누락으로 인해 flow가 완성되지 않는 경우 처리
 * 
 * @param search 현재 flow
 * @param sectors 미사용
 */
void block_bio_remap(struct sector *search, struct sector __attribute__((unused)) **sectors)
{
	if (search->events.next != search->events.prev) {
		struct event *last = search->events.prev->data;
		list_del(search->events.prev);

		// remove conflict data
		struct event *ev = NULL;
		struct list *pos;
		list_for_del(&search->events, pos, ev) {
			free(ev);
		}

		list_add_tail(&search->events, last);
	}
}

struct make_flow_conf {
	struct sector *sectors;
	int nr_record;
};

/** 
 * @brief flow 생성
 * 
 * @param data event
 * @param private 설정
 * 
 * @return flow 전달
 */
void *make_flow_handler(void *data, void *private)
{
	struct make_flow_conf *conf = private;
	struct event *ev = data;
	struct sector *search = NULL;
	struct list *flow = NULL;

	HASH_FIND_INT(conf->sectors, &ev->off, search);
	if (search == NULL) {
		if (ev->type != BLOCK_BIO_QUEUE) {
			return NULL;
		}
		search = malloc(sizeof(struct sector));
		CHECK(search);
		search->sector = ev->off;
		list_init(&search->events);

		HASH_ADD_INT(conf->sectors, sector, search);
	}

	list_add_tail(&search->events, ev);

	switch (ev->type) {
	case BLOCK_BIO_QUEUE:
		block_bio_remap(search, &conf->sectors);
		break;
	case BLOCK_RQ_COMPLETE:
		flow = malloc(sizeof(struct list));
		CHECK(flow);
		list_init(flow);
		list_merge(flow, &search->events); 
		block_rq_complete(search, &conf->sectors);
		 // DEBUG
		{
			uint64_t first_time = (((struct event *)flow->next->data)->time);
			uint64_t last_time = (((struct event *)flow->prev->data)->time);
			struct event *mine;
			struct list *pos;

			if (last_time - first_time > 10*TNS) {
				//printf("what\n");
				list_for_del(flow, pos, mine) {
				//	printf(""NS_FMT", %s, %u, %u\n", NS_ARG(mine->time), types[mine->type], mine->off, mine->len);
					free(mine);
				}
				free(flow);
				flow = NULL;
				//printf("\n\n");
				break;
			}
		}
		++conf->nr_record;
		break;
	case BLOCK_BIO_BACKMERGE:
		block_bio_backmerge(search, &conf->sectors);
		break;
	case BLOCK_SPLIT:
		block_split(search, &conf->sectors);
		break;
	default:
		break;
	}

	return flow;
}

struct threashold_conf {
	double max;
	double min;
};

struct raw {
        uint64_t time;
        uint64_t latency;
        uint64_t kernel_time;
        uint64_t driver_time;
        uint64_t device_time;
        uint64_t io_size;
};

void print_raw(struct raw *raw)
{
	printf("Time\": "NS_FMT"," , NS_ARG(raw->time));
	printf("Size of IO\": %"PRIu64"," , raw->io_size);
	printf("Latency\": "NS_FMT",", NS_ARG(raw->latency));
	printf("Kernel Time\": "NS_FMT",", NS_ARG(raw->kernel_time));
	printf("Driver Time\": "NS_FMT",", NS_ARG(raw->driver_time));
	printf("Device Time\": "NS_FMT"", NS_ARG(raw->device_time));
}

void *threashold_handler(void *data, void *private)
{
	struct threashold_conf *conf = private;
	struct list *events = data;

	struct raw raw;

	{
		struct list *pos;
		struct event *ev;
		uint64_t sq = 0, complete = 0, getq = 0;
		uint64_t first_time = (((struct event *)events->next->data)->time);
		uint64_t last_time = (((struct event *)events->prev->data)->time);
		int      last_len = ((struct event *)events->prev->data)->len;
		list_for_del(events, pos, ev) {
			if (ev->type == NVME_SQ) {
				sq = (ev->time);
			} else if (ev->type == BLOCK_RQ_COMPLETE) {
				complete = (ev->time);
			} else if (ev->type == BLOCK_BIO_BACKMERGE || ev->type == BLOCK_GETRQ || ev->type == BLOCK_BIO_QUEUE) {
				getq = (ev->time);
			}

			free(ev);
		}
		free(events);

		if (sq != 0 && complete != 0 && getq != 0) {
			raw.time = last_time;
			raw.latency = last_time - first_time;
			raw.kernel_time = getq - first_time;
			raw.driver_time = sq - getq;
			raw.device_time = complete - sq;
			raw.io_size = last_len*512;
		} else {
			return NULL;
		}
	}

	if (raw.latency > conf->max) {
		print_raw(&raw);
	}

	if (raw.latency < conf->min) {
		print_raw(&raw);
	}


	return NULL;
}

struct myarg_conf {
	struct file *trace_file;
	double max;
	double min;
};

struct arg_option op[] = {
	{0, "input", ARG_OPTION_MANDATORY, "trace.bin"},
	{1, "max", ARG_OPTION_MANDATORY, "output directory"},
	{2, "min", ARG_OPTION_MANDATORY, "output directory"},
	{0, 0, 0, 0}
};

/** 
 * @brief 프로그램 설정 free
 * 
 * @param conf
 */
static void teardown(struct myarg_conf *conf)
{
	file_close(conf->trace_file);
}

/** 
 * @brief 부동소수점형태의 문자열을 부동소수점으로 변환
 * 
 * @param str
 * 
 * @return 
 */
static double __str_to_double(char *str)
{
	double ret = 0;
	char *tmp = NULL;

	ret = strtod(str, &tmp);
	if (*tmp) {
		arg_err(op, -1);
	}

	return ret;
}

///** 
// * @brief 정수형태의 문자열을 정수로 변환
// * 
// * @param str
// * 
// * @return 
// */
//static int __str_to_int(char *str)
//{
//	int ret = 0;
//	char *tmp = NULL;
//
//	ret = strtol(str, &tmp, 10);
//	if (*tmp) {
//		arg_err(op, -1);
//	}
//
//	return ret;
//}

/** 
 * @brief 프로그램 argument 해석
 * 
 * @param key
 * @param value
 * @param private
 */
static void parser(char key, char *value, void *private)
{
	struct myarg_conf *conf = private;
	switch (key) {
	case 0:
		conf->trace_file = file_open(value, FILE_READ, 4*1024*1024);
		if (conf->trace_file == NULL) {
			arg_err(op, -1);
		}
		break;
	case 1:
		conf->max = __str_to_double(value);
		break;
	case 2:
		conf->min = __str_to_double(value);
		break;
	default:
		arg_err(op, -1);
		break;
	}
}

#define VTX(name) printf(#name": %p\n", (void *)name);

int main(int argc, char *argv[])
{
	struct myarg_conf conf;

	int nr_man = arg_parse(argc, argv, op, parser, &conf);
	if (nr_man != 3) {
		arg_err(op, -1);
	}

	printf("max %lf min %lf\n", conf.max, conf.min);

	struct read_bcc_conf read_bcc_conf;
	read_bcc_conf.nr_record = 0;
	buffer_init(&read_bcc_conf.file_buffer, 4*1024*1024, rhandler, conf.trace_file);
	struct vertex *read_bcc_vtx = vertices(0, read_bcc_handler, &read_bcc_conf);
	VTX(read_bcc_vtx);
	CHECK(read_bcc_vtx);

	struct make_flow_conf make_flow_conf;
	make_flow_conf.nr_record = 0;
	make_flow_conf.sectors = NULL;
	struct vertex *make_flow_vtx = vertex(make_flow_handler, &make_flow_conf);
	VTX(make_flow_vtx);
	CHECK(make_flow_vtx);

	struct threashold_conf threashold_conf;
	threashold_conf.max = conf.max;
	threashold_conf.min = conf.min;

	struct vertex *threashold_vtx = vertex(threashold_handler, &threashold_conf);
	if (threashold_vtx == NULL) {
		return -1;
	}

	edge(read_bcc_vtx, make_flow_vtx);
	edge(make_flow_vtx, threashold_vtx);

	vertex_start(read_bcc_vtx);
	vertex_stop(read_bcc_vtx);

	printf("bcc record %d\n", read_bcc_conf.nr_record);
	printf("flow record %d\n", make_flow_conf.nr_record);

	{
		struct list *pos;
		struct sector *sect, *tmp;
		struct event *ev = NULL;
		HASH_ITER(hh, make_flow_conf.sectors, sect, tmp) {
			list_for_del(&sect->events, pos, ev) {
				//printf("ox\n");
				free(ev);
			}
			HASH_DEL(make_flow_conf.sectors, sect);
			free(sect);
		}
	}

	teardown(&conf);
	BRK();
	return 0;
}
