#ifndef EXTSORT_H_UJVCQAPS
#define EXTSORT_H_UJVCQAPS

#include <stdlib.h>

typedef int (*ext_compare)(const void *a, const void *b);
typedef ssize_t (*ext_read)(void *private, void *buf, size_t nbyte);

struct extsort {
	size_t nmemb;
	size_t size;
	ext_read eread;
	ext_compare ecmp;
	void *private;
	char *output;
	char *tmplate;
};

int extsort(struct extsort *ext);

#endif /* end of include guard: EXTSORT_H_UJVCQAPS */
