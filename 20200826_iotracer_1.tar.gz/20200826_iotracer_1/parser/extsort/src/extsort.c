#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <inttypes.h>

#include "extsort.h"
#include "list.h"

#define INT2VOIDP(i) (void*)(uintptr_t)(i)
#define VOIDP2INT(i) (int)(uintptr_t)(i)

struct fd_members {
	int *fds;
	char *members;
	size_t sz_member;
	int nr_member;
};

static int must_write(int fd, char *data, size_t size)
{
	int remain = size;
	ssize_t write_size = 0;

	while (remain > 0) {
		write_size = write(fd, &data[size-remain], remain);
		remain -= write_size;
		if (write_size <= 0) {
			break;
		}
	}

	return size-remain;
}

static struct fd_members *alloc_fm(size_t nmemb, size_t size)
{
	struct fd_members *fm = NULL;
	fm = malloc(sizeof(struct fd_members));
	if (fm == NULL) {
		return NULL;
	}

	fm->fds = malloc(sizeof(int)*nmemb);
	if (fm->fds == NULL) {
		free(fm);
		return NULL;
	}

	fm->members = malloc(nmemb * size);
	if (fm->members == NULL) {
		free(fm->fds);
		free(fm);
		return NULL;
	}

	fm->sz_member = size;
	fm->nr_member = nmemb;

	return fm;
}

static void free_fm(struct fd_members *fm)
{
	free(fm->members);
	free(fm->fds);
	free(fm);
}

// consume list 정도가 더 좋지 않나
static int init_fm(struct fd_members *fm, struct list *list)
{
	struct list *pos = NULL;
	void *cur = NULL;
	int fd = 0;
	int idx = 0;
	int r = 0;
	ssize_t sz_read = 0;

	list_for_del(list, pos, cur) {
		fd = VOIDP2INT(cur);
		fm->fds[idx] = fd;
		r = lseek(fd, 0, SEEK_SET);
		if (r < 0) {
			return -1;
		}
		sz_read = read(fd, &fm->members[fm->sz_member * idx], 
			       fm->sz_member);
		if ((size_t)sz_read != fm->sz_member) {
			return -1;
		}
		++idx;
	}

	return 0;
}

static int choose_min_member(struct fd_members *fm, ext_compare ecmp)
{
	const int cnt = fm->nr_member;
	const size_t size = fm->sz_member;

	char *member = NULL;
	int min_idx = 0;
	int i = 0;

	min_idx = 0;
	member = fm->members;
	for (i = 1; i < cnt; ++i) {
		if (ecmp(member, &fm->members[i*size]) > 0) {
			member = &fm->members[i*size];
			min_idx = i;
		}
	}

	return min_idx;
}

static void fm_remove_at(struct fd_members *fm, int idx)
{
	const size_t size = fm->sz_member;
	const int nr_member = fm->nr_member;

	close(fm->fds[idx]);
	memmove(&fm->members[size *  idx   ], 
		&fm->members[size * (idx+1)], 
		(nr_member-1-idx)*size);
	memmove(&fm->fds[idx  ], 
		&fm->fds[idx+1], 
		(nr_member-1-idx)*sizeof(int));

	--fm->nr_member;
}

static int tempfd(char *tmplate)
{
	int fd = 0;
	char *filename = NULL;

	filename = strdup(tmplate);
	if (filename == NULL) {
		return -1;
	}

	fd = mkstemp(filename);
	unlink(filename);
	free(filename);
	return fd;
}

/** 
 * @brief 
 * 
 * @param list
 * @param nmemb
 * @param size
 * @param eread
 * @param ecmp
 * @param private
 * 
 * @return 
 *   success : fd 갯수
 *   failed  : -1
 */
static int distribute_sorted_file(struct list *list, struct extsort *ext)
{
	const size_t sz_members = ext->nmemb * ext->size;
	char *members = NULL;
	ssize_t sz_read = 0, sz_write = 0;
	int fd = 0;
	int r = 0;
	int nr_fd = 0;

	members = malloc(sz_members);
	if (members == NULL) {
		return -1;
	}

	while (1) { 
		// input : private, members, size, nmemb
		// output : fd
		sz_read = ext->eread(ext->private, members, sz_members);
		if (sz_read % ext->size != 0) { // member의 크기를 다 채우지 못함
			break;
		}

		if (sz_read == 0) { // 더 이상 읽을 것이 없음
			break;
		}

		qsort(members, sz_read/ext->size, ext->size, ext->ecmp);
		fd = tempfd(ext->tmplate);

		sz_write = must_write(fd, members, sz_read);
		assert(sz_write == sz_read);

		r = list_add_tail(list, INT2VOIDP(fd));
		assert(r == 0);

		++nr_fd;
	}
	free(members);

	return nr_fd;
}

int extsort(struct extsort *ext)
{
	struct list list = {0};
	ssize_t sz_read = 0;
	int out_fd = 0;
	int r = 0;
	int nr_member = 0;

	list_init(&list);

	nr_member = distribute_sorted_file(&list, ext);

	out_fd = creat(ext->output, 0644);
	assert(out_fd > 0);

	// alloc and init first members
	struct fd_members *fm = NULL;
	fm = alloc_fm(nr_member, ext->size);
	assert(fm);
	r = init_fm(fm, &list);
	assert(r == 0);

	int min_idx = 0;
	char *member;
	while (fm->nr_member) {
		// choose min_idx;
		min_idx = choose_min_member(fm, ext->ecmp);
		member = &fm->members[min_idx*fm->sz_member];

		// sorted data into output file
		must_write(out_fd, member, ext->size);

		// fill new data
		sz_read = read(fm->fds[min_idx], member, ext->size);
		if (sz_read == 0) { // read failed if fd is EOF
			fm_remove_at(fm, min_idx);
		}

		assert(sz_read >= 0); // logic 에러
	}

	free_fm(fm);
	close(out_fd);

	return 0;
}
